import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type AmcDocument = Amc & Document;

@Schema({ timestamps: true }) // handles createdAt and updatedAt automatically
export class Amc {
  @Prop({ required: true })
  amcId: string;

  @Prop({ required: true })
  name: string;

  @Prop({ required: true })
  shortName: string;

  @Prop({ required: true })
  registrationNumber: string;

  @Prop({
    type: {
      email: { type: String, required: true },
      phone: { type: String, required: true },
      website: { type: String, required: true },
    },
    required: true,
  })
  contactDetails: {
    email: string;
    phone: string;
    website: string;
  };

  @Prop({
    type: {
      street: { type: String, required: true },
      city: { type: String, required: true },
      state: { type: String, required: true },
      country: { type: String, required: true },
      pincode: { type: String, required: true },
    },
    required: true,
  })
  address: {
    street: string;
    city: string;
    state: string;
    country: string;
    pincode: string;
  };

  @Prop({ required: true })
  logo: string;

  @Prop({ required: true, enum: ['Active', 'Inactive'] })
  status: 'Active' | 'Inactive';
}

export const AmcSchema = SchemaFactory.createForClass(Amc);
