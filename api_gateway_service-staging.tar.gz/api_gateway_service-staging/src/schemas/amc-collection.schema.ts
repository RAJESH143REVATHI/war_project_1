import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';

export type AmcCollectionDocument = AmcCollection & Document;

@Schema({ timestamps: true })
export class AmcCollection {
    @Prop({ required: true })
    collectionName: string;

    @Prop({ required: true })
    image: string;

    @Prop({ type: MongooseSchema.Types.Mixed, required: false })
    filter?: Record<string, any>; // Accepts dynamic filter values
}

export const AmcCollectionSchema = SchemaFactory.createForClass(AmcCollection);
