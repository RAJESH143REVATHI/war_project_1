import { Body, Controller, Get, Post } from '@nestjs/common';
import { AppService } from './app.service';

import { randomUUID } from 'crypto';

import axios from 'axios';
import { ConfigService } from '@nestjs/config';

@Controller()
export class AppController {
  constructor(
    private readonly appService: AppService,
    private readonly configService: ConfigService
  ) {}

  @Get()
  getHello(): string {
    return this.appService.getHello();
  }


  @Post('client_callback')
  getCollBacksHere(@Body() body:any){
    console.log(body);

    return body
  }

  @Post('search')
  async doOndcSearch(@Body() body:any){
    let payload = body;
    const request_id = randomUUID()
    const message_id = randomUUID()
    const timestamp = new Date().toISOString();

    // console.log(request_id,"$$$$$$$$$",message_id);

    payload.context.transaction_id = request_id;
    payload.context.message_id = message_id;
    payload.context.timestamp = timestamp;

    try {

      const response = await axios.post(
        `${this.configService.get('ONDC_GATEWAY')}/search`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          }
        }
      );

      console.log(response.data,"$$$$$$$$")
  
      return response.data
      
    } catch (error) {
      console.log(error.response.data,"=====EEEEEEEE=========")

      return error.response.data
    }

    
  }

  @Post('select')
  async doOndcSelect(@Body() body:any){
    let payload = body;
    const request_id = randomUUID()
    const message_id = randomUUID()
    const timestamp = new Date().toISOString();

    // console.log(request_id,"$$$$$$$$$",message_id);

    payload.context.transaction_id = 'c57dc59f-75cd-4799-8e3f-3ec37e46fe37';
    payload.context.message_id = message_id;
    payload.context.timestamp = timestamp;


    console.log(payload,"==========Payload===========");

    try {

      const response = await axios.post(
        `${this.configService.get('ONDC_GATEWAY')}/select`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          }
        }
      );

      console.log(response.data,"$$$$$$$$")
  
      return response.data
      
    } catch (error) {
      console.log(error.response.data,"=====EEEEEEEE=========")

      return error.response.data
    }

    
  }

  @Post('init')
  async doOndcInit(@Body() body:any){
    let payload = body;
    const request_id = randomUUID()
    const message_id = randomUUID()
    const timestamp = new Date().toISOString();

    // console.log(request_id,"$$$$$$$$$",message_id);

    payload.context.transaction_id = 'c57dc59f-75cd-4799-8e3f-3ec37e46fe37';
    payload.context.message_id = message_id;
    payload.context.timestamp = timestamp;


    console.log(payload,"==========Payload===========");

    try {

      const response = await axios.post(
        `${this.configService.get('ONDC_GATEWAY')}/init`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          }
        }
      );

      console.log(response.data,"$$$$$$$$")
  
      return response.data
      
    } catch (error) {
      console.log(error.response.data,"=====EEEEEEEE=========")

      return error.response.data
    }

    
  }

  @Post('confirm')
  async doOndcConfirm(@Body() body:any){
    let payload = body;
    const request_id = randomUUID()
    const message_id = randomUUID()
    const timestamp = new Date().toISOString();

    payload.context.transaction_id = 'c57dc59f-75cd-4799-8e3f-3ec37e46fe37';
    payload.context.message_id = message_id;
    payload.context.timestamp = timestamp;


    console.log(payload,"==========Payload===========");

    try {

      const response = await axios.post(
        `${this.configService.get('ONDC_GATEWAY')}/confirm`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          }
        }
      );

      console.log(response.data,"$$$$$$$$")
  
      return response.data
      
    } catch (error) {

      return error.response.data
    }

    
  }

  @Post('update')
  async doOndcUpdate(@Body() body:any){
    let payload = body;
    const request_id = randomUUID()
    const message_id = randomUUID()
    const timestamp = new Date().toISOString();

    // console.log(request_id,"$$$$$$$$$",message_id);

    payload.context.transaction_id = 'c57dc59f-75cd-4799-8e3f-3ec37e46fe37';
    payload.context.message_id = message_id;
    payload.context.timestamp = timestamp;


    console.log(payload,"==========Payload===========");

    try {

      const response = await axios.post(
        `${this.configService.get('ONDC_GATEWAY')}/update`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          }
        }
      );

      console.log(response.data,"$$$$$$$$")
  
      return response.data
      
    } catch (error) {
      console.log(error.response.data,"=====EEEEEEEE=========")

      return error.response.data
    }

    
  }

  @Post('cancel')
  async doOndcCancle(@Body() body:any){
    let payload = body;
    const request_id = randomUUID()
    const message_id = randomUUID()
    const timestamp = new Date().toISOString();

    // console.log(request_id,"$$$$$$$$$",message_id);

    payload.context.transaction_id = 'c57dc59f-75cd-4799-8e3f-3ec37e46fe37';
    payload.context.message_id = message_id;
    payload.context.timestamp = timestamp;


    console.log(payload,"==========Payload===========");

    try {

      const response = await axios.post(
        `${this.configService.get('ONDC_GATEWAY')}/cancel`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          }
        }
      );

      console.log(response.data,"$$$$$$$$")
  
      return response.data
      
    } catch (error) {
      console.log(error.response.data,"=====EEEEEEEE=========")

      return error.response.data
    }

    
  }

  @Post('issue')
  async doOndcIssue(@Body() body:any){
    let payload = body;
    const request_id = randomUUID()
    const message_id = randomUUID()
    const timestamp = new Date().toISOString();

    const issue_id = randomUUID();

    // console.log(request_id,"$$$$$$$$$",message_id);

    payload.context.transaction_id = 'c57dc59f-75cd-4799-8e3f-3ec37e46fe37';
    payload.context.message_id = message_id;
    payload.context.timestamp = timestamp;

    payload.message.issue.created_at = timestamp;
    payload.message.issue.updated_at = timestamp;
    payload.message.issue.id = issue_id;

    console.log(payload,"==========Payload===========");

    try {

      const response = await axios.post(
        `${this.configService.get('ONDC_GATEWAY')}/issue`,
        payload,
        {
          headers: {
            'Content-Type': 'application/json',
          }
        }
      );

      console.log(response.data,"$$$$$$$$")
  
      return response.data
      
    } catch (error) {
      console.log(error.response.data,"=====EEEEEEEE=========")

      return error.response.data
    }

    
  }
}
