import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
} from 'typeorm';
import { OrderEntity } from './order.entity';

export enum PaymentCollectedBy {
  BAP = 'BAP',
  BPP = 'BPP',
}

export enum PaymentType {
  PRE_FULFILLMENT = 'PRE_FULFILLMENT',
  POST_FULFILLMENT = 'POST_FULFILLMENT',
}

export enum PaymentStatus {
  PAID = 'PAID',
  NOT_PAID = 'NOT-PAID',
  FAILED = 'FAILED',
}

@Entity('payments')
export class PaymentEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  order_id: string;

  @ManyToOne(() => OrderEntity, (order) => order.payments, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'order_id' })
  order: OrderEntity;

  @Column()
  order_status:string

  @Column({
    type: 'enum',
    enum: PaymentCollectedBy,
  })
  collected_by: PaymentCollectedBy;

  @Column()
  url: string;

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount: number;

  @Column({ length: 10, default: 'INR' })
  currency: string;

  @Column()
  source_bank_code: string;

  @Column()
  source_bank_account_number: string;

  @Column()
  source_bank_account_name: string;

  @Column({
    type: 'enum',
    enum: PaymentType,
  })
  type: PaymentType;

  @Column({
    type: 'enum',
    enum: PaymentStatus,
    default: PaymentStatus.NOT_PAID,
  })
  status: PaymentStatus;

  @Column({ type: 'jsonb', nullable: true })
  tags: any;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updated_at: Date;
}
