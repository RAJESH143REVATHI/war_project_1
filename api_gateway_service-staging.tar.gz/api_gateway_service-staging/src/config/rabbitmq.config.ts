import { registerAs } from '@nestjs/config';

export default registerAs('rabbitmq', () => ({
  url: `amqp://${process.env.RABBITMQ_USERNAME}:${process.env.RABBITMQ_PASSWORD}@${process.env.RABBITMQ_URL}:5672/${process.env.V_HOST}`,
  queues: {
    autheSrvice: process.env.AUTH_SERVICE_QUEUE,
    catalogService: process.env.CATALOG_SERVICE_QUEUE,
    userService: process.env.USER_SERVICE_QUEUE,
    cartService: process.env.CART_SERVICE_QUEUE,
    orderService: process.env.ORDER_SERVICE_QUEUE,
    complaintService: process.env.COMPLAINT_SERVICE_QUEUE,
    notificationService: process.env.NOTIFICATION_SERVICE_QUEUE,
    ratingService: process.env.RATING_SERVICE_QUEUE,
    dashboardService: process.env.DASHBOARD_SERVICE_QUEUE,
    ONDC_SERVICE_QUEUE: process.env.ONDC_SERVICE_QUEUE
  },
}));
