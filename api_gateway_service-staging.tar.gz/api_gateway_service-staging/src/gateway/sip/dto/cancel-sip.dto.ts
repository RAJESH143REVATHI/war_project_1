import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CancelSIPDto {
  @ApiProperty({ description: 'SIP Id ' })
  @IsNotEmpty()
  @IsString()
  sipId: string;

}