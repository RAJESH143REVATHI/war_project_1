import { Test, TestingModule } from '@nestjs/testing';
import { SipService } from './sip.service';

describe('SipService', () => {
  let service: SipService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [SipService],
    }).compile();

    service = module.get<SipService>(SipService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
