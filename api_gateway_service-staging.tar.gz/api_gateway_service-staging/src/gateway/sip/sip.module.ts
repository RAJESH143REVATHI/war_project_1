import { Module } from '@nestjs/common';
import { SipService } from './sip.service';
import { SipController } from './sip.controller';

@Module({
  controllers: [SipController],
  providers: [SipService],
})
export class SipModule {}
