export class MutualFund {}
