import { Module } from '@nestjs/common';
import { DashboardService } from './dashboard.service';
import { DashboardController } from './dashboard.controller';
import { MongooseModule } from '@nestjs/mongoose';

import { Fund, FundSchema } from 'src/schemas/fund.schema';
import { AmcCollection, AmcCollectionSchema } from 'src/schemas/amc-collection.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Fund.name, schema: FundSchema },
      { name: AmcCollection.name, schema: AmcCollectionSchema },
    ]),],
  controllers: [DashboardController],
  providers: [DashboardService],
})
export class DashboardModule { }
