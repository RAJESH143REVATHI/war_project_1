import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class WatchList {
  @ApiProperty({ description: 'SchemeId ' })
  @IsString()
  schemeId: string;
}
