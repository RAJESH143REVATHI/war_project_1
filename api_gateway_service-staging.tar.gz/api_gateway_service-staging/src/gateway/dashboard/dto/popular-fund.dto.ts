import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class PopularFund {
  @ApiProperty({ description: 'Filter ' })
  @IsString()
  filter: string;
}
