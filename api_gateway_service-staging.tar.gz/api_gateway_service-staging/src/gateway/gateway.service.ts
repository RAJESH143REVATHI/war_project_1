import { Injectable } from '@nestjs/common';
import { ClientProxy, ClientProxyFactory, Transport } from '@nestjs/microservices';

@Injectable()
export class GatewayService {
  private userServiceClient: ClientProxy;
  private orderServiceClient: ClientProxy;

  constructor() {
    
  }

  getUserDetails(userId: string) {
    return 'User Details'
  }

  createOrder(orderDetails: any) {
    return 'Create Orders'
  }
}
