export enum MessagePatternStr {
    GET_CART = 'GET_CART',
    UPDATE_CART = 'UPDATE_CART',
    PING_CART = 'PING_CART'
}