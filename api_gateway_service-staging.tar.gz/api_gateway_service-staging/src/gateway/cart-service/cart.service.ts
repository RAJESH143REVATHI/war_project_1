import { Injectable, OnModuleDestroy, OnModuleInit } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { ClientProxy } from "@nestjs/microservices";
import { catchError, firstValueFrom, of, retry } from "rxjs";
import { CartList } from "src/gateway/mutual-funds/dto/cart-list.dto";
import { CreateMutualFundDto } from "src/gateway/mutual-funds/dto/create-mutual-fund.dto";
import { RmqService } from "src/shared/rmq.service";

@Injectable()
export class CartService implements OnModuleInit,OnModuleDestroy {
    private client: ClientProxy;

    constructor(
        private readonly configService: ConfigService,
        private readonly rmqService: RmqService,
    ){}

    onModuleInit() {
        let queue = this.configService.get<string>('rabbitmq.queues.cartService');
        this.client = this.rmqService.createClient(queue);
    }

    onModuleDestroy() {
        this.client.close();
    }

    async sendMessage(pattern: string, data: any) {
        if (!this.client) {
          throw new Error('RabbitMQ client not initialized.');
        }
    
    
        return await firstValueFrom(
          this.client.send({ cmd: pattern }, data).pipe(
            retry(1), // Retry 2 more times if needed
            catchError(err => {
              console.error('❌ Failed to send RMQ message:', err);
              return of({ error: err.message });
            })
          )
        );
      }


    addToCart(createMutualFundDto: CreateMutualFundDto) {
        return 'This action adds a mutual fund to the cart';
      }
    
      cartList(cartListDto: CartList) {
        return 'This action retrieves the cart list';
      }
    
      deleteCart(createMutualFundDto: CreateMutualFundDto) {
        return 'This action removes a mutual fund from the cart';
      }
}