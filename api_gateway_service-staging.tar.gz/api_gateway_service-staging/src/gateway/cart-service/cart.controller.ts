import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { CartService } from './cart.service';
import { ApiOperation, ApiResponse, ApiBody, ApiTags } from '@nestjs/swagger';
import { CartList } from 'src/gateway/mutual-funds/dto/cart-list.dto';
import { MutualFundDetails } from 'src/gateway/mutual-funds/dto/mutual-fund-detail.dto';
import { Request, Response } from "express";

@ApiTags('Cart')
@Controller('cart')
export class CartController {
  constructor(private readonly cartService: CartService) {}

  @Get('ping')
  pingCartService() {
    console.log('======= Ping to Cart service ===========');
    return this.cartService.sendMessage('ping_cart', {});
  }

  @Post('addToCart')
  @ApiOperation({ summary: 'Add to cart' })
  @ApiResponse({ status: 200, description: 'Successfully added to  cart' })
  @ApiBody({ type: CartList })
  addToCart(@Body() MutualFundDetailDto: MutualFundDetails) {
    return this.cartService.addToCart(MutualFundDetailDto);
  }

  @Post('cartList')
  @ApiOperation({ summary: 'Get list of mutual funds in cart' })
  @ApiResponse({ status: 200, description: 'Successfully fetched cart list' })
  @ApiBody({ type: CartList })
  cartList(@Body() cartListDto: CartList) {
    return this.cartService.cartList(cartListDto);
  }

  @Post('deleteCart')
  @ApiOperation({ summary: 'Delete mutual fund from cart' })
  @ApiResponse({
    status: 200,
    description: 'Successfully removed mutual fund from cart',
  })
  @ApiBody({ type: MutualFundDetails })
  deleteCart(@Body() mutualFundDetailDto: MutualFundDetails) {
    return this.cartService.deleteCart(mutualFundDetailDto);
  }


  /**
   * Starts from here
   */

  @Post('createOrder')
  createLumsumOrder(@Body() data:any){
    let payload = {
      tenantId: '4da743f7-57a5-41b2-bc51-b8c1f7bf38d8',
      data: data
    }
    return this.cartService.sendMessage('create_lumpsum_order',payload);
  }

  @Get('getOrderStatus/:orderId')
  getOrderStatus(@Param('orderId') data:any){
    console.log("🚀 ~ CartController ~ getOrderStatus ~ data:", data)
    let payload = {
      orderId: data
    }
    return this.cartService.sendMessage('get_order_status',payload);
  }

  @Get('handleAofSubmission/:orderId')
  handleAofSubmission(@Param('orderId') data:any){
    console.log("🚀 ~ CartController ~ handleAofSubmission ~ data:", data)
    let payload = {
      orderId: data
    }
    return this.cartService.sendMessage('handle_aof_submission',payload);
  }

  @Post('selectPaymentMethod')
  selectPaymentMethod(@Body() data:any){
    let payload = {
      orderId: data.orderId,
      paymentMethod: data.paymentMethod
    }
    return this.cartService.sendMessage('select_payment_method',payload);
  }

  @Post('submit2fa')
  submit2FA(@Body() data:any){
    let payload = {
      orderId: data.orderId,
      data: data.payloda
    }
    return this.cartService.sendMessage('submit_2fa',payload);
  }
}
