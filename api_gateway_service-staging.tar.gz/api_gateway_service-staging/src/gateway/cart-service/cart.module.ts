import { Module } from "@nestjs/common";
import { CartService } from "./cart.service";
import { CartController } from "./cart.controller";
import { ConfigService } from "@nestjs/config";
import { RmqService } from "src/shared/rmq.service";

@Module({
    imports:[],
    controllers: [CartController],
    providers: [CartService,ConfigService,RmqService]
})
export class CartModule {}