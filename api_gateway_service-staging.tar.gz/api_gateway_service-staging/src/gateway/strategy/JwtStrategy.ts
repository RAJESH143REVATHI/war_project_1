import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: 'YOUR_SECRET_KEY',
    });
  }

  async validate(payload: any) {
    // this will be available as req.user
    return {
      user_id: payload.user_id,
      email:payload?.email,
      mobile_number: payload?.mobile_number,
      tenant_id: payload?.tenant_id,
      name:payload?.name

    };
  }
}
