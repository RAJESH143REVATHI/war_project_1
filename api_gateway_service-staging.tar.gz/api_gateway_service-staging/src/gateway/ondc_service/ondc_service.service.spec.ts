import { Test, TestingModule } from '@nestjs/testing';
import { OndcServiceService } from './ondc_service.service';

describe('OndcServiceService', () => {
  let service: OndcServiceService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [OndcServiceService],
    }).compile();

    service = module.get<OndcServiceService>(OndcServiceService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
