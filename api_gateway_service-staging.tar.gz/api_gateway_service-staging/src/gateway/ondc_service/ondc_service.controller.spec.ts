import { Test, TestingModule } from '@nestjs/testing';
import { OndcServiceController } from './ondc_service.controller';

describe('OndcServiceController', () => {
  let controller: OndcServiceController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [OndcServiceController],
    }).compile();

    controller = module.get<OndcServiceController>(OndcServiceController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
