import { Controller, Get } from '@nestjs/common';
import { OndcService } from './ondc_service.service';

@Controller('ondc-service')
export class OndcServiceController {

    constructor(private readonly ondcService: OndcService){}


    @Get('ping')
    pingOndcService(){
        return this.ondcService.sendMessage('ping_ondc_service',{name:'Suman Singh!!'});
    }
}
