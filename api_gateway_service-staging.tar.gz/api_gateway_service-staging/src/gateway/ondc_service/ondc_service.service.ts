import { Injectable, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClientProxy } from '@nestjs/microservices';
import { RmqService } from 'src/shared/rmq.service';

@Injectable()
export class OndcService implements OnModuleInit {
    private client: ClientProxy

    constructor(
        private readonly rmqService: RmqService,
        private readonly configService: ConfigService
    ){}

    onModuleInit() {
        let queue = this.configService.get<string>('rabbitmq.queues.ONDC_SERVICE_QUEUE');
        this.client = this.rmqService.createClient(queue);
    }


    sendMessage(pattern:string,data:any){
        return this.client.send(pattern,data);
    }

}
