// catalog-message-pattern.ts

export enum HttpMethod {
    GET = 'get',
    POST = 'post',
    PUT = 'put',
    DELETE = 'delete',
}

export enum MessagePatternStr {
    VERIFY_PAN = 'VERIFY_PAN',
    CREATE_OTP = 'CREATE_OTP',
    VERIFY_OTP = 'VERIFY_OTP',
    VERIFY_BANK = 'VERIFY_BANK',
}




