// src/user/dto/create-user.dto.ts
import { IsEmail, IsNotEmpty, IsOptional, IsString, MinLength } from 'class-validator';

export class CreateUserDto {
  
  @IsString()
  @IsNotEmpty()
  name: string;

  @IsEmail()
  @IsOptional()
  email: string;

  @IsString()
  tenant_id: string
  
  @IsString()
  @IsNotEmpty()
  mobile_number: string;

  // New optional fields
  @IsString()
  ip_address?: string;

  @IsString()
  @IsOptional()
  fcm_token?: string;

  @IsString()
  device_detail?: string;

  @IsString()
  latitude?: string;

  @IsString()
  logitude?: string;

  @IsString()
  @IsOptional()
  device_id?: string;
}

export class GetUserDetailsDto{
  @IsString({message:"mobile_number must be string"})
  @IsNotEmpty({message:"mobile_number required"})
  mobile_number:string
}