// src/user/dto/user-aof.dto.ts
import { ApiBody, ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsDateString,
  IsEnum,
  Length,
  IsOptional,
  IsNumberString,
  IsEmail,
  IsIn,
  Matches,
  MaxLength,
  Min,
  Max,
  IsNotEmpty,
  IsArray,
  ArrayNotEmpty,
  IsNumber,
  ValidateIf,
} from 'class-validator';
import {
  Citizenship,
  CountryCode,
  CpBelongsTo,
  Gender,
  IncomeRange,
  IndiaTaxResidencyStatus,
  MaritalStatus,
  ModeOfHolding,
  Nationality,
  NomineeDisplayOption,
  NomineeIdType,
  NomineeRelationship,
  Occupation,
  PbaType,
  PoliticalExposure,
  SkipNomination,
  SourceOfWealth,
} from 'src/enums';

export class AofDto {
  @IsString({ message: 'userId must be a string' })
  @IsNotEmpty({ message: 'userId should not be empty' })
  @ApiProperty()
  user_id: string;

  @Matches(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, {
    message:
      'PAN number must be in the format: 5 uppercase letters, 4 digits, 1 uppercase letter (e.g., ABCDE1234F)',
  })
  @IsString({ message: 'PAN must be a string' })
  @IsNotEmpty({ message: 'PAN should not be empty' })
  @ApiProperty()
  pan: string;

  // Only validate if dob is provided
  
  
  @IsString({ message: 'Date of birth must be a string' })
  @Matches(/^([0-2][0-9]|(3)[0-1])\/(0[1-9]|1[0-2])\/\d{4}$/, {
    message: 'Date of birth must be in the format dd/mm/yyyy',
  })
  @IsNotEmpty({ message: 'Date of birth is required' })
  @ApiProperty()
  dob: string;

   @IsEnum(Gender, {
    message: 'Gender must be one of: male, female, other',
  })
  @IsOptional() // Optional, because default is used if not provided
  @ApiProperty()
  gender?: Gender;

  @IsEnum(MaritalStatus, {
    message:
      'Marital status must be one of: married, single, divorced, widowed',
  })
  @IsOptional()
  @ApiProperty()
  marital_status?: MaritalStatus;

 
  @IsString({ message: 'Spouse name must be a string' })
   @IsOptional()
  @ApiProperty()
  spouse_name?: string;

 
  @IsString({ message: 'Mother name must be a string' })
   @IsOptional()
  @ApiProperty()
  mother_name?: string;

  @IsNotEmpty({ message: 'Adhaar number cannot be empty' })
  @IsString({ message: 'Aadhaar number must be a string' })
  @Matches(/^\d{4}$/, { message: 'Adhaar last 4 digit is required' })
  @ApiProperty()
  aadhaar_number: string;

  @IsEnum(CountryCode, {
    message: 'Nationality must be one of: in, us, uk, ...',
  })
  @IsOptional()
  @ApiProperty()
  nationality: CountryCode;

  @IsArray()
  @ArrayNotEmpty({ message: 'At least one citizenship is required' })
  @IsEnum(CountryCode, {
    each: true,
    message: 'Each citizenship must be a valid country',
  })
  @IsOptional()
  @ApiProperty()
  citizenships: CountryCode[];

  @IsString({
    message: 'Signature is required and must be a string (URL or path)',
  })
  @ApiProperty()
  signature: string;

  
  @IsOptional()
  @ApiProperty()
  geo_latitude: string;

  // @Min(-180)
  // @Max(180)
  // @IsNumber()
  @IsOptional()
  @ApiProperty()
  geo_longitudes: number;

  @IsEnum(Occupation, {
    message: 'Occupation must be one of Options',
  })
  @IsNotEmpty()
  @ApiProperty()
  occupation: Occupation;

  @IsEnum(SourceOfWealth, {
    message: 'source_of_wealth must be one of Options',
  })
  @IsNotEmpty()
  @ApiProperty()
  source_of_wealth: SourceOfWealth;

  @IsEnum(IncomeRange, {
    message: 'income_range must be provided',
  })
  @IsNotEmpty()
  @ApiProperty()
  income_range: IncomeRange;

  @IsEnum(CountryCode, {
    message: `COB must be one valid Country Code`,
  })
  @IsNotEmpty()
  @ApiProperty()
  cob: CountryCode;

  @IsString()
  @IsOptional()
  @ApiProperty()
  pob: string; // Place of Birth

  @IsEnum(PoliticalExposure)
  @IsString({ message: 'it must be a string' })
  @IsNotEmpty({ message: 'select and option in Political Exposure' })
  @ApiProperty()
  political_exposure: PoliticalExposure;

  @IsEnum(IndiaTaxResidencyStatus)
  @IsString()
  @IsOptional()
  @ApiProperty()
  india_tax_residency_status: IndiaTaxResidencyStatus;

  @IsEnum(CountryCode, {
    message: 'Nationality must be one of: in, us, uk, ...',
  })
  @IsString()
  @IsOptional()
  @ApiProperty()
  trc_country_0: CountryCode;

  @IsString()
  @IsOptional()
  @ApiProperty()
  trc_idtype_0: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  trc_idnumber_0: string;

  @IsEnum(CountryCode,{message:"Invalid Country Code"})
  @IsString()
  @IsOptional()
  @ApiProperty()
  trc_country_1: CountryCode;

  @IsString()
  @IsOptional()
  @ApiProperty()
  trc_idtype_1: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  trc_idnumber_1: string;

  @IsEnum(CountryCode,{message:"Invalid Country Code"})
  @IsString()
  @IsOptional()
  @ApiProperty()
  trc_country_2: CountryCode;

  @IsString()
  @IsOptional()
  @ApiProperty()
  trc_idtype_2: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  trc_idnumber_2: string;

  @IsEnum(ModeOfHolding)
  @IsOptional()
  @ApiProperty()
  mode_of_holding: ModeOfHolding;

  @IsString()
  @IsOptional()
  @ApiProperty()
  ca_line: string;

  @IsEnum(CountryCode,{message:"Invalid Country Code"})
  @IsOptional()
  @ApiProperty()
  ca_country: CountryCode;

  @IsString()
  @IsOptional()
  @ApiProperty()
  cp_number: string;

  @IsOptional()
  @IsEnum(CpBelongsTo)
  @ApiProperty()
  cp_belongsto?: CpBelongsTo;

  @IsEmail()
  @IsOptional()
  @ApiProperty()
  ce_address: string;

  @IsOptional()
  @IsEnum(CpBelongsTo)
  @ApiProperty()
  ce_belongsto?: CpBelongsTo;

  @Matches(/\d{9,18}/, {
    message: 'Invalid pba_number format',
  })
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  pba_number: string;

  @IsString()
  @Matches(/^([A-Za-z ]){1,70}$/, {
    message: 'Invalid pba_pname format',
  })
  @IsOptional()
  @ApiProperty()
  pba_pname: string;

  @Matches(/^[A-Z]{4}0[A-Z0-9]{6}$/, {
    message: 'Invalid IFSC Code format',
  })
  @IsString()
  @IsNotEmpty()
  @ApiProperty()
  pba_code: string;

  @IsEnum(PbaType)
  @IsNotEmpty()
  @ApiProperty()
  pba_type: PbaType;

  @IsEnum(SkipNomination)
  @IsOptional()
  @ApiProperty()
  skip_nomination: SkipNomination;

  @IsString()
  @Matches(/^([A-Za-z ]){1,40}$/, {
    message: 'Invalid Nominee Name format',
  })
  @IsOptional()
  @ApiProperty()
  nominee_name_0: string;

  @IsEnum(NomineeRelationship)
  @IsOptional()
  @ApiProperty()
  nominee_relationship_0?: NomineeRelationship;

  @Matches(/^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/, {
    message: 'Invalid Nominee dob format',
  })
  @IsOptional()
  @ApiProperty()
  nominee_dob_0?: string;

  @IsEnum(NomineeIdType)
  @IsOptional()
  @ApiProperty()
  nominee_idtype_0: NomineeIdType;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_idnumber: string;

  @Matches(/^([\d]){10}$/)
  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_cphone_0: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_cemail_0: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_caline_0: string;

  @Matches(/^([\d]){10}$/)
  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_capincode_0: string;

  @IsEnum(CountryCode)
  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_cacountry_0: CountryCode;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_guardian_name_0: string;

  @IsEnum(NomineeIdType)
  @IsOptional()
  @ApiProperty()
  nominee_gidtype_0: NomineeIdType;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_gidnumber_0: string;

  @IsEmail()
  @IsOptional()
  @ApiProperty()
  nominee_gcemail_0: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_gcaline_0: string;

  @IsNumber()
  @IsOptional()
  @ApiProperty()
  nominee_gcapincode_0: number;

  @IsEnum(CountryCode)
  @IsOptional()
  @ApiProperty()
  nominee_gcacountry_0: CountryCode;

  @IsNumber()
  @IsOptional()
  @ApiProperty()
  nominee_percentage_0: number;

  @IsString()
  @Matches(/^([A-Za-z ]){1,40}$/, {
    message: 'Invalid Nominee Name format',
  })
  @IsOptional()
  @ApiProperty()
  nominee_name_1: string;

  @IsEnum(NomineeRelationship)
  @IsOptional()
  @ApiProperty()
  nominee_relationship_1?: NomineeRelationship;

  @Matches(/^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/, {
    message: 'Invalid Nominee dob format',
  })
  @IsOptional()
  @ApiProperty()
  nominee_dob_1?: string;

  @IsEnum(NomineeIdType)
  @IsOptional()
  @ApiProperty()
  nominee_idtype_1: NomineeIdType;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_idnumber_1: string;

  @Matches(/^([\d]){10}$/)
  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_cphone_1: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_cemail_1: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_caline_1: string;

  @Matches(/^([\d]){10}$/)
  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_capincode_1: string;

  @IsEnum(CountryCode)
  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_cacountry_1: CountryCode;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_guardian_name_1: string;

  @IsEnum(NomineeIdType)
  @IsOptional()
  @ApiProperty()
  nominee_gidtype_1: NomineeIdType;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_gidnumber_1: string;

  @IsEmail()
  @IsOptional()
  @ApiProperty()
  nominee_gcemail_1: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_gcaline_1: string;

  @IsNumber()
  @IsOptional()
  @ApiProperty()
  nominee_gcapincode_1: number;

  @IsEnum(CountryCode)
  @IsOptional()
  @ApiProperty()
  nominee_gcacountry_1: CountryCode;

  @IsNumber()
  @IsOptional()
  @ApiProperty()
  nominee_percentage_1: number;

  @IsString()
  @Matches(/^([A-Za-z ]){1,40}$/, {
    message: 'Invalid Nominee Name format',
  })
  @IsOptional()
  @ApiProperty()
  nominee_name_2: string;

  @IsEnum(NomineeRelationship)
  @IsOptional()
  @ApiProperty()
  nominee_relationship_2?: NomineeRelationship;

  @Matches(/^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/, {
    message: 'Invalid Nominee dob format',
  })
  @IsOptional()
  @ApiProperty()
  nominee_dob_2?: string;

  @IsEnum(NomineeIdType)
  @IsOptional()
  @ApiProperty()
  nominee_idtype_2: NomineeIdType;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_idnumber_2: string;

  @Matches(/^([\d]){10}$/)
  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_cphone_2: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_cemail_2: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_caline_2: string;

  @Matches(/^([\d]){10}$/)
  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_capincode_2: string;

  @IsEnum(CountryCode)
  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_cacountry_2: CountryCode;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_guardian_name_2: string;

  @IsEnum(NomineeIdType)
  @IsOptional()
  @ApiProperty()
  nominee_gidtype_2: NomineeIdType;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_gidnumber_2: string;

  @IsEmail()
  @IsOptional()
  @ApiProperty()
  nominee_gcemail_2: string;

  @IsString()
  @IsOptional()
  @ApiProperty()
  nominee_gcaline_2: string;

  @IsNumber()
  @IsOptional()
  @ApiProperty()
  nominee_gcapincode_2: number;

  @IsEnum(CountryCode)
  @IsOptional()
  @ApiProperty()
  nominee_gcacountry_2: CountryCode;

  @IsNumber()
  @IsOptional()
  @ApiProperty()
  nominee_percentage_2: number;

  @IsEnum(NomineeDisplayOption)
  @IsOptional()
  @ApiProperty()
  nomination_display_setting: NomineeDisplayOption;

  // @Length(10, 10)
  // pan: string;

  // @MaxLength(70)
  // @Matches(/^[a-zA-Z\s]+$/, { message: 'Investor name must not contain special characters' })
  // investorName: string;

  // @IsEnum(['Male', 'Female', 'Transgender'])
  // gender: string;

  // @IsOptional()
  // @MaxLength(70)
  // @Matches(/^[a-zA-Z\s]+$/, { message: 'Father name must not contain special characters' })
  // fatherName?: string;

  // @IsOptional()
  // @MaxLength(70)
  // @Matches(/^[a-zA-Z\s]+$/, { message: 'Spouse name must not contain special characters' })
  // spouseName?: string;

  // @MaxLength(70)
  // @Matches(/^[a-zA-Z\s]+$/, { message: 'Mother name must not contain special characters' })
  // motherName: string;

  // @IsEnum(['Married', 'Unmarried'])
  // maritalStatus: string;

  // @Length(4, 4)
  // @IsNumberString()
  // aadhaarLast4Digits: string;

  // @IsString()
  // nationality: string;

  // @IsString()
  // citizenship: string;

  // @IsString()
  // signatureUrl: string;

  // @IsString()
  // geoLatitude: string;

  // @IsString()
  // geoLongitude: string;

  // @IsIn(['Business', 'Professional', 'Retired', 'Housewife', 'Student', 'Public Sector Service', 'Private Sector Service', 'Government Service', 'Agriculture', 'Doctor', 'Forex Dealer', 'Service', 'Others'])
  // occupation: string;

  // @IsIn(['Salary', 'Business', 'Gift', 'Ancestral Property', 'Rental Income', 'Prize Money', 'Royalty', 'Others'])
  // sourceOfWealth: string;

  // @IsIn(['Below 1L', '1L to 5L', '5L to 10L', '10L to 25L', '25L to 1Cr', 'Above 1Cr'])
  // annualIncome: string;

  // @IsString()
  // countryOfBirth: string;

  // @IsString()
  // @MaxLength(60)
  // placeOfBirth: string;

  // @IsIn(['No exposure', 'Politically Exposed', 'Related to a Politically Exposed Person'])
  // politicalExposure: string;

  // @IsIn(['Resident'])
  // taxResidencyStatus: string;

  // @IsString()
  // addressLine: string;

  // @Length(6, 6)
  // @IsNumberString()
  // pincode: string;

  // @IsString()
  // country: string;

  // @IsIn(['Residential', 'Business Location', 'Registered Office'])
  // addressNature: string;

  // @Length(10, 10)
  // @IsNumberString()
  // phoneNumber: string;

  // @IsIn(['Self', 'Spouse', 'Dependent Children', 'Dependent Siblings', 'Dependent Parents', 'Guardian', 'PMS', 'Custodian', 'POA'])
  // phoneBelongsTo: string;

  // @IsEmail()
  // email: string;

  // @IsIn(['Self', 'Spouse', 'Dependent Children', 'Dependent Siblings', 'Dependent Parents', 'Guardian', 'PMS', 'Custodian', 'POA'])
  // emailBelongsTo: string;

  // @Length(9, 18)
  // @IsNumberString()
  // bankAccountNumber: string;

  // @MaxLength(70)
  // @Matches(/^[a-zA-Z\s]+$/, { message: 'Holder name must not contain special characters' })
  // primaryHolderName: string;

  // @Matches(/^[A-Z]{4}0[A-Z0-9]{6}$/)
  // ifscCode: string;

  // @IsIn(['Savings'])
  // accountType: string;

  // // Nominee Fields
  // @IsOptional()
  // @MaxLength(40)
  // nomineeName?: string;

  // @IsOptional()
  // @Matches(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, { message: 'Invalid PAN format' })
  // nomineePAN?: string;

  // @IsOptional()
  // @IsDateString()
  // nomineeDOB?: string;

  // @IsOptional()
  // nomineeRelationship?: string;

  // @IsOptional()
  // @MaxLength(35)
  // @Matches(/^[a-zA-Z\s]*$/, { message: 'Guardian name must not contain special characters' })
  // nomineeGuardianName?: string;

  // @IsOptional()
  // @Matches(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/, { message: 'Invalid PAN format' })
  // nomineeGuardianPAN?: string;

  // @IsOptional()
  // @Min(0)
  // @Max(100)
  // nomineeAllocationPercentage?: number;
}
