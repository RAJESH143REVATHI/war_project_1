import { AccountTypeEnum } from '@npstx/pg-entities';
import {
  IsEnum,
  IsNotEmpty,
  IsNumber,
  IsString,
  Matches,
} from 'class-validator';

export class BankDto {
  @IsNotEmpty({ message: 'user_id is Required' })
  @IsString({ message: 'user_id is must be a string' })
  user_id: string;

  @IsNotEmpty({ message: 'tenantId is Required' })
  @IsString({ message: 'Tenant is must be a string' })
  tenantId: string;

  @IsNotEmpty({ message: 'Account number Required' })
  @IsString({ message: 'Account number must be a string' })
  @Matches(/^\d{9,18}$/, {
    message: 'Account number must be a string with 9 to 18 digits',
  })
  pba_number: string;

  @IsNotEmpty({ message: 'Account Holder Required' })
  @IsString({ message: 'Account Holder must be String' })
  @Matches(/^([A-Za-z ]){1,70}$/, {
    message: 'Account Holder must contain only letters and spaces (max 70)',
  })
  pba_pname: string;

  @IsNotEmpty({ message: 'IFSC Code Required' })
  @IsString({ message: 'IFSC code must be String' })
  @Matches(/^[A-Z]{4}0[A-Z0-9]{6}$/, {
    message: 'IFSC Code must follow standard format (e.g., SBIN0001234)',
  })
  pba_code: string;

  @IsNotEmpty({ message: 'Account type Required' })
  @IsString({ message: 'Account type must be string' })
  // @IsEnum(AccountTypeEnum, {
  //   message: 'Account type must be saving or current',
  // })
  pba_type: AccountTypeEnum;
}
