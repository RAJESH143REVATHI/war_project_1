// import {
//   ExceptionFilter,
//   Catch,
//   ArgumentsHost,
//   BadRequestException,
//   ValidationError,
// } from '@nestjs/common';
// import { Response } from 'express';
// import { AofDto } from './dto/aof.dto'; // import your DTO

// @Catch(BadRequestException)
// export class DtoFirstErrorFilter implements ExceptionFilter {
//   catch(exception: BadRequestException, host: ArgumentsHost) {
//     const ctx = host.switchToHttp();
//     const response = ctx.getResponse<Response>();
//     const status = exception.getStatus();

//     const exceptionResponse = exception.getResponse();

//     // Check if exceptionResponse has the raw ValidationError objects:
//     // NestJS usually serializes them to an object, so this might not be straightforward.
//     // But if you enable `validationError: { target: true }` in ValidationPipe, you can get 'target' back.

//     // If you don't have raw ValidationErrors in the response,
//     // you might need to catch the exception earlier or customize the ValidationPipe

//     // Here's a simplified approach using the message array:
//     if (
//       typeof exceptionResponse === 'object' &&
//       'message' in exceptionResponse &&
//       Array.isArray(exceptionResponse.message)
//     ) {
//       // Here you can't directly get the DTO class from messages,
//       // so an alternative is to detect by request path or other context,
//       // or enable detailed errors with ValidationPipe (see below).

//       // For demo, let's just pick first message always (or add your own logic)
//       return response.status(status).json({
//         messageee: exceptionResponse.message[0],
       
//       });
//     }

//     return response.status(status).json(exceptionResponse);
//   }
// }
