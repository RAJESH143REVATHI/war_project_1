import { HttpException, Injectable, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClientProxy } from '@nestjs/microservices';
import { UserDto } from 'src/auth/dto/user.dto';
import { RmqService } from 'src/shared/rmq.service';
import { CreateTransactionDto } from 'src/gateway/transaction/dto/create-transaction.dto';
import { CreateSipDto } from '../sip/dto/create-sip.dto';
import { catchError, firstValueFrom, of, retry } from 'rxjs';
import { RmqWrapperService } from 'src/shared/rmq-wrapper.service';

@Injectable()
export class UserService implements OnModuleInit {
  private client: ClientProxy;

  constructor(
    private readonly configService: ConfigService,
    private readonly rmqService: RmqService,
    private readonly rmqWrapper: RmqWrapperService
  ) { }

  onModuleInit() {
    let queue = this.configService.get<string>('rabbitmq.queues.userService');
    this.client = this.rmqService.createClient(queue);
  }


  async sendMessage(pattern: string, data: any) {
    console.log("🚀 ~ UserService ~ sendMessage ~ data:", data)
    if (!this.client) {
      throw new Error('RabbitMQ client not initialized.');
    }


    return await firstValueFrom(
      this.client.send({ cmd: pattern }, data).pipe(
        retry(1), // Retry 2 more times if needed
        catchError(err => {
          console.error('❌ Failed to send RMQ message:', err);
          return of({ error: err.message });
        })
      )
    );
  }

  //aof
  

  createUpdateUser(pattern: string, data: UserDto) {
    return this.client.send(pattern, data);
  }

  showOverallPortfolio(createTransactionDto: CreateTransactionDto) {
    return 'This action displays the overall user portfolio';
  }

  userHoldingDetail(createTransactionDto: CreateTransactionDto) {
    return "This action fetches the user's holding details";
  }


  fetchSipList(createSipDto: CreateSipDto) {
    return 'This action adds a new sip';
  }

  cancelSIP(createSipDto: CreateSipDto) {
    return `This action returns all sip`;
  }


  fetchBanks(createTransactionDto: CreateTransactionDto) {
    return 'This action fetches the list of available banks';
  }
  redeemFund(createTransactionDto: CreateTransactionDto) {
    return 'This action initiates fund redemption';
  }

  transactionList(createTransactionDto: CreateTransactionDto) {
    return 'This action fetches the transaction list';
  }

  paymentStatus(createTransactionDto: CreateTransactionDto) {
    return 'This action checks the payment status of a transaction';
  }
}
