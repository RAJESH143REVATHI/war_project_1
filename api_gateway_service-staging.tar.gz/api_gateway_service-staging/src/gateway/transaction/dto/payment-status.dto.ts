import { IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class PaymentStatusDto {
  @ApiProperty({ description: 'Order id ' })
  @IsOptional()
  @IsString()
  orderId: string;

  @ApiProperty({ description: 'Transaction Id ' })
  @IsOptional()
  @IsString()
  txnId: string;

}
