import { Module } from "@nestjs/common";
import { RmqService } from "src/shared/rmq.service";
import { CatalogService } from "./catalog.service";
import { CatalogController } from "./catalog.controller";
import { MongooseModule } from "@nestjs/mongoose";
import { AmcCollection, AmcCollectionSchema } from "src/schemas/amc-collection.schema";
import { Fund, FundSchema } from "src/schemas/fund.schema";
import { ExpressAdapter } from "@nestjs/platform-express";
import { RmqWrapperService } from "src/shared/rmq-wrapper.service";

@Module({
    imports:[

         MongooseModule.forFeature([
              { name: Fund.name, schema: FundSchema },
              { name: AmcCollection.name, schema: AmcCollectionSchema },
            ]),
    ],
    controllers:[CatalogController],
    providers:[RmqService,CatalogService,ExpressAdapter,RmqWrapperService]
})
export class CatalogModule{}