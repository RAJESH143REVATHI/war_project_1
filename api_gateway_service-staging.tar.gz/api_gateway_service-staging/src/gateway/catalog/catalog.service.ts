import { Injectable, OnModuleInit } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClientProxy } from '@nestjs/microservices';
import { RmqService } from 'src/shared/rmq.service';
import { CreateDashboardDto } from '../dashboard/dto/create-dashboard.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Fund, FundDocument } from 'src/schemas/fund.schema';
import {
  AmcCollection,
  AmcCollectionDocument,
} from 'src/schemas/amc-collection.schema';
import { Model } from 'mongoose';
import { CreateMutualFundDto } from '../mutual-funds/dto/create-mutual-fund.dto';
import { RmqWrapperService } from 'src/shared/rmq-wrapper.service';
import { catchError, firstValueFrom, of, retry } from 'rxjs';

@Injectable()
export class CatalogService implements OnModuleInit {
  private client: ClientProxy;

  constructor(
    private readonly rmqService: RmqService,
    private readonly configService: ConfigService,
    private readonly rmqWrapper: RmqWrapperService,
    @InjectModel(Fund.name) private fundModel: Model<FundDocument>,
    @InjectModel(AmcCollection.name)
    private amcCollectionDocument: Model<AmcCollectionDocument>,
  ) { }

  async onModuleInit() {
    let queue = this.configService.get<string>(
      'rabbitmq.queues.catalogService',
    );
    this.client = this.rmqService.createClient(queue);
    await this.client.connect();
    // console.log("🚀 ~ CatalogService ~ onModuleInit ~ queue:", queue)
  }

  async sendMessage(pattern: string, data: any) {
    if (!this.client) {
      throw new Error('RabbitMQ client not initialized.');
    }


    return await firstValueFrom(
      this.client.send({ cmd: pattern }, data).pipe(
        retry(2), // Retry 2 more times if needed
        catchError(err => {
          console.error('❌ Failed to send RMQ message:', err.message);
          return of({ error: 'Failed to send message to RMQ' });
        })
      )
    );
  }

  async getCollection() {
    return {
      // amcCollectionModel: await this.amcCollectionModel.find(query).exec(),

      fundModel: await this.amcCollectionDocument.find().exec(),
    };
  }

  fetchPopularFund(createDashboardDto: CreateDashboardDto) {
    return 'This action fetches funds';
  }
  addToWatchlist(createDashboardDto: CreateDashboardDto) {
    return 'This action adds to watchlist';
  }
  removeFromWatchlist(createDashboardDto: CreateDashboardDto) {
    return 'This action removes from watchlist';
  }

  fetchWatchlist() {
    return 'This action fetches watchlist';
  }

  async getMutualFundList(pattern, query: any) {
    console.log(query);
    console.log('in gateway catalog')
    return this.client.send(pattern, query);
    // return {
    //   // amcCollectionModel: await this.amcCollectionModel.find(query).exec(),
    //   fundModel: await this.fundModel.find(query).exec(),
    // };
  }

  fetchMFDetail(createMutualFundDto: CreateMutualFundDto) {
    return 'This action fetches mutual fund details';
  }
}
