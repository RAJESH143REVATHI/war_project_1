{
   [
    {
      "name": "SIP with ₹100",
      "value": 'amount=100',
      "image": "https://example.com/images/sip_100.png"
    },
    {
      "name": "SIP with ₹500",
      "value": 'amount=500',
      "image": "https://example.com/images/sip_500.png"
    },
    {
      "name": "Large cap",
      "value": 'category=large cap',
      "image": "https://example.com/images/sip_1000.png"
    },
    {
      "name": "Mid cap",
      "value": 'category=mid cap',
      "image": "https://example.com/images/sip_2000.png"
    },
    {
      "name": "Small cap",
      "value": 'category=small cap',
      "image": "https://example.com/images/sip_2000.png"
    },
    {
      "name": "Low Risk",
      "value": 'risk=low risk',
      "image": "https://example.com/images/sip_2000.png"
    },
    {
      "name": "High return",
      "value": 'returns=high return',
      "image": "https://example.com/images/sip_2000.png"
    },
    {
      "name": "Tax Saving",
      "value": 'category=tax saving',
      "image": "https://example.com/images/sip_2000.png"
    }
  ]
}