// catalog-message-pattern.ts

export enum HttpMethod {
    GET = 'get',
    POST = 'post',
    PUT = 'put',
    DELETE = 'delete',
}

export enum MessagePatternStr {
    GET_CATALOG = 'GET_CATALOG',
    CREATE_CATALOG = 'CREATE_CATALOG',
    UPDATE_CATALOG = 'UPDATE_CATALOG',
    PING_CATALOG = 'PING_CATALOG',
    GET_ONDCFUNDDATA = 'GET_ONDCFUNDDATA',
    GET_TOPCOLLECTION= 'GET_TOPCOLLECTION',
    GET_RISKLIST= 'GET_RISKLIST',
    GET_SORTLIST= 'GET_SORTLIST',
    GET_AMCLIST= 'GET_AMCLIST',
    GET_POPULARFUND= 'GET_POPULARFUND',
    GET_HOLDINGDATA = 'GET_HOLDINGDATA',

    GET_CATOGERY='GET_CATOGERY'
}

export interface CatalogRouteConfig {
    method: HttpMethod;
    path: string;
    pattern: string;
}

export const CatalogMessagePatterns: CatalogRouteConfig[] = [
    {
        method: HttpMethod.GET,
        path: 'get_catalog',
        pattern: 'get_catalog',
    },
    {
        method: HttpMethod.POST,
        path: 'create_catalog',
        pattern: 'create_catalog',
    },
    {
        method: HttpMethod.PUT,
        path: 'update_catalog',
        pattern: 'update_catalog',
    },
    {
        method: HttpMethod.GET,
        path: 'ping',
        pattern: 'ping_catalog',
    },

];
