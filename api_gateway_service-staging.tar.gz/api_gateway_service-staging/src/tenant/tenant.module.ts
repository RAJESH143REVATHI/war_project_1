import { Global, Module } from "@nestjs/common";
import { TenantService } from "./tenant.service";
import { TenantConfig, TenantConfigSchema } from "./tenantConfig.schema";
import { MongooseModule } from "@nestjs/mongoose";
import { TenantController } from "./tenant.controller";

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: TenantConfig.name, schema: TenantConfigSchema },
    ]),
  ],
  controllers: [TenantController],
  providers: [TenantService],
  exports: [TenantService]
})
export class TenantModule {}
