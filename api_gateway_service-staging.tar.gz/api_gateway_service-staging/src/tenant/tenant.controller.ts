import {
  Body,
  Controller,
  HttpException,
  HttpStatus,
  Post,
  Req,
  Res,
} from '@nestjs/common';
import { TenantService } from './tenant.service';

import { Public } from 'src/decorators/public.decorator';
import { Response, Request } from 'express';
import { TenantDto } from './tenant.dto';

@Controller('tenant')
export class TenantController {
  constructor(private readonly tenantService: TenantService) {}

  @Public()
  @Post('createTenant')
  async createTenant(
    @Req() req: Request,
    @Body() body: TenantDto,
    @Res() res: Response,
  ) {
    try {
      const tenant = await this.tenantService.createTenant(body);
      return res.status(201).json({
        success: true,
        data: tenant,
      });
    } catch (error) {
      console.error('Error creating tenant:', error);
      throw new HttpException(
        {
          success: false,
          message: error.message || 'Failed to create tenant',
        },
        error.status || HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Public()
  @Post('getConfigByTenant')
  async getConfigByTenant(
    @Req() req: Request,
    @Body() body: { tenant_id: string },
    @Res() res: Response,
  ){
    try {
      const tenant = await this.tenantService.getConfigByTenant(body.tenant_id);
      return res.status(201).json({
        success: true,
        data: tenant,
      });
    } catch (error) {
      console.error('Error creating tenant:', error);
      throw new HttpException(
        {
          success: false,
          message: error.message || 'Failed to create tenant',
        },
        error.status || HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Public()
  @Post('getTenantConnection')
  async getTenantConnection(@Req() req: Request, @Body() body: { tenant_id: string }, @Res() res: Response){
    try {
      const tenant = await this.tenantService.getTenantConnection(body.tenant_id);
      return res.status(201).json({
        success: true,
        data: tenant,
      });
    } catch (error) {
      console.error('Error creating tenant:', error);
      throw new HttpException(
        {
          success: false,
          message: error.message || 'Failed to create tenant',
        },
        error.status || HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
