import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
  UseGuards, Request,
  Req,
  Res
} from '@nestjs/common';
import { AuthService } from './auth.service';
import { CreateAuthDto } from './dto/create-auth.dto';
import { UpdateAuthDto } from './dto/update-auth.dto';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { UserDto } from './dto/user.dto';
import { AuthGuard } from '@nestjs/passport';
import { Public } from 'src/decorators/public.decorator';

@ApiTags('Auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) { }

  @Post('authUser')
  @ApiOperation({ summary: 'Authenticate a user' })
  @ApiResponse({ status: 200, description: 'User authenticated successfully' })
  @ApiBody({ type: CreateAuthDto })
  authenticate(@Body() createAuthDto: CreateAuthDto) {
    return this.authService.authenticate(createAuthDto);
  }

  @Post('verifyTenent')
  @ApiOperation({ summary: 'Verify tenent' })
  @ApiResponse({ status: 200, description: 'Tenent Verified successfully' })
  @ApiBody({ type: UserDto })
  async verifyTenent(@Body() userDto: UserDto) {
    const data = await this.authService.verifyTenent(userDto);
    console.log("userDto", JSON.stringify(data, null, 2));
    return data;
  }

  @Post('getConfig')
  @ApiOperation({ summary: 'Get app configuration' })
  @ApiResponse({ status: 200, description: 'Config received successfully' })
  @UseGuards(AuthGuard('jwt'))
  @Post('getConfig')
  async test(@Request() req, @Body() body: any) {
    return this.authService.getConfig(req.user);
    // return {
    //   message: 'Decoded JWT Data',
    //   data: req.user, // this contains full JWT payload
    //   body: body
    // };
  }


  // @Post('getConfig')
  // @ApiOperation({ summary: 'Get app configuration' })
  // @ApiResponse({ status: 200, description: 'Config received successfully' })
  // @ApiBody({ type: CreateAuthDto })
  // getGlobalConfig(@Body() createAuthDto: CreateAuthDto) {
  //   return this.authService.authenticate(createAuthDto);
  // }

  @Public()
  @Post('validateTenant')
  validateTenant(@Req() req: any, @Res()res:any) {

      let data = {
          tenant: {
              tenant_id: req.body.tenant_id,
              tenant_pass_key: req.body.tenant_pass_key,
              tenant_name: req.body.tenant_name,
          },
          user: {
              user_mobile: req.body.user_mobile,
              fcm_id: req.body.fcm_key,
              device_id: req.body.device_id,
              device_type: req.body.device_type,
              device_os: req.body.device_os,
          }
      }

      console.log(req.body);
      // Check Tenant Exist or not?

      //IF No -: Return Invalid Tenant
      // IF YES -: 
          // Check User Exist or not?
          // IF No -: Query Tenant for User validation or validate user with otp
          // IF Yes -: Create JWT Token and Send to User


  }

}
