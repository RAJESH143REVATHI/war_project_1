import { Injectable } from '@nestjs/common';
import { CreateAuthDto } from './dto/create-auth.dto';
import { InjectModel } from '@nestjs/mongoose';

import { Model } from 'mongoose';

import { UserDto } from './dto/user.dto';
import { UserService } from 'src/gateway/user-service/user-service.service';

import { firstValueFrom } from 'rxjs';
import { JwtService } from '@nestjs/jwt';
import {
  TenantConfig,
  TenantConfigDocument,
} from 'src/tenant/tenantConfig.schema';

@Injectable()
export class AuthService {
  constructor(
    private readonly jwtService: JwtService,
    private readonly userService: UserService,
    @InjectModel(TenantConfig.name)
    private tenentConfigModel: Model<TenantConfigDocument>,
  ) {}

  async login(username: string, password: string): Promise<any> {}
  authenticate(createAuthDto: CreateAuthDto) {
    return 'This action adds a new auth';
  }

  async verifyTenent(userDto: UserDto) {
    const configData = await this.tenentConfigModel
      .findOne({ tenant_id: userDto.source })
      .exec();
    console.log('Actual userDetails:', JSON.stringify(configData, null, 2));

    console.log(configData);

    if (configData! && configData?.tenant_id) {
      const userDetailsG = await firstValueFrom(
        this.userService.createUpdateUser('createUpdateUser', userDto),
      );

      console.log('Actual userDetails:', JSON.stringify(userDetailsG, null, 2));
      const token = this.jwtService.sign(userDetailsG);

      return token;
    } else {
      return 'No source found';
    }
  }

  async getConfig(user: any) {
    const configData = await this.tenentConfigModel
      .findOne({ tenant_id: user.source })
      .exec();
    console.log('userdata', user.source);
    if (configData?.tenant_id) {
      const filteredData = {
        ThemeConfig: configData?.layout,
      };
      return { configModel: filteredData };
    } else {
      return 'No source found';
    }
  }
}
