import {
    IsString,
    IsNotEmpty,
    IsOptional,
    IsObject,
    ValidateNested,
    IsBoolean,
  } from 'class-validator';
  import { Type } from 'class-transformer';
  
  // DTO for DbCredentials
  export class DbCredentialsDto {
    @IsString()
    @IsNotEmpty()
    host: string;
  
    @IsString()
    @IsNotEmpty()
    port: string;
  
    @IsString()
    @IsNotEmpty()
    username: string;
  
    @IsString()
    @IsNotEmpty()
    password: string;
  
    @IsString()
    @IsNotEmpty()
    dbName: string;
  }
  
  // DTO for Integrations
  export class IntegrationsDto {
    @IsOptional()
    @IsString()
    paymentGateway?: string;
  
    @IsOptional()
    @IsString()
    notificationService?: string;
  }
  
  // Main DTO
  export class TenantDto {
    tenant_id?: string;
  
    @IsString()
    @IsNotEmpty()
    tenant_name: string;

    @IsString()
    @IsNotEmpty()
    tenant_pass_key: string;
  
    @IsOptional()
    @IsObject()
    layout?: Record<string, any>;
  
    @ValidateNested()
    @Type(() => DbCredentialsDto)
    dbCredentials: DbCredentialsDto;
  
    @IsOptional()
    @IsObject()
    featureFlags?: Record<string, boolean>;
  
    @IsOptional()
    @ValidateNested()
    @Type(() => IntegrationsDto)
    integrations?: IntegrationsDto;
  }
  