import { Global, Module } from "@nestjs/common";
import { TenantService } from "./tenant.service";
import { TenantConfig, TenantConfigSchema } from "./tenantConfig.schema";
import { MongooseModule } from "@nestjs/mongoose";

@Global()
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: TenantConfig.name, schema: TenantConfigSchema },
    ]),
  ],
  controllers: [],
  providers: [TenantService],
  exports: [TenantService]
})
export class TenantModule {}
