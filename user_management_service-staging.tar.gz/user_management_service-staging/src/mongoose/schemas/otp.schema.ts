import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type OtpDocument = Otp & Document;

@Schema({ timestamps: true })
export class Otp {
  @Prop({ required: true })
  mobile: number;

  @Prop({ required: true })
  otp: string;

  @Prop({ required: true })
  expiresAt: number;

  @Prop({ default: 0 })
  tries: number;

  @Prop({default:'generated',required:true})
  status: string;
 
}

export const OtpSchema = SchemaFactory.createForClass(Otp);
