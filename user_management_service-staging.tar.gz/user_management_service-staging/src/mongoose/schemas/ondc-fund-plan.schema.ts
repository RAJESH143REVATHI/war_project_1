import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type OndcFundPlanDocument = OndcFundPlan & Document;

@Schema({ timestamps: true })
export class OndcFundPlan {
  @Prop({ required: true })
  providerID: string;

  @Prop({ required: true })
  providerName: string;

  @Prop()
  schemeID: string;

  @Prop()
  schemeName: string;

  @Prop({ required: true })
  planID: string;

  @Prop({ required: true })
  planName: string;

  @Prop()
  isin: string;

  @Prop()
  rtaIdentifier: string;

  @Prop()
  amfiIdentifier: string;

  @Prop()
  plan: string;

  @Prop()
  option: string;

  @Prop()
  idcwOption: string;

  @Prop()
  planType: string;

  @Prop()
  bppId: string;

  @Prop()
  bppUri: string;

  @Prop([
    {
      type: {
        fId: { type: String, required: true },
        ftype: { type: String, required: true },
        AMOUNT_MIN: { type: String },
        AMOUNT_MULTIPLES: { type: String },
        ADDITIONAL_AMOUNT_MIN: { type: String },
        ADDITIONAL_AMOUNT_MULTIPLES: { type: String },
        UNITS_MIN: { type: String },
        UNITS_MAX: { type: String },
        UNITS_MULTIPLES: { type: String },
        FREQUENCY: { type: String },
        FREQUENCY_DATES: { type: String },
        AMOUNT_MAX: { type: String },
        INSTALMENTS_COUNT_MIN: { type: String },
        INSTALMENTS_COUNT_MAX: { type: String },
      },
    },
  ])
  fullfillments: Array<Record<string, any>>;

  @Prop()
  'Lumpsum Fulfillment ID': string;

  @Prop()
  'Redemption Fulfillment ID': string;

  @Prop()
  'SIP Fulfillment ID (1)': string;
}

export const OndcFundPlanSchema = SchemaFactory.createForClass(OndcFundPlan);
