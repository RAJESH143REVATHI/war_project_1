// src/common/services/tenant-aware-repository.service.ts
import { Injectable } from '@nestjs/common';
import { Repository, ObjectLiteral, DeepPartial, FindOptionsWhere, DataSource,EntityManager } from 'typeorm';
import { TenantService } from 'src/tenant/tenant.service';
import { QueryDeepPartialEntity } from 'typeorm/query-builder/QueryPartialEntity';

@Injectable()
export class TenantAwareRepositoryService {
  constructor(private readonly tenantService: TenantService) {}

  private async getDataSource(tenantId: string): Promise<DataSource> {
    return this.tenantService.getTenantConnection(tenantId);
  }

  private async getRepository<T extends ObjectLiteral>(
    tenantId: string,
    entity: new () => T,
  ): Promise<Repository<T>> {
    
    const dataSource = await this.tenantService.getTenantConnection(tenantId);
    // return dataSource
    return dataSource.getRepository(entity);
  }

  async findAll<T extends ObjectLiteral>(tenantId: string, entity: new () => T): Promise<T[]> {
    const repo = await this.getRepository(tenantId, entity);
    return repo.find();
  }

  async findOne<T extends ObjectLiteral>(
    tenantId: string,
    entity: new () => T,
    where: FindOptionsWhere<T>,
  ): Promise<T | null> {
    const repo = await this.getRepository(tenantId, entity);
    return repo.findOne({ where });
  }

  async create<T extends ObjectLiteral>(
    tenantId: string,
    entity: new () => T,
    data: DeepPartial<T>,
  ): Promise<T> {    
    const repo = await this.getRepository(tenantId, entity);
    const created = repo.create(data);
    return repo.save(created);
  }

  async update<T extends ObjectLiteral>(
    tenantId: string,
    entity: new () => T,
    id: string,
    data: QueryDeepPartialEntity<T>,
  ): Promise<T | null> {
    const repo = await this.getRepository(tenantId, entity);
    await repo.update(id, data);
    return repo.findOne({ where: { id } as any });
  }

  async delete<T extends ObjectLiteral>(tenantId: string, entity: new () => T, id: number): Promise<void> {
    const repo = await this.getRepository(tenantId, entity);
    await repo.delete(id);
  }

  async runQuery<T = any>(
    tenantId: string,
    query: string,
    parameters?: any[],
  ): Promise<T[]> {
    const dataSource = await this.getDataSource(tenantId);
    return dataSource.query(query, parameters);
  }

  async transaction<T>(
    tenantId: string,
    runInTransaction: (manager: EntityManager) => Promise<T>,
  ): Promise<T> {
    const dataSource = await this.getDataSource(tenantId);
    return dataSource.transaction(runInTransaction);
  }
}
