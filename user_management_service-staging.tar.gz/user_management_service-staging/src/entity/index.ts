// import { OrderEntity } from "./order.entity";
// import { PaymentEntity } from "./payment.entity";
// import { UserAofEntity } from "./user.aof.entity";
// import { UserEntity } from "./user.entity";

// export const entities = [
//     UserEntity,
//     UserAofEntity,
//     OrderEntity,
//     PaymentEntity
// ]