// import {
//   Entity,
//   PrimaryGeneratedColumn,
//   Column,
//   CreateDateColumn,
//   UpdateDateColumn,
//   ManyToOne,
//   JoinColumn,
//   OneToMany,
// } from 'typeorm';
// import { UserEntity } from './user.entity';
// import { PaymentEntity } from './payment.entity';
// // import { OrderStatus } from 'src/order/order-status.enum';

 

// export enum OrderStatus {
//   CREATED = 'created',
//   SELECT_REQUESTED = 'select_requested',
//   ON_SELECT_RECEIVED = 'on_select_received',
//   ON_SELECT_RECEIVED_ERROR = 'on_select_received_error',
 
//   AOF_PENDING = 'aof_pending',
//   AOF_ERROR = 'aof_error',
//   AOF_SUBMITTED = 'aof_submitted',
//   AOF_SELECT_REQUESTED = 'aof_select_requested',
//   AOF_SELECT_RECEIVED = 'aof_select_received',
//   AOF_SELECT_RECEIVED_ERROR = 'aof_select_received_error',
 
//   KYC_PENDING = 'kyc_pending',
//   KYC_SUBMITTED = 'kyc_submitted',
//   KYC_SELECT_REQUESTED = 'kyc_select_requested',
//   KYC_SELECT_RECEIVED = 'kyc_select_received',
//   KYC_SELECT_RECEIVED_ERROR = 'kyc_select_received_error',
 
//   ESIGN_PENDING = 'esign_pending',
//   ESIGN_SUBMITTED = 'esign_submitted',
//   ESIGN_SELECT_REQUESTED = 'esign_select_requested',
//   ESIGN_SELECT_RECEIVED = 'esign_select_received',
//   ESIGN_SELECT_RECEIVED_ERROR = 'esign_select_received_error',
 
//   PAYMENT_OPTIONS_RESIVED = 'payment_options_resived',
//   PAYMENT_OPTION_SELECTED = 'payment_option_selected',
 
//   INIT_SENT = 'init_sent',
//   INIT_FAILED = 'init_failed',
//   ON_INIT_RECEIVED = 'on_init_received',
 
//   CONFIRM_SENT = 'confirm_sent',
//   CONFIRM_FAILED = 'confirm_failed',
//   ON_CONFIRM_RECEIVED = 'on_confirm_received',
//   ON_CONFIRM_RECEIVED_ERROR = 'on_confirm_received_error',
 
//   PAID = 'paid',
 
//   COMPLETE = 'complete',
//   FAILED = 'failed',
// }


// @Entity('orders')
// export class OrderEntity {
//   @PrimaryGeneratedColumn('uuid')
//   id: string;
 
//   @Column()
//   user_id: string;
 
//   @ManyToOne(() => UserEntity, (user) => user.orders, { onDelete: 'CASCADE' })
//   @JoinColumn({ name: 'user_id' })
//   user: UserEntity;
 
//   @OneToMany(() => PaymentEntity, (payment) => payment.order)
//   payments: PaymentEntity[];
 
//   @Column()
//   transaction_id: string;
 
//   @Column()
//   bap_order_id: string;
 
//   @Column({ nullable: true })
//   bpp_order_id: string;
 
//   @Column()
//   bap_id: string;
 
//   @Column()
//   bap_uri: string;
 
//   @Column({ nullable: true })
//   bpp_id: string;
 
//   @Column({ nullable: true })
//   bpp_uri: string;
 
//   @Column({
//     type: 'enum',
//     enum: OrderStatus,
//     default: OrderStatus.CREATED,
//   })
//   status: OrderStatus;
 
//   @Column({ nullable: true  })
//   order_status: string;
 
//   @Column({
//     nullable: true,
//     enum: [
//       'N/A',
//       'AOF_SUBMITTED',
//       'AOF_FAILED',
//     ],
//     default: 'N/A',
//   })
//   aof_status: 'N/A' | 'AOF_SUBMITTED' | 'AOF_FAILED';
 
//   @Column({ type: 'jsonb', nullable: true })
//   aof_response: any;
 
//   @Column({ nullable: true })
//   aof_error: string;
 
//   @Column({ type: 'jsonb', nullable: true })
//   kyc_response: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   esign_response: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   on_status_kyc_payload: any
 
//   @Column({ type: 'jsonb', nullable: true })
//   on_status_esign_payload: any
 
//   @Column({
//     type: 'enum',
//     enum: ['LUMPSUM', 'SIP'],
//     default: 'LUMPSUM',
//   })
//   investment_type: 'LUMPSUM' | 'SIP';
 
//   @Column({ type: 'decimal', precision: 10, scale: 2 })
//   amount: number;
 
//   // SIP-specific fields (optional for Lumpsum)
//   @Column({ type: 'date', nullable: true })
//   sip_start_date: Date;
 
//   @Column({ type: 'enum', enum: ['MONTHLY', 'QUARTERLY'], nullable: true })
//   sip_frequency: 'MONTHLY' | 'QUARTERLY';
 
//   @Column({ type: 'int', nullable: true })
//   sip_duration_months: number;
 
//   @Column({ type: 'enum', enum: ['ACTIVE', 'PAUSED', 'CANCELLED'], nullable: true })
//   sip_status: 'ACTIVE' | 'PAUSED' | 'CANCELLED';
 
//   @Column({ type: 'jsonb', nullable: true })
//   select_context: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   aof_select_context: any
 
//   @Column({ type: 'jsonb', nullable: true })
//   aof_form: any
 
//   @Column({ type: 'jsonb', nullable: true })
//   aof_select_payload: any
 
//   @Column({ type: 'jsonb', nullable: true })
//   kyc_select_context: any
 
//   @Column({ type: 'jsonb', nullable: true })
//   kyc_select_payload: any
 
//   @Column({ type: 'jsonb', nullable: true })
//   esign_select_context: any
 
//   @Column({ type: 'jsonb', nullable: true })
//   esign_select_payload: any
 
//   @Column({ type: 'boolean', default: false })
//   user_action_required: boolean
 
//   @Column({ type: 'boolean', default: false })
//   hasError: any
 
//   @Column({ type: 'jsonb', nullable: true })
//   error_response: any
 
//   @Column({ type: 'jsonb', nullable: true })
//   init_context: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   confirm_context: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   on_select_payload: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   next_required_form: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   on_init_payload: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   on_confirm_payload: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   payments_options: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   selected_payment: any;
 
//   @Column({ type: 'jsonb', nullable: true })
//   on_status_payment_payload: any;
 
//   @Column({ type: 'date',nullable: true })
//   order_created_time: Date;
 
//   @Column({ type: 'date',nullable: true })
//   order_updated_time: Date;
 
//   @CreateDateColumn({ name: 'created_at' })
//   created_at: Date;
 
//   @UpdateDateColumn({ name: 'updated_at' })
//   updated_at: Date;
// }

