import { Controller } from '@nestjs/common';
import { UserService } from './user.service';
import { MessagePattern } from '@nestjs/microservices';
import { CreateUserDto } from './dto/user.dto';
import { AofDto } from './dto/user-aof.dto';
import { BankDto } from './dto/bank.dto';

@Controller()
export class UserController {
  constructor(private readonly userService: UserService) { }

  @MessagePattern('ping_user')
  async getUserPing() {
    return this.userService.responseToPing();
  }


  @MessagePattern({ cmd: 'create_user' })
  async createUser(payload: { tenantId: string, data: CreateUserDto }) {
    let tenantId = payload.tenantId
    console.log("🚀 ~ UserController ~ createUser ~ payload:", payload)
    return this.userService.createUser(tenantId, payload.data)
  }

  //get details
  @MessagePattern({ cmd: 'get_details' })
  async getUserDetails(data) {
    console.log("getUserDetails controller in service");
    return this.userService.getUserDetails(data.tenantId, data.data.mobile_number)
  }
  //aof
  @MessagePattern({ cmd: 'create_aof' })
  async createAof(payload: { tenantId: string, data: AofDto }) {

    let tenantId = payload.tenantId;
    return await this.userService.createAof(tenantId, payload.data)
  }

  //add bank 
  @MessagePattern({cmd:'add_bank'})
  async addBank(data:BankDto){
    return await this.userService.addBank(data)
  }

   //add bank 
  @MessagePattern({cmd:'get_bank_list'})
  async getBankList(payload){
    return await this.userService.getBankList(payload)
  }
}
