import {
  BadRequestException,
  ConflictException,
  Injectable,
  InternalServerErrorException,
  OnModuleInit,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { ClientProxy, RpcException } from '@nestjs/microservices';
import { RmqService } from 'src/shared/rmq.service';
import { TenantAwareRepositoryService } from 'src/shared/tenant-aware-repository.service';
import { CreateUserDto } from './dto/user.dto';
import { RpcError } from '@npst/nestjs-shared-utils';

import { DataSource, DataSourceOptions, Timestamp } from 'typeorm';
import { AofDto } from './dto/user-aof.dto';
import { ResponseConstructor } from 'src/res/response.constructor';
import { TenantService } from 'src/tenant/tenant.service';
import { JwtService } from '@nestjs/jwt';
import { AuthService } from 'src/auth/auth.service';
import { UserAofEntity, UserEntity, BankEntity } from '@npstx/pg-entities';
import { BankDto } from './dto/bank.dto';
import { mapSqlErrorCodeToResponseType } from 'src/res/error.codes';

@Injectable()
export class UserService implements OnModuleInit {
  private connections: Map<string, DataSource> = new Map();

  private client: ClientProxy;
  constructor(
    private readonly configService: ConfigService,
    private readonly rabbitMq: RmqService,
    private readonly tenantAwareRepoService: TenantAwareRepositoryService,
    private readonly tenantService: TenantService,
    private jwtService: JwtService,
    private readonly authService: AuthService,
  ) { }

  onModuleInit() {
    const queue = this.configService.get('rabbitmq.queue');
    this.client = this.rabbitMq.createClient(queue);
  }

  verifyTennt(tenentKey: string, mobile: string) {
    if (tenentKey === 'NP803STEmple' && mobile) {
      return { status: 'success' };
    } else {
      return 'tenentKey mismatch';
    }
  }

  // async createUpdateUser(data: any) {
  //     const dataSource = await this.getTenantConnection('');
  //     const userDto = await this.parseUserPayload(data);
  //     const repo = dataSource.getRepository(User);

  //     const existingUser = await repo.findOne({ where: { mobile_number: userDto.mobile.trim() }  });

  //     let user: User;

  //     if (existingUser) {
  //       // Update existing user
  //       existingUser.user_name = '';
  //       existingUser.device_number = userDto.deviceNumber;
  //       existingUser.os = userDto.OS;
  //       existingUser.fcm_token = userDto.FCM;
  //       existingUser.device_detail = userDto.deviceDetail;
  //       existingUser.updated_at = new Date();

  //       user = await repo.save(existingUser);
  //     } else {
  //       // Create new user
  //       const newUser = repo.create({
  //         user_name: '',
  //         tenant_id: userDto.source,
  //         mobile_number: userDto.mobile,
  //         device_number: userDto.deviceNumber,
  //         os: userDto.OS,
  //         fcm_token: userDto.FCM,
  //         device_detail: userDto.deviceDetail,
  //         created_at: new Date(),
  //         updated_at: new Date(),
  //       });

  //       user = await repo.save(newUser);
  //     }

  //     const result = { userId: user.id, ...data };
  //     console.log("User Details:", JSON.stringify(result, null, 2));

  //     return result;
  //   }

  // async createUpdateUser(data: any) {

  //     const dtSource = await this.getTenantConnection('');
  //     // console.log("Actual userDetails:", JSON.stringify(dtSource, null, 2));
  //     const userDto = await this.parseUserPayload(data);
  //     console.log('kkkkk', userDto.mobile)
  //     const repo = dtSource.getRepository(User);

  //     let user = await repo.findOne({ where: { mobile_number: userDto.mobile.trim() } });
  //     var userId = '';
  //     if (user) {
  //         // User exists - update record
  //         user.user_name = '';
  //         user.device_number = userDto.deviceNumber;
  //         user.os = userDto.OS;
  //         user.fcm_token = userDto.FCM;
  //         user.device_detail = userDto.deviceDetail;
  //         user.updated_at = new Date();

  //         const updatedUser = await repo.save(user);
  //         userId = updatedUser.id;
  //         //return { id: updatedUser.id };
  //     } else {
  //         // User doesn't exist - insert new record
  //         const newUser = repo.create({
  //             user_name: '',
  //             tenant_id: userDto.source,
  //             mobile_number: userDto.mobile,
  //             device_number: userDto.deviceNumber,
  //             os: userDto.OS,
  //             fcm_token: userDto.FCM,
  //             device_detail: userDto.deviceDetail,
  //             created_at: new Date(),
  //             updated_at: new Date(),
  //         });

  //         const insertedUser = await repo.save(newUser);
  //         userId = insertedUser.id;
  //         //return { id: insertedUser.id };
  //     }

  //     console.log("User Details:", JSON.stringify({userId: userId, ...data}, null, 2));
  //     return { userId: userId, ...data }

  // }

  // async parseUserPayload(data: any): Promise<UserDto> {
  //     const dtoObject = plainToInstance(UserDto, data);
  //     const errors = await validate(dtoObject);

  //     if (errors.length > 0) {
  //         throw new Error(`Validation failed: ${JSON.stringify(errors)}`);
  //     }

  //     return dtoObject;
  // }

  responseToPing() {
    return `
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to User Service</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
        }
        .container {
            text-align: center;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to User Service</h1>
        <p>Your request has been received successfully.</p>
    </div>
</body>
</html>
`;
  }

  async getUserDetails(tenantId: string, body) {
    console.log('getUserDetails service in service ,', body);
    try {
      const user = await this.tenantAwareRepoService.findOne(
        tenantId,
        UserEntity,
        { mobile_number: body },
      );
      console.log('user,', user, 'usertype ,', typeof user);
      if (user !== null && user !== undefined) {
        return new ResponseConstructor(user, 'success').compose();
      }
      return new ResponseConstructor('', 'not_found').compose();
    } catch (error) {
      let msg = await this.errorWrapper(error, tenantId, UserEntity);
      return new ResponseConstructor(
        msg,
        mapSqlErrorCodeToResponseType(error.code || error.driverError.code),
      ).compose();
    }
  }

  async createUser(tenantId: string, dto: CreateUserDto) {
    try {
      const user: any = await this.tenantAwareRepoService.findOne(
        tenantId,
        UserEntity,
        { mobile_number: dto.mobile_number },
      );
      if (!user) {
        const created_user: any = await this.tenantAwareRepoService.create(
          tenantId,
          UserEntity,
          dto,
        );
      
        return await this.authService.create(created_user);
      }
      if (user) {
        const updateUser = await this.tenantAwareRepoService.update(
          tenantId,
          UserEntity,
          user.id,
          {
            ip_address: dto.ip_address,
            latitude: dto.latitude,
            logitude: dto.logitude,
            fcm_token: dto.fcm_token,
            device_detail: dto.device_detail,
            device_id: dto.device_id
          }
        )
        console.log('kkUser last', user)
        return await this.authService.create(user);

      }

      // return new ResponseConstructor('', 'created').compose();
    } catch (error) {
      console.log('🚀 ~ UserService ~ createUser ~ error:', error);
      let msg = await this.errorWrapper(error, tenantId, UserEntity);
      return new ResponseConstructor(
        msg,
        mapSqlErrorCodeToResponseType(error.code || error.driverError.code),
      ).compose();
      // throw RpcError.handleError(error);
      // console.log("🚀 ~ UserService ~ createUser ~ error:", error)
      // const code = error?.code;
      // const detail = error?.detail || '';
      // if (code === '23505') {
      //   if (detail.includes('email')) {
      //     throw new RpcException(
      //       JSON.stringify({
      //         statusCode: 409,
      //         message: 'Email already exists',
      //       }),
      //     );
      //   }
      //   if (detail.includes('mobile_number')) {
      //     throw new RpcException(
      //       JSON.stringify({
      //         statusCode: 409,
      //         message: 'Mobile number already exists',
      //       }),
      //     );
      //   }
      //   throw new RpcException(
      //     JSON.stringify({ statusCode: 409, message: 'Duplicate entry' }),
      //   );
      // }

      // throw new RpcException(
      //   JSON.stringify({
      //     statusCode: 500,
      //     message: 'Unexpected error occurred',
      //   }),
      // );
    }
  }

  //aof
  async createAof(tenantId: string, dto: AofDto) {
    let currentEntity: any;
    try {
      let dataSource = await this.tenantService.getTenantConnection(tenantId);
      const queryRunner = dataSource.createQueryRunner();
      await queryRunner.connect();
      await queryRunner.startTransaction();
      currentEntity = UserAofEntity; // Track which entity we are working on
      const userAofEntity = queryRunner.manager.create(UserAofEntity, {
        ...dto,
        user: { id: dto.user_id },
      });
      const savedAof = await queryRunner.manager.save(
        UserAofEntity,
        userAofEntity,
      );

      // Update isAofCreated in User
      currentEntity = UserEntity;
      await queryRunner.manager.update(UserEntity, dto.user_id, {
        isAofCreated: true,
        pan: dto.pan,
      });

      // Add bank
      currentEntity = BankEntity;
      const bankEntity = queryRunner.manager.create(BankEntity, {
        user: { id: dto.user_id },
        pba_number: dto.pba_number,
        pba_pname: dto.pba_pname,
        pba_code: dto.pba_code,
        pba_type: dto.pba_type,
      });
      await queryRunner.manager.save(BankEntity, bankEntity);

      await queryRunner.commitTransaction();
      return new ResponseConstructor('', 'created').compose();
    } catch (error) {
      let msg = await this.errorWrapper(error, tenantId, currentEntity);
      return new ResponseConstructor(
        msg,
        mapSqlErrorCodeToResponseType(
          error?.code || error?.driverError?.code || error?.message || 'error',
        ),
      ).compose();
    }

    // let userEntity = new UserEntity();
    // userEntity.id = dto.user_id;
    // let userAofEntity = new UserAofEntity();
    // userAofEntity.user = userEntity as UserEntity;
    // try {
    //   const res = await this.tenantAwareRepoService
    //     .create(tenantId, UserAofEntity, dto)
    //     .then(async (res) => {
    //       console.log('first then ,', res, typeof res);

    //       if (res !== null && res !== undefined) {
    //         await this.tenantAwareRepoService.update(
    //           tenantId,
    //           UserEntity,
    //           res.user_id,
    //           { isAofCreated: true },
    //         );
    //         let data = {
    //           user_id: dto.user_id,
    //           tenantId: tenantId,
    //           pba_number: dto.pba_number,
    //           pba_pname: dto.pba_pname,
    //           pba_code: dto.pba_code,
    //           pba_type: dto.pba_type,
    //         };
    //         await this.addBank(data);
    //       }
    //     });
    //   return new ResponseConstructor('', 'created').compose();
    // } catch (error) {
    //   //   const constraints = await this.getConstrainst(tenantId);
    //   let msg = await this.errorWrapper(error, tenantId, UserAofEntity);
    //   return new ResponseConstructor(
    //     msg,
    //     mapSqlErrorCodeToResponseType(error.code || error.driverError.code),
    //   ).compose();
    // }
  }

  //add bank
  async addBank(data) {
    try {
      const bank = new BankEntity();
      bank.user = { id: data.user_id } as UserEntity;
      await this.tenantAwareRepoService.create(data.tenantId, BankEntity, data);
      return new ResponseConstructor('', 'created').compose();
    } catch (error) {
      let msg = await this.errorWrapper(error, data.tenantId, BankEntity);
      return new ResponseConstructor(
        msg,
        mapSqlErrorCodeToResponseType(error.code || error.driverError?.code),
      ).compose();
    }
  }

  //get banks
  async getBankList(payload) {
    try {
      const dataSource = await this.tenantService.getTenantConnection(
        payload.tenant_id,
      );
      const banks = await dataSource.getRepository(BankEntity).find({
        where: { user_id: payload.user_id },
      });
      return new ResponseConstructor(banks || [], 'created').compose();
    } catch (error) {
      console.log(error.message);
      let msg = await this.errorWrapper(error, payload.tenant_id, UserEntity);
      return new ResponseConstructor(
        msg,
        mapSqlErrorCodeToResponseType(error?.code || error.driverError?.code),
      ).compose();
    }
  }
  errorWrapper = async (error, tenant_id, entity) => {
    console.log('hooooo');

    if (error.driverError?.detail) {
      const detail = error.driverError.detail;
      const match = detail.match(/^Key \((\w+)\)=\((.+?)\) already exists\.$/);
      if (match) {
        const [, field, value] = match;
        return `${field.toUpperCase()} ${value} already exists.`;
      } else if (!match) {
        const fkMatch = detail.match(
          /^Key \((\w+)\)=\((.+?)\) is not present in table "(\w+)"\.$/,
        );
        if (fkMatch) {
          const [, field, value, table] = fkMatch;
          return `${field.toUpperCase()} ${value} not found in ${table.toUpperCase()} table.`;
        }
      }
    }
    if (error?.code === '23502') {
      const column =
        error.column ||
        this.extractColumnFromMessage(error.message || error.detail);
      return column
        ? `${column} cannot be null`
        : 'A required field is missing';
    }
    if (error?.code === '22P02') {
      console.log(error);

      const position = this.extractPgParamPosition(error?.where);
      console.log('position ,', position);

      const column = await this.extractColumnFromSource(
        tenant_id,
        position,
        entity,
      );
      console.log('column ,', column);

      // console.log("clll ", column);

      if (
        position !== null &&
        position !== undefined &&
        column !== null &&
        column !== undefined
      ) {
        return `Invalid Input  for ${column}`;
      }
    }
    return this.cleanInputString(error?.message) || error;
  };

  cleanInputString(input: string): string {
    return input
      .replace(/\\+/g, '') // Remove backslashes
      .replace(/['"]+/g, '') // Remove single and double quotes
      .trim(); // Trim leading/trailing spaces
  }
  extractColumnFromMessage(message: string): string | null {
    const match = message.match(/column "([^"]+)" of relation/);
    return match ? match[1] : null;
  }

  extractPgParamPosition(whereClause: string | undefined): number | null {
    const match = whereClause?.match(/\$([0-9]+)/);
    return match ? parseInt(match[1], 10) : null;
  }
  async extractColumnFromSource(tenant_id: string, position, entity) {
    let dataSource = await this.tenantService.getTenantConnection(tenant_id);
    // let col =dataSource.getMetadata(UserAofEntity).propertiesMap
    // console.log("colll ", dataSource.getMetadata(UserAofEntity).type);

    return Object.values(dataSource.getMetadata(entity).propertiesMap)[
      position
    ];
  }

  getConstrainst = async (tenant_id: string) => {
    let dataSource = await this.tenantService.getTenantConnection(tenant_id);
    const tableName = dataSource.getMetadata(UserAofEntity).tableName;
    await dataSource.query(
      `
  SELECT
      con.conname AS constraint_name,
      con.contype AS constraint_type,
      tbl.relname AS table_name,
      ARRAY_AGG(col.attname) AS columns
  FROM
      pg_constraint con
  JOIN
      pg_class tbl ON tbl.oid = con.conrelid
  JOIN
      pg_namespace ns ON ns.oid = tbl.relnamespace
  LEFT JOIN
      unnest(con.conkey) AS colnum ON true
  LEFT JOIN
      pg_attribute col ON col.attnum = colnum AND col.attrelid = tbl.oid
  WHERE
      tbl.relname = $1
  GROUP BY
      con.conname, con.contype, tbl.relname
  ORDER BY
      con.conname
  `,
      [tableName],
    );
  };
}
