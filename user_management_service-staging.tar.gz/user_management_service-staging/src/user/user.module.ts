import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { RmqService } from 'src/shared/rmq.service';
import { ConfigService } from '@nestjs/config';
import { TenantAwareRepositoryService } from 'src/shared/tenant-aware-repository.service';
import { TenantService } from 'src/tenant/tenant.service';
import { TenantModule } from 'src/tenant/tenant.module';
import { AuthModule } from 'src/auth/auth.module';

@Module({
  imports: [TenantModule,AuthModule],
  providers: [UserService,RmqService,ConfigService,TenantAwareRepositoryService],
  controllers: [UserController]
})
export class UserModule {}
