
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(
    private jwtService: JwtService
  ) {}

  async create(created_user:any): Promise<{ access_token: string }> {
    const payload = {
      user_id: created_user.id,
      email: created_user.email,
      mobile_number: created_user.mobile_number,
      tenant_id: created_user.tenant_id,
      name: created_user.name,
      isAofCreated: created_user.isAofCreated,
      };
    return {
      access_token: await this.jwtService.signAsync(payload),
    };
  }
}
