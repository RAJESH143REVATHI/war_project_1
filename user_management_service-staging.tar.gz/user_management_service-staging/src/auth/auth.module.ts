
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AuthService } from './auth.service';
import { ConfigModule, ConfigService } from '@nestjs/config';

@Module({
  imports: [
    JwtModule.registerAsync({
        imports:[ConfigModule],
        useFactory:(config:ConfigService) =>({
            secret:config.get<string>("YOUR_SECRET_KEY"),
            signOptions:{
                expiresIn:'30m'
            },
        }),
        inject:[ConfigService]
    })
  ],
  providers: [AuthService],
  controllers: [],
  exports: [AuthService,JwtModule],
})
export class AuthModule {}
