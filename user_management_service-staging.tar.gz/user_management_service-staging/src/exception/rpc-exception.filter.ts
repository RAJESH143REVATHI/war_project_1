import {
    Catch,
    ArgumentsHost,
    HttpException,
  } from '@nestjs/common';
  import {
    BaseRpcExceptionFilter,
    RpcException,
  } from '@nestjs/microservices';
  import { QueryFailedError } from 'typeorm';
  
  @Catch()
  export class AllRpcExceptionsFilter extends BaseRpcExceptionFilter {
    catch(exception: unknown, host: ArgumentsHost): any {
      // Handle TypeORM errors
      if (exception instanceof QueryFailedError) {
        const driverError: any = (exception as any).driverError;
  
        if (driverError.code === '23505') {
          if (driverError.detail?.includes('email')) {
            return new RpcException(JSON.stringify({
              message: 'Email already exists.',
              statusCode: 409,
            }));
          }
  
          if (driverError.detail?.includes('mobile_number')) {
            return new RpcException(JSON.stringify({
              message: 'Mobile number already exists.',
              statusCode: 409,
            }));
          }
  
          return new RpcException(JSON.stringify({
            message: 'Duplicate entry.',
            statusCode: 409,
          }));
        }
  
        if (driverError.code === '23503') {
          return new RpcException(JSON.stringify({
            message: 'Invalid reference in related entity.',
            statusCode: 400,
          }));
        }
  
        if (driverError.code === '23502') {
          return new RpcException(JSON.stringify({
            message: 'Missing required fields.',
            statusCode: 400,
          }));
        }
  
        return new RpcException(JSON.stringify({
          message: 'Database error occurred.',
          statusCode: 500,
        }));
      }
  
      // If already an RpcException
      if (exception instanceof RpcException) {
        return exception;
      }
  
      // Handle NestJS HttpException
      if (exception instanceof HttpException) {
        return new RpcException(JSON.stringify({
          message: exception.message,
          statusCode: exception.getStatus(),
        }));
      }
  
      console.error('[Unhandled Exception]', exception);
  
      return new RpcException(JSON.stringify({
        message: 'Unexpected error occurred.',
        statusCode: 500,
      }));
    }
  }
  