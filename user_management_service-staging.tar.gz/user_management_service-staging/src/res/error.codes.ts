// sql-error-mapper.ts

export type ResponseType =
  | 'success'
  | 'created'
  | 'error'
  | 'validation'
  | 'unauthorized'
  | 'forbidden'
  | 'not_found'
  | 'conflict';

export const sqlErrorCodeToResponseType: Record<string, ResponseType> = {
  // ========== PostgreSQL Errors ==========
  '23505': 'conflict',                // unique_violation
  '23503': 'validation',              // foreign_key_violation
  '23502': 'validation',              // not_null_violation
  '42703': 'error',                   // undefined_column
  '42601': 'error',                   // syntax_error
  '42P01': 'error',                   // undefined_table
  '22P02': 'validation',              // invalid_text_representation
  '42883': 'error',                   // undefined_function
  '22001': 'validation',              // string_data_right_truncation
  '22003': 'validation',              // numeric_value_out_of_range
  '40001': 'conflict',                // serialization_failure
  '57P01': 'error',                   // admin_shutdown

  // ========== MySQL Errors ==========
  'ER_DUP_ENTRY': 'conflict',                     // Duplicate entry
  'ER_NO_REFERENCED_ROW_2': 'validation',         // Foreign key constraint fails
  'ER_BAD_NULL_ERROR': 'validation',              // Column cannot be null
  'ER_TRUNCATED_WRONG_VALUE': 'validation',       // Enum or wrong value format
  'ER_PARSE_ERROR': 'error',                      // SQL syntax error
  'ER_NO_SUCH_TABLE': 'not_found',                // Table not found
  'ER_ROW_IS_REFERENCED_2': 'conflict',           // Row is referenced (FK)
  'ER_DATA_TOO_LONG': 'validation',               // Data too long for column
  'ER_WRONG_VALUE_FOR_FIELD': 'validation',

  // ========== Node.js / TypeORM / Network Errors ==========
  'ECONNREFUSED': 'error',            // DB connection refused
  'ETIMEDOUT': 'error',               // Connection timeout
  'ENOTFOUND': 'error',               // Host not found
  'ECONNRESET': 'error',              // Connection reset by peer
  'EHOSTUNREACH': 'error',            // Host unreachable

  // ========== Auth-related ==========
  'UNAUTHORIZED': 'unauthorized',
  'FORBIDDEN': 'forbidden',
  'NOT_FOUND': 'not_found',
};

/**
 * Maps SQL/driver error code to your custom response type.
 * @param code SQL error code (err.code from catch block)
 */
export function mapSqlErrorCodeToResponseType(code: string): ResponseType {
  return sqlErrorCodeToResponseType[code] || 'error';
}
