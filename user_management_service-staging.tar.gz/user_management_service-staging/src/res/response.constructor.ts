/* eslint-disable @typescript-eslint/no-unsafe-assignment */
class ApiResponse<T = any> {
  data: T;
  status: boolean;
  statusCode: number;
  msg: string | T;
}

export class ResponseConstructor<T = any> {
  private input: T;
  private type: string;

  constructor(data: T, type: string = 'success') {
    this.input = data;
    this.type = type;
  }

  private buildResponse({
    data,
    status,
    statusCode,
    msg,
  }: ApiResponse): ApiResponse {
    return {
      data,
      status,
      statusCode,
      msg,
    };
  }

  /**
   * Composes a standardized API response based on the response type.
   *
   * Handles various response scenarios including success, errors, and HTTP status-specific cases.
   * Automatically formats the response with appropriate status codes and messages.
   *
   * @method compose
   * @memberof ApiResponse
   *
   * @returns {Object} A structured response object containing:
   * @property {any|null} data - The response payload (null for error cases)
   * @property {boolean} status - Indicates success (true) or failure (false)
   * @property {number} statusCode - Appropriate HTTP status code
   * @property {string} msg - Human-readable status message
   *
   * @example
   * // Success response
   * new ApiResponse(userData, 'success').compose();
   * // Returns: { data: userData, status: true, statusCode: 200, msg: 'Request successful' }
   *
   * @example
   * // Error response
   * new ApiResponse('Invalid input', 'validation').compose();
   * // Returns: { data: null, status: false, statusCode: 400, msg: 'Invalid input' }
   *
   * @example
   * // Default error case
   * new ApiResponse(null, 'unknown_type').compose();
   * // Returns: { data: null, status: false, statusCode: 500, msg: 'Unknown response type' }
   *
   * @throws Will return a 500 error response if an unknown type is provided
   */
  compose() {
    switch (this.type) {
      case 'success':
        return this.buildResponse({
          data: this.input,
          status: true,
          statusCode: 200,
          msg: 'Request successful',
        });

      case 'created':
        return this.buildResponse({
          data: this.input,
          status: true,
          statusCode: 201,
          msg: 'Resource created successfully',
        });

      case 'error':
        return this.buildResponse({
          data: null,
          status: false,
          statusCode: 500,
          msg: this.input || 'Internal server error',
        });

      case 'validation':
        return this.buildResponse({
          data: null,
          status: false,
          statusCode: 400,
          msg: this.input || 'Validation error',
        });

      case 'unauthorized':
        return this.buildResponse({
          data: null,
          status: false,
          statusCode: 401,
          msg: this.input || 'unauthorized access',
        });

      case 'forbidden':
        return this.buildResponse({
          data: null,
          status: false,
          statusCode: 403,
          msg: this.input || 'Forbidden',
        });

      case 'not_found':
        return this.buildResponse({
          data: null,
          status: false,
          statusCode: 404,
          msg: this.input || 'Resource not found',
        });

      case 'conflict':
        return this.buildResponse({
          data: null,
          status: false,
          statusCode: 409,
          msg: this.input || 'Conflict occurred',
        });

      default:
        return this.buildResponse({
          data: null,
          status: false,
          statusCode: 500,
          msg: 'Unknown response type',
        });
    }
  }
}
