import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { UserModule } from './user/user.module';
import { MongooseModule } from '@nestjs/mongoose';
import { VerificationModule } from './verification/verification.module';
import rabbitmqConfig from './config/rabbitmq.config';
import { AuthModule } from './auth/auth.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, load: [rabbitmqConfig] }),
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        uri: `mongodb://${configService.get<string>(
          'MONGO_USERNAME',
        )}:${configService.get<string>(
          'MONGO_PASSWORD',
        )}@${configService.get<string>(
          'MONGO_HOST',
        )}:${configService.get<string>(
          'MONGO_PORT',
        )}/${configService.get<string>('MONGO_DATABASE')}?authSource=admin`,
      }),
      inject: [ConfigService],
    }),
    UserModule,
    VerificationModule,
    AuthModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
