import { IsString } from 'class-validator';

export class VerifyBankDto {
  @IsString()
  id_number: number;

  @IsString()
  ifsc: string;

  @IsString()
  ifsc_details: boolean; 
}
