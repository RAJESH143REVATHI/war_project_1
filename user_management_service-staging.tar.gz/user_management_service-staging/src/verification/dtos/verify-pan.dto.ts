import { IsString } from 'class-validator';

export class VerifyPanDto {
  @IsString()
  data: string;
}
