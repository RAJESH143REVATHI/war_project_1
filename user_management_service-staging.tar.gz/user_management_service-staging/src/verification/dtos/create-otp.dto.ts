import { IsMobilePhone } from 'class-validator';

export class CreateOtpDto {
  @IsMobilePhone('en-IN')
  mobile: number;
}
