import { Body, Controller } from '@nestjs/common';
import { MessagePattern, Payload } from '@nestjs/microservices';
import { VerificationService } from './verification.service';
import { VerifyPanDto } from './dtos/verify-pan.dto';
import { CreateOtpDto } from './dtos/create-otp.dto';
import { VerifyOtpDto } from './dtos/verify-otp.dto';
import { VerifyBankDto } from './dtos/verify-bank.dto';

@Controller('verification')
export class VerificationController {
  constructor(private readonly verificationService: VerificationService) {}

  // @MessagePattern({ cmd: 'VERIFY_PAN' })
  // async verifyPan(payload: any) {
  //   return await this.verificationService.verifyPan(payload.data);
  // }

  // @MessagePattern({ cmd: 'CREATE_OTP' })
  // async createOtp(@Payload() mobile: number)  {
  //   return await this.verificationService.createOtp(mobile);
  // }

  // @MessagePattern({ cmd: 'VERIFY_OTP' })
  // async verifyOtp(payload: any) {
  //   return await this.verificationService.verifyOtp(payload.otpId, payload.otp);
  // }

  // @MessagePattern({ cmd: 'VERIFY_BANK' })
  // async verifyBank(payload: any) {
  //   return await this.verificationService.verifyBank(payload.id_number,payload.ifsc,payload.ifsc_details);
  // }

  @MessagePattern({ cmd: 'VERIFY_PAN' })
  async verifyPan(@Payload() payload: VerifyPanDto) {
    console.log("🚀 ~ VerificationController ~ verifyPan ~ payload:", payload)
    return await this.verificationService.verifyPan(payload.data);
  }

  @MessagePattern({ cmd: 'CREATE_OTP' })
  async createOtp(@Payload() payload: any) {
    console.log('payload mobile',payload)
    return await this.verificationService.createOtp(payload);
  }

  @MessagePattern({ cmd: 'VERIFY_OTP' })
  async verifyOtp(@Payload() payload: VerifyOtpDto) {
    return await this.verificationService.verifyOtp(payload.otpId, payload.otp);
  }

  @MessagePattern({ cmd: 'VERIFY_BANK' })
  async verifyBank(@Payload() payload: VerifyBankDto) {
    return await this.verificationService.verifyBank(
      payload.id_number,
      payload.ifsc,
      payload.ifsc_details,
    );
  }
}
