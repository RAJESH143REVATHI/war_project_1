import { Module } from '@nestjs/common';
import { VerificationController } from './verification.controller';
import { VerificationService } from './verification.service';
import { SharedMongooseModule } from 'src/mongoose/mongoose.module';
import { HttpModule, HttpService } from '@nestjs/axios';

@Module({
  imports:[SharedMongooseModule,HttpModule],
  controllers: [VerificationController],
  providers: [VerificationService]
})
export class VerificationModule {}
