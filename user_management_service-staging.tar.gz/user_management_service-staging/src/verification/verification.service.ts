import {Injectable } from '@nestjs/common';
import { match } from 'assert';
import axios from 'axios';
import { otpRepository } from 'src/mongoose/repositories/otp.repository';
import { AwsInstance } from 'twilio/lib/rest/accounts/v1/credential/aws';
import { firstValueFrom } from 'rxjs';
import { HttpService } from '@nestjs/axios';

@Injectable()
export class VerificationService {
  constructor(private readonly otpRepository: otpRepository,
    private readonly httpservice : HttpService
  ) {}

  async verifyPan(panNumber: string): Promise<any> {
    try {
      const response = await axios.post(
        `${process.env.SUREPASS_PAN_API_URL}`,
        { id_number: panNumber },
        {
          headers: {
            Authorization: `Bearer ${process.env.SUREPASS_TOKEN}`,
            'Content-Type': 'application/json',
          },
        },
      );
      const panDetails = response.data?.data?.pan_details || {};
      const isSalaried = response.data?.data?.is_salaried ?? null;

      return {
        success: true,
        data: {
          full_name: panDetails.full_name || '',
          pan_number: response.data.data.pan_number || '',
          masked_aadhaar: panDetails.masked_aadhaar || '',
          email: panDetails.email || '',
          phone_number: panDetails.phone_number || '',
          gender: panDetails.gender || '',
          dob: panDetails.dob || '',
          aadhaar_linked: panDetails.aadhaar_linked ?? null,
          is_salaried: isSalaried,
          address: {
            line_1: panDetails.address?.line_1 || '',
            line_2: panDetails.address?.line_2 || '',
            street_name: panDetails.address?.street_name || '',
            zip: panDetails.address?.zip || '',
            city: panDetails.address?.city || '',
            state: panDetails.address?.state || '',
            country: panDetails.address?.country || '',
            full: panDetails.address?.full || '',
          },
        },
      };
    } catch (error) {
      console.error(
        'PAN verification failed:',
        error.response?.data || error.message,
      );
      return {
        success: false,
        message: 'PAN verification failed',
        error: error.response?.data || error.message,
      };
    }
  }

  async createOtp(
    mobile: number,
  ): Promise<{ otpId: string; success: boolean; message: string }> {
    const otp = this.generateOtp();
    const expiresAt = Date.now() + 5 * 60 * 1000;
    const expiresIn = Math.floor((expiresAt - Date.now()) / (1000 * 60));

    console.log('mobile otp',mobile);
    const savedOtp = await this.otpRepository.create({
      mobile,
      otp,
      expiresAt,
    });

    if (savedOtp && savedOtp._id) {
      console.log(`OTP saved for ${mobile}:`, savedOtp);
    } else {
      console.error(`Failed to save OTP for ${mobile}`);
    }

    return {
      success: true,
      message: `OTP sent successfully, will expire in ${expiresIn} minutes`,
      otpId: savedOtp._id,
    };
  }

  private generateOtp(): string {
    return Math.floor(1000 + Math.random() * 9000).toString();
  }

  async verifyOtp(
    id: string,
    otp: string,
  ): Promise<{ success: boolean; message: string, otpId:string }> {
    const record = await this.otpRepository.findById(id);
    if (!record) {
      return { success: false, message: 'OTP not found',otpId:id };
    }

    if (record.status === 'verified') {
      return {
        success: false,
        message: 'OTP has already been verified',
        otpId:id
      };
    }
    if (record.tries >= 3) {
      return {
        success: false,
        message: 'Maximum verification attempts exceeded',
        otpId:id
      };
    }
    await this.otpRepository.update(id, { tries: record.tries + 1 });

    const isExpired = Date.now() > record.expiresAt;
    const isMatch = record.otp === otp;

    if (isExpired) {
      return { success: false, message: 'OTP has expired', otpId:id };
    }

    if (isMatch) {
      await this.otpRepository.update(id, { status: 'verified' });
    } else {
      return { success: false, message: 'Invalid OTP', otpId:id };
    }

    console.log({})

    return { success: true, message: 'OTP verified successfully', otpId: id };
  }

  async verifyBank(id_number: number,ifsc: string,ifsc_details:boolean) {
    const url = process.env.SUREPASS_BANK_VERIFICATION_API_URL || '';
    try {
      const { data } = await firstValueFrom(
        this.httpservice.post(url,{
            id_number: id_number,
            ifsc: ifsc,
            ifsc_details:ifsc_details,
          },
          {
            headers: {
              Authorization: `Bearer ${process.env.SUREPASS_TOKEN}`,
              'Content-Type': 'application/json',
            },
          },
        ),
      );     

      return {
        success: true,
        data,
      };
    } catch (error) {
      console.error(
        'Bank verification failed:',
        error?.response?.data || error,
      );
      return {
        success: false,
        message: error?.response?.data?.message || 'Verification failed',
      };
    }
  }
}
