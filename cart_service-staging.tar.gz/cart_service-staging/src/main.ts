import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import { ConfigService } from '@nestjs/config';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const configService = app.get(ConfigService);

  // console.log(process.env.CART_SERVICE_QUEUE,"@@@@@@@",process.env.RABBITMQ_URL);

  const microservice = NestFactory.createMicroservice<MicroserviceOptions>(AppModule, {
    transport: Transport.RMQ,
    options: {
      urls: [configService.get<any>('rabbitmq.url')],
      queue: process.env.CART_SERVICE_QUEUE,
      queueOptions: {
        durable: true
      }
    }
  });


  (await microservice).listen();
  // await app.listen(process.env.PORT ?? 3000);
}
bootstrap();
