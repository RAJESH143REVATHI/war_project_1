import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { CartModule } from './cart/cart.module';
import { MongooseModule } from '@nestjs/mongoose';
import { OrderModule } from './order/order.module';
import rabbitmqConfig from './config/rabbitmq.config';
import { ConsumerModule } from './consumer/consumer.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, load: [rabbitmqConfig] }),
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        uri: `mongodb://${configService.get<string>(
          'MONGO_USERNAME',
        )}:${configService.get<string>(
          'MONGO_PASSWORD',
        )}@${configService.get<string>(
          'MONGO_HOST',
        )}:${configService.get<string>(
          'MONGO_PORT',
        )}/${configService.get<string>('MONGO_DATABASE')}?authSource=admin`,
      }),
      inject: [ConfigService],
    }),
    CartModule,
    OrderModule,
    ConsumerModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
