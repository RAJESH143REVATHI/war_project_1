// src/common/helpers/tenant-transaction.helper.ts

import { DeepPartial, EntityManager, ObjectLiteral } from 'typeorm';

export class TenantTransactionHelper {
  constructor(private readonly manager: EntityManager) {}

  getRepository<T extends ObjectLiteral>(entity: new () => T) {
    return this.manager.getRepository(entity);
  }

  async create<T extends ObjectLiteral>(
    entity: new () => T,
    data: DeepPartial<T>,
  ): Promise<T> {
    const repo = this.getRepository(entity);
    const instance = repo.create(data);
    return repo.save(instance);
  }

  async update<T extends ObjectLiteral>(
    entity: new () => T,
    id: number | string,
    data: Partial<T>,
  ): Promise<T> {
    const repo = this.getRepository(entity);
    await repo.update(id, data);
    return repo.findOneOrFail({ where: { id } as any });
  }

  async findOne<T extends ObjectLiteral>(
    entity: new () => T,
    where: Partial<T>,
  ): Promise<T | null> {
    const repo = this.getRepository(entity);
    return repo.findOne({ where });
  }

  async findById<T extends ObjectLiteral>(
    entity: new () => T,
    id: number | string,
  ): Promise<T | null> {
    const repo = this.getRepository(entity);
    return repo.findOne({ where: { id } as any });
  }
}
