import { Module } from "@nestjs/common";
import { TenantAwareRepositoryService } from "./tenant-aware-repository.service";
import { RmqService } from "./rmq.service";
import { TenantModule } from "src/tenant/tenant.module";

@Module({
    imports:[TenantModule],
  providers: [TenantAwareRepositoryService,RmqService],
  exports: [TenantAwareRepositoryService,RmqService]
})
export class SharedModule {}
