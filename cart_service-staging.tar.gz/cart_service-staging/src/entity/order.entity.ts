import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
  OneToMany,
} from 'typeorm';
import { UserEntity } from './user.entity';
import { OrderStatus } from 'src/order/order-status.enum';
import { PaymentEntity } from './payment.entity';

@Entity('orders')
export class OrderEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  user_id: string;

  @ManyToOne(() => UserEntity, (user) => user.orders, { onDelete: 'CASCADE' })
  @JoinColumn({ name: 'user_id' })
  user: UserEntity;

  @OneToMany(() => PaymentEntity, (payment) => payment.order)
  payments: PaymentEntity[];

  @Column()
  transaction_id: string;

  @Column()
  bap_order_id: string;

  @Column({ nullable: true })
  bpp_order_id: string;

  @Column()
  bap_id: string;

  @Column()
  bap_uri: string;

  @Column({ nullable: true })
  bpp_id: string;

  @Column({ nullable: true })
  bpp_uri: string;

  @Column({
    type: 'enum',
    enum: OrderStatus,
    default: OrderStatus.CREATED,
  })
  status: OrderStatus;

  @Column({ nullable: true  })
  order_status: string;

  @Column({
    nullable: true,
    enum: [
      'N/A',
      'AOF_SUBMITTED',
      'AOF_FAILED',
    ],
    default: 'N/A',
  })
  aof_status: 'N/A' | 'AOF_SUBMITTED' | 'AOF_FAILED';

  @Column({ type: 'jsonb', nullable: true })
  aof_response: any;

  @Column({ nullable: true })
  aof_error: string;

  @Column({ type: 'jsonb', nullable: true })
  kyc_response: any;

  @Column({ type: 'jsonb', nullable: true })
  esign_response: any;

  @Column({ type: 'jsonb', nullable: true })
  on_status_kyc_payload: any

  @Column({ type: 'jsonb', nullable: true })
  on_status_esign_payload: any

  @Column({
    type: 'enum',
    enum: ['LUMPSUM', 'SIP'],
    default: 'LUMPSUM',
  })
  investment_type: 'LUMPSUM' | 'SIP';

  @Column({ type: 'decimal', precision: 10, scale: 2 })
  amount: number;

  // SIP-specific fields (optional for Lumpsum)
  @Column({ type: 'date', nullable: true })
  sip_start_date: Date;

  @Column({ type: 'enum', enum: ['MONTHLY', 'QUARTERLY'], nullable: true })
  sip_frequency: 'MONTHLY' | 'QUARTERLY';

  @Column({ type: 'int', nullable: true })
  sip_duration_months: number;

  @Column({ type: 'enum', enum: ['ACTIVE', 'PAUSED', 'CANCELLED'], nullable: true })
  sip_status: 'ACTIVE' | 'PAUSED' | 'CANCELLED';

  @Column({ type: 'jsonb', nullable: true })
  select_context: any;

  @Column({ type: 'jsonb', nullable: true })
  aof_select_context: any

  @Column({ type: 'jsonb', nullable: true })
  aof_form: any

  @Column({ type: 'jsonb', nullable: true })
  aof_select_payload: any

  @Column({ type: 'jsonb', nullable: true })
  kyc_select_context: any

  @Column({ type: 'jsonb', nullable: true })
  kyc_select_payload: any

  @Column({ type: 'jsonb', nullable: true })
  esign_select_context: any

  @Column({ type: 'jsonb', nullable: true })
  esign_select_payload: any

  @Column({ type: 'boolean', default: false })
  user_action_required: boolean

  @Column({ type: 'boolean', default: false })
  hasError: any

  @Column({ type: 'jsonb', nullable: true })
  error_response: any

  @Column({ type: 'jsonb', nullable: true })
  init_context: any;

  @Column({ type: 'jsonb', nullable: true })
  confirm_context: any;

  @Column({ type: 'jsonb', nullable: true })
  on_select_payload: any;

  @Column({ type: 'jsonb', nullable: true })
  next_required_form: any;

  @Column({ type: 'jsonb', nullable: true })
  on_init_payload: any;

  @Column({ type: 'jsonb', nullable: true })
  on_confirm_payload: any;

  @Column({ type: 'jsonb', nullable: true })
  payments_options: any;

  @Column({ type: 'jsonb', nullable: true })
  selected_payment: any;

  @Column({ type: 'jsonb', nullable: true })
  on_status_payment_payload: any;

  @Column({ type: 'date',nullable: true })
  order_created_time: Date;

  @Column({ type: 'date',nullable: true })
  order_updated_time: Date;

  @CreateDateColumn({ name: 'created_at' })
  created_at: Date;

  @UpdateDateColumn({ name: 'updated_at' })
  updated_at: Date;
}
