// src/user/entities/user-aof.entity.ts
import {
    Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn,
  } from 'typeorm';
  import { UserEntity } from './user.entity';
  
  @Entity('user_aof_details')
  export class UserAofEntity {
    @PrimaryGeneratedColumn('uuid')
    id: number;
  
    // @OneToOne(() => UserEntity)
    // @JoinColumn()
    // user: UserEntity;

    @OneToOne(() => UserEntity, (user) => user.user_aof, {
      onDelete: 'CASCADE',
    })
    @JoinColumn({ name: 'user_id' })
    user: UserEntity;
  
    @Column({ length: 10 })
    pan: string;
  
    @Column({ length: 70 })
    investorName: string;
  
    @Column()
    dob: Date;
  
    @Column({ enum: ['Male', 'Female', 'Transgender'] })
    gender: 'Male' | 'Female' | 'Transgender';
  
    @Column({ length: 70, nullable: true })
    fatherName?: string;
  
    @Column({ length: 70, nullable: true })
    spouseName?: string;
  
    @Column({ length: 70 })
    motherName: string;
  
    @Column({ enum: ['Married', 'Unmarried'] })
    maritalStatus: string;
  
    @Column({ type: 'char', length: 4 })
    aadhaarLast4Digits: string;
  
    @Column()
    nationality: string;
  
    @Column()
    citizenship: string;
  
    @Column()
    signatureUrl: string; // URL or path to file
  
    @Column('decimal', { precision: 10, scale: 7 })
    geoLatitude: number;
  
    @Column('decimal', { precision: 10, scale: 7 })
    geoLongitude: number;
  
    @Column()
    occupation: string;
  
    @Column()
    sourceOfWealth: string;
  
    @Column()
    annualIncome: string;
  
    @Column()
    countryOfBirth: string;
  
    @Column({ length: 60 })
    placeOfBirth: string;
  
    @Column()
    politicalExposure: string;
  
    @Column({ default: 'Resident' })
    taxResidencyStatus: string;
  
    // Communication Address Fields
    @Column()
    addressLine: string;
  
    @Column({ length: 6 })
    pincode: string;
  
    @Column()
    country: string;
  
    @Column()
    addressNature: string;
  
    // Contact Info
    @Column({ length: 10 })
    phoneNumber: string;
  
    @Column()
    phoneBelongsTo: string;
  
    @Column()
    email: string;
  
    @Column()
    emailBelongsTo: string;
  
    // Payout Bank Details
    @Column({ length: 18 })
    bankAccountNumber: string;
  
    @Column({ length: 70 })
    primaryHolderName: string;
  
    @Column()
    ifscCode: string;
  
    @Column({ default: 'Savings' })
    accountType: string;
  
    // Nominee 1
    @Column({ nullable: true })
    nomineeName: string;
  
    @Column({ nullable: true })
    nomineePAN: string;
  
    @Column({ type: 'date', nullable: true })
    nomineeDOB: Date;
  
    @Column({ nullable: true })
    nomineeRelationship: string;
  
    @Column({ nullable: true })
    nomineeGuardianName: string;
  
    @Column({ nullable: true })
    nomineeGuardianPAN: string;
  
    @Column({ type: 'int', nullable: true })
    nomineeAllocationPercentage: number;
  }
  