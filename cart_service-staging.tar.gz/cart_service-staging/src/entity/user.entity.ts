// src/user/entities/user.entity.ts

import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    UpdateDateColumn,
    OneToOne,
    OneToMany,
    Index,
    JoinColumn,
  } from 'typeorm';

  import { UserAofEntity } from './user.aof.entity';
  import { OrderEntity } from './order.entity';


  @Entity('users')
  export class UserEntity {
    @PrimaryGeneratedColumn('uuid')
    id: string;
  
    @Column({ length: 100 })
    name: string;
  
    @Column({nullable: true})
    tenant_id: string;
  
    @Index()
    @Column({ unique: true })
    mobile_number: string;
  
    @Column({ unique: true })
    email: string;
  
    @Column({ select: false,nullable: true })
    password: string;
  
    @CreateDateColumn({ name: 'created_at' })
    created_at: Date;
  
    @UpdateDateColumn({ name: 'updated_at' })
    updated_at: Date;
  
    @OneToOne(() => UserAofEntity, (aof) => aof.user, {
      cascade: true,
    })
    @JoinColumn()
    user_aof: UserAofEntity;
  
    @OneToMany(() => OrderEntity, (order) => order.user)
    orders: OrderEntity[];
}
  