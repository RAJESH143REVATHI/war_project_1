import { Injectable, Scope,NotFoundException, HttpStatus, HttpException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { TenantConfig } from 'src/tenant/tenantConfig.schema';
import { DataSource, DataSourceOptions } from 'typeorm';

import * as bcrypt from 'bcrypt';
import { v4 as uuidv4 } from 'uuid';
import { TenantDto } from './tenant.dto';
// import { UserEntity } from 'src/entity/user.entity';
// import { OrderEntity } from 'src/entity/order.entity';
// import { entities } from 'src/entity';

import {entities as npstxEntities} from '@npstx/pg-entities'

@Injectable() // Ensure a per-request scope
export class TenantService {
  private connections: Map<string, DataSource> = new Map();

  constructor(@InjectModel(TenantConfig.name) private tenantConfigModel: Model<TenantConfig>) {}

  async getTenantConnection(tenant_id: string): Promise<DataSource | any> {
    if (this.connections.has(tenant_id)) {
      return this.connections.get(tenant_id);
    }

    // Fetch tenant_id-specific DB credentials from MongoDB
    const config = await this.tenantConfigModel.findOne({ tenant_id }).exec();

    /**`
     * 
     * Cashed the tenant_id based database credintials in memory (Redis or KeyDb).
     * Others services will have access to the chashed database credintials.
     * Reduce database queries.
     * 
     */
    if (!config) {
      throw new Error(`No database configuration found for tenant_id: ${tenant_id}`);
    }

    const connectionOptions: DataSourceOptions = {
      type: 'postgres',
      host: config.dbCredentials.host,
      username: config.dbCredentials.username,
      password: config.dbCredentials.password,
      database: config.dbCredentials.dbName,
      entities: npstxEntities,
      synchronize: true,
      logging: false, 
      extra: {
        max: 10, // Max connections in pool
        min: 2, // Keep a minimum of 2 connections
        idleTimeoutMillis: 30000, 
        connectionTimeoutMillis: 5000,
      },
    };

    const dataSource = new DataSource(connectionOptions);
    await dataSource.initialize(); // Establish connection

    this.connections.set(tenant_id, dataSource);
    return dataSource;
  }

  async getConfigByTenant(tenant_id: string): Promise<TenantConfig> {
    const config = await this.tenantConfigModel.findOne({ tenant_id }).exec();
    if (!config) {
      throw new NotFoundException(`Configuration not found for tenant_id: ${tenant_id}`);
    }
    return config;
  }

  async createTenant(data: TenantDto) {
    try {
      // Assign UUID
      data.tenant_id = uuidv4();

      // Hash tenant_pass_key
      const saltRounds = 10;
      data.tenant_pass_key = await bcrypt.hash(data.tenant_pass_key, saltRounds);

      // Save to DB
      const tenant = new this.tenantConfigModel(data);
      const result = await tenant.save();
      return result;
    } catch (error) {
      console.error('Error in TenantService:', error);
      throw new HttpException(
        'Error creating tenant: ' + (error.message || 'Unknown error'),
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
