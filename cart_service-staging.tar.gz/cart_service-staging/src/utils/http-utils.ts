import axios, { AxiosRequestConfig, Method } from 'axios';

import FormData from 'form-data';
import fs from 'fs';
import path from 'path';

/**
 * Make an HTTP request using axios.
 * @param url - The full URL to call.
 * @param method - HTTP method: 'GET', 'POST', etc.
 * @param data - Payload for POST/PUT requests (optional).
 * @param headers - Optional headers.
 */
export async function makeApiCall<T = any>(
  url: string,
  method: Method,
  data?: any,
  headers?: Record<string, string>
): Promise<T> {
  const config: AxiosRequestConfig = {
    url,
    method
  };

  if(data){
    config.data = data;
  }
  if(headers){
    config.headers = headers;
  }
  console.log("🚀 ~ config:-----", config);

  try {
    const response = await axios(config);
    return response.data as T;
  } catch (error) {
    console.log("🚀 ~ error:", error?.response?.data?.data);
    // Optional: throw structured error for caller to handle
    throw {
      message: error?.response?.data?.message || 'HTTP request failed',
      status: error?.response?.status || 500,
      details: error?.response?.data || error,
    };
  }
}


/**
 * Makes a multipart/form-data HTTP request.
 * @param url - The full endpoint URL.
 * @param method - HTTP method, typically 'POST' or 'PUT'.
 * @param formFields - Key-value pairs of the form data.
 * @param fileFields - Key-filepath or file buffers. Supports multiple files.
 */
export async function makeMultipartApiCall<T = any>(
  url: string,
  method: Method,
  formFields: Record<string, any>,
  fileFields?: Record<string, string | Buffer>,
  customHeaders?: Record<string, string>
): Promise<T> {
  const form = new FormData();

  for (const key in formFields) {
    const value = formFields[key];
    if (Array.isArray(value)) {
      value.forEach(v => form.append(key, v));
    } else {
      form.append(key, value ?? '');
    }
  }

  if (fileFields) {
    for (const key in fileFields) {
      const file = fileFields[key];
      if (typeof file === 'string') {
        form.append(key, fs.createReadStream(file), { filename: path.basename(file) });
      } else {
        form.append(key, file, { filename: `${key}.pdf` });
      }
    }
  }

  const config: AxiosRequestConfig = {
    method,
    url,
    data: form,
    headers: {
      ...form.getHeaders(),
      ...(customHeaders || {}),
    },
    maxBodyLength: Infinity,
  };

  console.log("🚀 ~ Sending multipart request to:", url);

  try {
    const response = await axios(config);
    return response.data as T;
  } catch (error: any) {
    console.log("🚀 ~ error:", error)
    throw {
      message: error?.response?.data?.message || 'Multipart request failed',
      status: error?.response?.status || 500,
      details: error?.response?.data || error,
    };
  }
}

