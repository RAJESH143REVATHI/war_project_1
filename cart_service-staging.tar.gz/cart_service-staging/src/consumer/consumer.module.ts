import { forwardRef, Module } from "@nestjs/common";
import { OnSelectConsumerService } from "./onSelectConsumer.service";
import { MqService } from "./mq.service";
import { OrderModule } from "src/order/order.module";
import { FormHandlerService } from "./formHandler.service";
import { OnStatusConsumerService } from "./onStatusConsumer.service";
import { OnInitConsumerService } from "./onInitConsumer.service";
import { OnConfirmConsumerService } from "./onConfirm.service";
import { OnUpdateConsumerService } from "./onUpdateConsumer.service";


@Module({
    imports: [
        forwardRef(() => OrderModule)
    ],
    controllers: [],
    providers: [
        MqService,
        OnSelectConsumerService,
        FormHandlerService,
        OnStatusConsumerService,
        OnInitConsumerService,
        OnConfirmConsumerService,
        OnUpdateConsumerService
    ],
    exports: [MqService,OnSelectConsumerService]
})
export class ConsumerModule {}