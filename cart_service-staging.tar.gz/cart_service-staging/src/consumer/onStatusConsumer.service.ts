import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { MqService } from './mq.service';
import * as amqp from 'amqplib';
import { OrderService } from 'src/order/order.service';
// import { CatlogProcesserService } from 'src/catalog-processer/catlog-processer.service';

@Injectable()
export class OnStatusConsumerService implements OnModuleInit {
  private readonly logger = new Logger(OnStatusConsumerService.name);


  constructor(
    private readonly mqService: MqService,
    private readonly orderService: OrderService
  ) {}

  /**
   * Start listening to the on_status_queue when the module is initialized.
   * The queue is declared in the rabbitmq.config.ts file.
   * If the queue is not created, the service will not start.
   * If the queue is deleted, the service will throw an error.
   */
  async onModuleInit() {
    try {
      await this.consumeQueue('on_status_queue');
      console.log("🚀 on_status_queue start listening");
    } catch (err) {
      this.logger.error('Failed to initialize OnStatusConsumerService', err);
    }
  }

  private async consumeQueue(queueName: string) {
    await this.mqService.listenToQueue(queueName, async (data, msg, channel: amqp.Channel) => {
      try {
        this.logger.log(`📥 Received from ${queueName}: ${JSON.stringify(data)}`);

        let status = await this.orderService.getOnStatusRes(data);

        channel.ack(msg);
      } catch (err) {
        this.logger.error(`❌ Error processing message from ${queueName}: ${err.message}`, err.stack);

        // 🔁 Decide whether to requeue the message (true) or discard (false);
        const requeue = true;

        channel.nack(msg, false, requeue);
      }
    });
  }
}
