import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { MqService } from './mq.service';
import * as amqp from 'amqplib';
import { OrderService } from 'src/order/order.service';
// import { CatlogProcesserService } from 'src/catalog-processer/catlog-processer.service';

@Injectable()
export class OnConfirmConsumerService implements OnModuleInit {
  private readonly logger = new Logger(OnConfirmConsumerService.name);


  constructor(
    private readonly mqService: MqService,
    private readonly orderService: OrderService
  ) {}

  /**
   * Start listening to the on_init_queue when the module is initialized.
   * The queue is declared in the rabbitmq.config.ts file.
   * If the queue is not created, the service will not start.
   * If the queue is deleted, the service will throw an error.
   */
  async onModuleInit() {
    try {
      await this.consumeQueue('on_confirm_queue');
      console.log("🚀 on_confirm_queue start listening on_confirm");
    } catch (err) {
      this.logger.error('Failed to initialize OnInitConsumerService', err);
    }
  }

  private async consumeQueue(queueName: string) {
    await this.mqService.listenToQueue(queueName, async (data, msg, channel: amqp.Channel) => {
      try {
        this.logger.log(`📥 Received from ${queueName}: ${JSON.stringify(data)}`);

        let status = await this.orderService.onConfirmRes(data);
        

        channel.ack(msg);
      } catch (err) {
        this.logger.error(`❌ Error processing message from ${queueName}: ${err.message}`, err.stack);

        // 🔁 Decide whether to requeue the message (true) or discard (false);
        const requeue = true;

        channel.nack(msg, false, requeue);
      }
    });
  }
}
