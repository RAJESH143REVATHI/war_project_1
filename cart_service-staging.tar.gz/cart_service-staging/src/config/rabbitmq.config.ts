import { registerAs } from '@nestjs/config';

export default registerAs('rabbitmq', () => ({
  url: `amqp://${process.env.RABBITMQ_USERNAME}:${process.env.RABBITMQ_PASSWORD}@${process.env.RABBITMQ_URL}:5672/${process.env.V_HOST}`,
  queue: process.env.RABBITMQ_CART_QUEUE,
}));
