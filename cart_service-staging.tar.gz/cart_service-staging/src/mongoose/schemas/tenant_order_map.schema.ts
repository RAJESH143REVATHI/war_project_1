import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";

export type TenantOrderMapDocument = TenantOrderMap & Document;

// MongoDB example: tenant_order_map.schema.ts
@Schema({ collection: 'tenant_order_map' })
export class TenantOrderMap {
  @Prop({ required: true, unique: true })
  transaction_id: string;

  @Prop({ required: true })
  tenant_id: string;

}

export const TenantOrderMapSchema = SchemaFactory.createForClass(TenantOrderMap);
