import { forwardRef, Module } from "@nestjs/common";
import { TenantModule } from "src/tenant/tenant.module";
import { OrderController } from "./order.controller";
import { OrderService } from "./order.service";
import { ConfigService } from "@nestjs/config";
import { RmqService } from "src/shared/rmq.service";
import { ContextBuilderService } from "./context-builder.service";
import { TenantAwareRepositoryService } from "src/shared/tenant-aware-repository.service";
import { SharedModule } from "src/shared/shared.module";
import { SharedMongooseModule } from "src/mongoose/mongoose.module";
import { AofSubmissionService } from "./aof-submission/aof-submission.service";
import { ConsumerModule } from "src/consumer/consumer.module";

@Module({
    imports: [
        TenantModule,
        SharedModule,
        SharedMongooseModule,
        forwardRef(() => ConsumerModule)
    ],
    controllers: [OrderController],
    providers: [OrderService,ConfigService,ContextBuilderService,AofSubmissionService],
    exports: [OrderService,ContextBuilderService,AofSubmissionService]
    
})
export class OrderModule {}