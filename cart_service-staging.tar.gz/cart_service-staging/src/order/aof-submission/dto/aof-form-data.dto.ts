import {
  IsString,
  IsNotEmpty,
  IsEmail,
  IsOptional,
  IsIn,
  IsEnum,
  IsDateString,
  IsNumberString,
  IsLatitude,
  IsLongitude,
  IsNumber,
  MaxLength,
  MinLength,
  Length,
} from 'class-validator';

export enum Gender {
  Male = 'Male',
  Female = 'Female',
  Transgender = 'Transgender',
}

export enum MaritalStatus {
  Married = 'Married',
  Unmarried = 'Unmarried',
}

export enum AccountType {
  Savings = 'Savings',
  Current = 'Current',
}

export class AofFormDataDto {
  @IsString()
  @Length(10, 10)
  pan: string;

  @IsString()
  @Length(4, 4)
  aadhaarLast4Digits: string;

  @IsString()
  @IsNotEmpty()
  investorName: string;

  @IsDateString()
  dob: string;

  @IsEnum(Gender)
  gender: Gender;

  @IsEnum(MaritalStatus)
  maritalStatus: MaritalStatus;

  @IsOptional()
  @IsString()
  fatherName?: string;

  @IsOptional()
  @IsString()
  spouseName?: string;

  @IsString()
  motherName: string;

  @IsEmail()
  email: string;

  @IsString()
  emailBelongsTo: string;

  @IsNumberString()
  @Length(10, 10)
  phoneNumber: string;

  @IsString()
  phoneBelongsTo: string;

  @IsString()
  addressLine: string;

  @IsString()
  @Length(6, 6)
  pincode: string;

  @IsString()
  country: string;

  @IsString()
  addressNature: string;

  @IsString()
  occupation: string;

  @IsString()
  sourceOfWealth: string;

  @IsString()
  annualIncome: string;

  @IsString()
  bankAccountNumber: string;

  @IsString()
  primaryHolderName: string;

  @IsString()
  ifscCode: string;

  @IsEnum(AccountType)
  accountType: AccountType;

  @IsOptional()
  @IsString()
  nomineeName?: string;

  @IsOptional()
  @IsString()
  nomineePAN?: string;

  @IsOptional()
  @IsDateString()
  nomineeDOB?: string;

  @IsOptional()
  @IsString()
  nomineeRelationship?: string;

  @IsOptional()
  @IsString()
  nomineeGuardianName?: string;

  @IsOptional()
  @IsString()
  nomineeGuardianPAN?: string;

  @IsOptional()
  @IsNumber()
  nomineeAllocationPercentage?: number;

  @IsString()
  nationality: string;

  @IsString()
  citizenship: string;

  @IsString()
  taxResidencyStatus: string;

  @IsString()
  countryOfBirth: string;

  @IsString()
  placeOfBirth: string;

  @IsString()
  politicalExposure: string;

  @IsString()
  signatureUrl: string;

  @IsLatitude()
  geoLatitude: number;

  @IsLongitude()
  geoLongitude: number;
}
