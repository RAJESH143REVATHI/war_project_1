// src/aof-submission/dto/submit-form.dto.ts

export class SubmitFormDto {
  tenantId: string;
  transactionId: string;
  formUrl: string;
  userId: string;
}
