// src/aof-submission/interfaces/aof-form-data.interface.ts

export interface AofFormData {
  // Personal Information
  pan: string;
  aadhaarLast4Digits: string;
  name: string;
  dob: string; // Format: YYYY-MM-DD
  gender: 'Male' | 'Female' | 'Transgender';
  maritalStatus: 'Married' | 'Unmarried' | 'Others';
  fatherName?: string;
  spouseName?: string;
  motherName: string;

  // Contact & Address Info
  email: string;
  emailBelongsTo?: string;
  phoneNumber: string;
  phoneBelongsTo?: string;
  addressLine: string;
  pincode: string;
  country: string;
  addressNature: string;

  // Income & Employment
  occupation:
    | 'Business'
    | 'Professional'
    | 'Retired'
    | 'Housewife'
    | 'Student'
    | 'Public Sector Service'
    | 'Private Sector Service'
    | 'Government Service'
    | 'Agriculture'
    | 'Doctor'
    | 'Forex Dealer'
    | 'Service'
    | 'Others'
    | 'Self Employed'
    | string;
  sourceOfWealth:
    | 'Salary'
    | 'Business'
    | 'Gift'
    | 'Ancestral Property'
    | 'Rental Income'
    | 'Prize Money'
    | 'Royalty'
    | 'Others'
    | string
  annualIncome:
    | 'Below ₹1L'
    | '₹1L - ₹5L'
    | '₹5L - ₹10L'
    | '₹10L - ₹25L'
    | '₹25L - ₹1Cr'
    | 'Above ₹1Cr'
    | string

  // Banking Details
  bankAccountNumber: string;
  primaryHolderName: string;
  ifscCode: string;
  accountType: 'Savings' | 'Current' | string;

  // Nominee Details
  nomineeName?: string;
  nomineePAN?: string;
  nomineeDOB?: string;
  nomineeRelationship?: string;
  nomineeGuardianName?: string;
  nomineeGuardianPAN?: string;
  nomineeAllocationPercentage?: number;

  // Residency & Tax
  nationality: string;
  citizenship: string;
  taxResidencyStatus: 'Resident' | 'Non-Resident' | string;
  countryOfBirth: string;
  placeOfBirth: string;

  // Compliance
  politicalExposure: 'No exposure' | 'Politically Exposed' | 'Related to a Politically Exposed Person' | string;

  // Signature & Location
  signatureUrl: string;
  geoLatitude: number;
  geoLongitude: number;
}
