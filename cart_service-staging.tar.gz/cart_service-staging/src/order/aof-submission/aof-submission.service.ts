import { forwardRef, Inject, Injectable, Logger } from '@nestjs/common';
import { SubmitFormDto } from './dto/submit-form.dto';
import { TenantAwareRepositoryService } from 'src/shared/tenant-aware-repository.service';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';
// import { OrderEntity } from 'src/entity/order.entity';
// import { UserAofEntity } from 'src/entity/user.aof.entity';
import { AxiosError } from 'axios';
// import { AofFormData } from './interfaces/aof-form-data.interface';
import { makeApiCall, makeMultipartApiCall } from 'src/utils/http-utils';
// import { url } from 'inspector';

import * as cheerio from 'cheerio';
import path from 'path';
import { OrderService } from '../order.service';

type FormField = {
  name: string;
  type: string;
  required: boolean;
  defaultValue: any;
};

export enum AOFStatus{
  AOF_SUBMITTED= 'AOF_SUBMITTED',
  AOF_FAILED= 'AOF_FAILED'

}

@Injectable()
export class AofSubmissionService {
  private readonly logger = new Logger(AofSubmissionService.name);

  constructor(
    private readonly tenantRepo: TenantAwareRepositoryService,
    @Inject(forwardRef(() => OrderService))
    private readonly orderService: OrderService
  ) { }

  extractFormFieldsFromHtml(html: string): {
    fields: {
      name: string;
      type: string;
      required: boolean;
      defaultValue: string;
    }[], url: string
  } {
    const $ = cheerio.load(html);
    const fields: {
      name: string;
      type: string;
      required: boolean;
      defaultValue: string;
    }[] = [];
    let url = '';

    $('input, select, textarea').each((_, element) => {
      const tag = $(element);
      const name = tag.attr('name');
      const type = tag.attr('type') || tag[0].tagName; // fallback to tag name
      const value = tag.val() as string;
      const required = tag.attr('required') !== undefined;

      if (name) {
        fields.push({
          name,
          type,
          required,
          defaultValue: value || '',
        });
      }
    });

    $('form').each((_, element) => {
      const tag = $(element);
      const action = tag.attr('action');

      url = action || url;

    });

    return { fields, url };
  }


  async autoSubmitForm(dto: SubmitFormDto): Promise<any> {
    const { tenantId, transactionId, formUrl, userId } = dto;

    try {

      const response = await makeApiCall(formUrl, 'GET');

      let { fields, url } = this.extractFormFieldsFromHtml(response);
     

      // const userAof = await this.tenantRepo.findOne<UserAofEntity>(
      //   tenantId,
      //   UserAofEntity,
      //   { user: { id: userId } },
      // );

      // if (!userAof) throw new Error(`AOF data not found for user ${userId}`);


      // Parse token from formUrl
      const urlObj = new URL(formUrl);
      const token = urlObj.searchParams.get('token') || '';
      const transaction_id = urlObj.searchParams.get('transaction_id') || '';


      const submitUrl = url;
      // console.log("🚀 ~ AofSubmissionService ~ autoSubmitForm ~ submitUrl:", submitUrl)

      const { payload, filePayload } = this.getRequiredFormPayload(fields);
      // console.log(filePayload, "🚀 ~ AofSubmissionService ~ autoSubmitForm ~ formFields:", payload)


      const submitResponse = await makeMultipartApiCall(submitUrl, 'POST', payload,filePayload);

      if(submitResponse.status === 'SUBMITTED' && submitResponse.submission_id){
        return {status:true, aofRes: submitResponse}
      }else{
        return {status:false,aofRes: submitResponse}
      }
      


      // this.logger.log(`AOF submitted for transaction: ${transactionId} --> ${JSON.stringify(submitResponse)}`);

      // if(submitResponse.status === 'SUBMITTED' && submitResponse.submission_id){
      //   // this.logger.log(`AOF submitted for transaction: ${transactionId} --> ${JSON.stringify(submitResponse)}`);

      //   // Make Select request to BPP.

      //   this.orderService.selectFormSubmission({ transaction_id, token,submission_id:submitResponse.submission_id,tenantId });
      // }

      // await this.tenantRepo.updateByWhere(
      //   tenantId,
      //   OrderEntity,
      //   { transaction_id: transactionId },
      //   {
      //     aof_status: AOFStatus.AOF_SUBMITTED,
      //     aof_response: submitResponse
      //   },
      // );


    } catch (error) {
      console.log("🚀 ~ AofSubmissionService ~ autoSubmitForm ~ error:", error)
      const errMsg =
        error instanceof AxiosError
          ? `AxiosError: ${error.message}`
          : (error as Error).message;

      this.logger.error(`AOF submission failed for ${transactionId}: ${errMsg}`);

      return {status:false,aofRes: {errMsg}}

      // await this.tenantRepo.updateByWhere(
      //   tenantId,
      //   OrderEntity,
      //   { transaction_id: transactionId },
      //   {
      //     aof_status: AOFStatus.AOF_FAILED,
      //     aof_error: errMsg,
      //   },
      // );

    }
  }



  private getRequiredFormPayload(fields: FormField[]): Record<string, any> {
    const dummyValues: Record<string, any> = {
      name: "Suraj Singh",
      dob: "1998-02-26",
      gender: "male",
      marital_status: "married",
      father_name: "Anup Singh",
      spouse_name: "Anu Singh",
      mother_name: "Veena Singh",
      aadhaar_number: "1234",
      nationality: "in",
      citizenships: ["in"],
      geo_latitude: "12.9716",
      geo_longitudes: "77.5946",
      occupation: "business",
      source_of_wealth: "salary",
      income_range: "upto_1lakh",
      cob: "in",
      pob: "Bangalore",
      political_exposure: "no_exposure",
      india_tax_residency_status: "resident",
      mode_of_holding: "single",
      ca_line: "123 MG Road",
      ca_pincode: "560001",
      ca_country: "in",
      ca_nature: "residential",
      cp_number: "9876543210",
      ce_address: "suman@example.com",
      pba_number: "5231231231193",
      pba_pname: "HDFC Bank",
      pba_code: "HDFC0001236",
      pba_type: "savings",
      skip_nomination: "yes",
      'trc_country[0]': "",
      'trc_idtype[0]': '',
      'trc_idnumber[0]': '',
      'trc_country[1]': '',
      'trc_idtype[1]': '',
      'trc_idnumber[1]': '',
      'trc_country[2]': '',
      'trc_idtype[2]': '',
      'trc_idnumber[2]': '',
      'nominee_name[0]': '',
      'nominee_relationship[0]': '',
      'nominee_dob[0]': '',
      'nominee_idtype[0]': '',
      'nominee_idnumber[0]': '',
      'nominee_cphone[0]': '',
      'nominee_cemail[0]': '',
      'nominee_caline[0]': '',
      'nominee_capincode[0]': '',
      'nominee_cacountry[0]': '',
      'nominee_guardian_name[0]': '',
      'nominee_gidtype[0]': '',
      'nominee_gidnumber[0]': '',
      'nominee_gcphone[0]': '',
      'nominee_gcemail[0]': '',
      'nominee_gcaline[0]': '',
      'nominee_gcapincode[0]': '',
      'nominee_gcacountry[0]': '',
      'nominee_percentage[0]': '',
      'nominee_name[1]': '',
      'nominee_relationship[1]': '',
      'nominee_dob[1]': '',
      'nominee_idtype[1]': '',
      'nominee_idnumber[1]': '',
      'nominee_cphone[1]': '',
      'nominee_cemail[1]': '',
      'nominee_caline[1]': '',
      'nominee_capincode[1]': '',
      'nominee_cacountry[1]': '',
      'nominee_guardian_name[1]': '',
      'nominee_gidtype[1]': '',
      'nominee_gidnumber[1]': '',
      'nominee_gcphone[1]': '',
      'nominee_gcemail[1]': '',
      'nominee_gcaline[1]': '',
      'nominee_gcapincode[1]': '',
      'nominee_gcacountry[1]': '',
      'nominee_percentage[1]': '',
      'nominee_name[2]': '',
      'nominee_relationship[2]': '',
      'nominee_dob[2]': '',
      'nominee_idtype[2]': '',
      'nominee_idnumber[2]': '',
      'nominee_cphone[2]': '',
      'nominee_cemail[2]': '',
      'nominee_caline[2]': '',
      'nominee_capincode[2]': '',
      'nominee_cacountry[2]': '',
      'nominee_guardian_name[2]': '',
      'nominee_gidtype[2]': '',
      'nominee_gidnumber[2]': '',
      'nominee_gcphone[2]': '',
      'nominee_gcemail[2]': '',
      'nominee_gcaline[2]': '',
      'nominee_gcapincode[2]': '',
      'nominee_gcacountry[2]': '',
      'nominee_percentage[2]': '',
      nomination_display_setting: ''
    };

    const payload: Record<string, any> = {};
    const filePayload: Record<string, any> = {};

    for (const field of fields) {
      // if (field.required || field.type === "select") {
      if (dummyValues.hasOwnProperty(field.name)) {
        payload[field.name] = dummyValues[field.name];
      } else if (field.type === "select") {
        payload[field.name] = Array.isArray(field.defaultValue)
          ? field.defaultValue
          : field.defaultValue ?? "default_option";
      } else if (field.type === "text" || field.type === "input") {
        payload[field.name] = "sample text";
      } else if (field.type === "email") {
        payload[field.name] = "user@example.com";
      } else if (field.type === "number") {
        payload[field.name] = 12345;
      } else if (field.type === "file") {
        filePayload[field.name] = path.join(process.cwd(), 'file', 'signature-3.jpg');;
      } else {
        payload[field.name] = field.defaultValue ?? null;
      }
      // }
    }

    return { payload, filePayload };
  }


}

