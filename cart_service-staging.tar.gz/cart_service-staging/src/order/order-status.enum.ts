export enum OrderStatus {
  CREATED = 'created',
  SELECT_REQUESTED = 'select_requested',
  ON_SELECT_RECEIVED = 'on_select_received',
  ON_SELECT_RECEIVED_ERROR = 'on_select_received_error',

  AOF_PENDING = 'aof_pending',
  AOF_ERROR = 'aof_error',
  AOF_SUBMITTED = 'aof_submitted',
  AOF_SELECT_REQUESTED = 'aof_select_requested',
  AOF_SELECT_RECEIVED = 'aof_select_received',
  AOF_SELECT_RECEIVED_ERROR = 'aof_select_received_error',

  KYC_PENDING = 'kyc_pending',
  KYC_SUBMITTED = 'kyc_submitted',
  KYC_SELECT_REQUESTED = 'kyc_select_requested',
  KYC_SELECT_RECEIVED = 'kyc_select_received',
  KYC_SELECT_RECEIVED_ERROR = 'kyc_select_received_error',

  // EXISTING_FOLIO = 'existing_folio',

  ESIGN_PENDING = 'esign_pending',
  ESIGN_SUBMITTED = 'esign_submitted',
  ESIGN_SELECT_REQUESTED = 'esign_select_requested',
  ESIGN_SELECT_RECEIVED = 'esign_select_received',
  ESIGN_SELECT_RECEIVED_ERROR = 'esign_select_received_error',

  PAYMENT_OPTIONS_RESIVED = 'payment_options_resived',
  PAYMENT_OPTION_SELECTED = 'payment_option_selected',

  INIT_SENT = 'init_sent',
  INIT_FAILED = 'init_failed',
  ON_INIT_RECEIVED = 'on_init_received',

  CONFIRM_SENT = 'confirm_sent',
  CONFIRM_FAILED = 'confirm_failed',
  ON_CONFIRM_RECEIVED = 'on_confirm_received',
  ON_CONFIRM_RECEIVED_ERROR = 'on_confirm_received_error',

  PAID = 'paid',

  COMPLETE = 'complete',
  FAILED = 'failed',
}

export enum BppOrderStatus {
  CREATED = 'CREATED',
  ACCEPTED = 'ACCEPTED',

}

export const OrderStatusList = [
  OrderStatus.CREATED,
  OrderStatus.SELECT_REQUESTED,
  OrderStatus.ON_SELECT_RECEIVED,
  OrderStatus.AOF_PENDING,
  OrderStatus.KYC_PENDING,
  OrderStatus.INIT_SENT,
  OrderStatus.ON_INIT_RECEIVED,
  OrderStatus.CONFIRM_SENT,
  OrderStatus.ON_CONFIRM_RECEIVED,
  OrderStatus.COMPLETE,
  OrderStatus.FAILED,
];

export enum FormTypes {
  APPLICATION_FORM = 'APPLICATION_FORM',
  APPLICATION_FORM_WITH_KYC = 'APPLICATION_FORM_WITH_KYC',
  KYC = 'KYC',
  ESIGN = 'ESIGN'
}