// context-builder.service.ts
import { Injectable } from '@nestjs/common';
import { v4 as uuidv4 } from 'uuid';

export interface Payload {
  transactionId: string
  action: 'search' | 'select' | 'init' | 'confirm' | 'status';
  bapId: string;
  bapUri: string;
  bppId?: string;
  bppUri?: string;
  ttl?: string;

  providerId: string;
  itemId: string;
  amount: number,
  fulfillment_id: string,
  fullfillmentType: 'LUMPSUM' | 'SIP' | 'REDEMPTION',
  investorPan: string,
  arn: string,
  euin: string,
  phone: string
}

@Injectable()
export class ContextBuilderService {

  buildContext(params: {
    transactionId: string;
    action: 'search' | 'select' | 'init' | 'confirm' | 'status' | string;
    bapId: string;
    bapUri: string;
    bppId?: string;
    bppUri?: string;
    ttl?: string;
  }) {
    const {
      transactionId,
      action,
      bapId,
      bapUri,
      bppId,
      bppUri,
      ttl = 'PT10M',
    } = params;

    return {
      domain: "ONDC:FIS14",
      location: {
        country: {
          code: 'IND',
        },
        city: {
          code: '*',
        },
      },
      action,
      version: '2.0.0',
      bap_id: bapId,
      bap_uri: bapUri,
      bpp_id: bppId,
      bpp_uri: bppUri,
      transaction_id: transactionId,
      message_id: uuidv4(), // unique per API call
      timestamp: new Date().toISOString(),
      ttl,
    };
  }

  private getItemsOfPayload(itemId: string, amount: number, fulfillment_id: string) {
    return [{
      "id": itemId,
      "quantity": {
        "selected": {
          "measure": {
            "value": amount,
            "unit": "INR"
          }
        }
      },
      "fulfillment_ids": [
        fulfillment_id
      ]
    }]
  };

  private getTagsOfPayload() {
    return [
      {
        display: false,
        descriptor: {
          name: "BAP Terms of Engagement",
          code: "BAP_TERMS"
        },
        list: [
          {
            descriptor: {
              name: "Static Terms (Transaction Level)",
              code: "STATIC_TERMS"
            },
            value: "https://buyerapp.com/legal/ondc:fis14/static_terms?v=0.1"
          },
          {
            descriptor: {
              name: "Offline Contract",
              code: "OFFLINE_CONTRACT"
            },
            value: "true"
          }
        ]
      }
    ]
  }

  private getCustomerData(pan: string, phone: string) {
    return {
      /**
       * {
            "id": "1232132132/32",
            "type": "FOLIO"
          },
       */
      person: {
        id: `pan:${pan}`,
        creds: [
          {
            id: "115.245.207.90",
            type: "IP_ADDRESS"
          }
        ]
      },
      contact: {
        phone: phone
      }
    }
  }

  private getAgentData(arn: string, euin: string) {
    return {
      person: {
        id: euin
      },
      organization: {
        creds: [
          {
            id: arn,
            type: "ARN"
          }
        ]
      }
    }
  }

  private getFullfillmentOfPayload(data:
    {
      fulfillment_id: string,
      type: string,
      pan: string,
      arn: string,
      euin: string,
      phone: string
    }
  ) {
    let fulfillmentsObj = {
      id: data.fulfillment_id,
      type: data.type,
      customer: this.getCustomerData(data.pan, data.phone),
      agent: this.getAgentData(data.arn, data.euin),
    }

    //Need to add stops In case of SIP.
    // "stops": [
    //    {
    //         "time": {
    //             "schedule": {
    //                 "frequency": "R6/2026-05-15/P1M"
    //             }
    //         }
    //     }
    // ]


    return [
      fulfillmentsObj
    ]

  }

  getXinput(formId: string, formSubmissionId: string) {
    return {
      form: {
        id: formId
      },
      form_response: {
        submission_id: formSubmissionId
      }
    }
  }

  buildMessagePayload(params: {
    providerId: string,
    itemId: string,
    amount: number,
    fulfillment_id: string,
    fullfillmentType: 'LUMPSUM' | 'SIP' | 'REDEMPTION',
    investorPan: string,
    arn: string,
    euin: string,
    phone: string
  }) {
    // const context = this.buildContext(params);
    let message = {
      order: {
        provider: {
          "id": params.providerId
        },
        items: this.getItemsOfPayload(params.itemId, params.amount, params.fulfillment_id),
        fulfillments: this.getFullfillmentOfPayload({
          fulfillment_id: params.fulfillment_id,
          type: params.fullfillmentType,
          pan: params.investorPan,
          arn: params.arn,
          euin: params.euin,
          phone: params.phone
        }),
        tags: this.getTagsOfPayload()
      }
    }
    return message;
  }

  buildPayload(data: Payload) {
    let contextPayload = {
      transactionId: data.transactionId,
      action: data.action,
      bapId: data.bapId,
      bapUri: data.bapUri,
      bppId: data.bppId,
      bppUri: data.bppUri,
      ttl: data.ttl
    }

    let messagePayload = {
      providerId: data.providerId,
      itemId: data.itemId,
      amount: data.amount,
      fulfillment_id: data.fulfillment_id,
      fullfillmentType: data.fullfillmentType,
      investorPan: data.investorPan,
      arn: data.arn,
      euin: data.euin,
      phone: data.phone
    }
    return {
      context: this.buildContext(contextPayload),
      message: this.buildMessagePayload(messagePayload)
    }

  }
}
