import { Injectable } from '@nestjs/common';
import { OrderStatus } from './order-status.enum';
import { transitionRules } from './transition-rules';


@Injectable()
export class OrderWorkflowService {
  constructor(

  ) {}



}