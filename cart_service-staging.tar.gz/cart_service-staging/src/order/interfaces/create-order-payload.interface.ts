

export enum OrderType {
  LUMPSUM = 'LUMPSUM',
  SIP = 'SIP',
}

export interface CreateOrderPayloadInput {
  orderType: OrderType;
  transactionId: string;
  messageId: string;
  bapId: string;
  bapUri: string;
  bppId: string;
  bppUri: string;
  providerId: string;
  itemId: string;
  amount: string;
  pan: string;
  euin: string;
  arn: string;
  subBrokerArn: string;
  phone: string;
  bankDetails: {
    accountNumber: string;
    accountName: string;
    bankCode: string;
  };
  paymentId?: string; // for confirm API
  orderId?: string; // for confirm API
  xinput?: {
    formId: string;
    submissionId: string;
  }; // optional, for additional form flows
  schedule?: string; // e.g., for SIP: "R6/2026-05-15/P1M"
}
