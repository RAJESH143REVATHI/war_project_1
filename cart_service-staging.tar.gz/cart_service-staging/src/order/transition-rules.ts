import { FormTypes, OrderStatus } from './order-status.enum';

export const transitionRules = {
  [OrderStatus.ON_SELECT_RECEIVED]: (onSelectPayload) => {
  console.log("🚀 ~ onSelectPayload:", onSelectPayload)

    let xinput = onSelectPayload?.message?.order?.xinput;
    let payments = onSelectPayload?.message?.order?.payments;
    // console.log(xinput,"🚀 ~ payments:", payments)
    let fulfillment = onSelectPayload?.message?.order?.fulfillments[0];

    

    
    if (xinput?.required && xinput?.form?.url && xinput?.form?.id == FormTypes.APPLICATION_FORM_WITH_KYC) return OrderStatus.AOF_PENDING;

    if(xinput?.required && xinput?.form?.url && xinput?.form?.id == FormTypes.APPLICATION_FORM) return OrderStatus.AOF_PENDING;

    // if(xinput?.required  ==false && xinput?.form?.url && xinput?.form?.id == FormTypes.APPLICATION_FORM) return OrderStatus.EXISTING_FOLIO;

    if (xinput?.required && xinput?.form?.url && xinput?.form?.id == FormTypes.KYC) return OrderStatus.KYC_PENDING;
    
    if (xinput?.required && xinput?.form?.url && xinput?.form?.id == FormTypes.ESIGN) return OrderStatus.ESIGN_PENDING;
    
    if(payments && payments.length > 0){
      return OrderStatus.PAYMENT_OPTIONS_RESIVED
    }
    
    // if (!xinput || !xinput?.required || !payments) return OrderStatus.INIT_SENT;

    return OrderStatus.INIT_SENT;
  },
  [OrderStatus.ON_INIT_RECEIVED]: () => OrderStatus.CONFIRM_SENT,
};

export function extractTags(data: any[]): Record<string, string> {
  const result: Record<string, string> = {};

  for (const item of data) {
    if (item.value && item.descriptor?.code) {
      result[item.descriptor.code] = item.value;
    } else if (Array.isArray(item.list)) {
      for (const subItem of item.list) {
        if (subItem.value && subItem.descriptor?.code) {
          result[subItem.descriptor.code] = subItem.value;
        }
      }
    }
  }

  return result;
}