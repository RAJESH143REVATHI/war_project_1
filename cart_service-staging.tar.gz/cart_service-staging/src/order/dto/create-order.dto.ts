// src/order/dto/create-order.dto.ts

import { IsUUID, IsNotEmpty, IsEnum, IsDateString, IsNumber, IsOptional, IsString } from 'class-validator';

export class BaseOrderDto {
  @IsUUID()
  user_id: string;

  @IsNotEmpty()
  transaction_id: string;

  @IsNotEmpty()
  bap_order_id: string;

  @IsNotEmpty()
  bap_id: string;

  @IsNotEmpty()
  bap_uri: string;

  @IsOptional()
  bpp_id?: string;

  @IsOptional()
  bpp_uri?: string;

  @IsNumber()
  amount: number;

  @IsString()
  providerId: string;

  @IsString()
  itemId: string;

  @IsString()
  fulfillment_id: string;

  @IsString()
  fullfillmentType: 'LUMPSUM' | 'SIP' | 'REDEMPTION';

  @IsString()
  investorPan: string;

  @IsString()
  arn: string;

  @IsString()
  euin: string;

  @IsString()
  isin: string;

  @IsString()
  phone: string;
}

export class CreateLumpsumOrderDto extends BaseOrderDto {}

export class CreateSIPOrderDto extends BaseOrderDto {
  @IsDateString()
  sip_start_date: string;

  @IsEnum(['MONTHLY', 'QUARTERLY'])
  sip_frequency: 'MONTHLY' | 'QUARTERLY';

  @IsNumber()
  sip_duration_months: number;
}
