import { IsObject, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { ContextDto } from './common/context.dto';

export class BaseOndcRequestDto<T> {
  @IsObject()
  @ValidateNested()
  @Type(() => ContextDto)
  context: ContextDto;

  @IsObject()
  @ValidateNested()
  @Type()
  message: {
    order: T;
  };
}
