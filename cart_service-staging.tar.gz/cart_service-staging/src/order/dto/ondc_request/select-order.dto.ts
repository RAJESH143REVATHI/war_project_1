import { IsArray, IsObject } from 'class-validator';
import { ProviderDto } from './common/provider.dto';
import { ItemDto, ItemWithPaymentDto, ItemWithQuantityDto } from './common/item.dto';
import { FulfillmentDto } from './common/fulfillment.dto';
import { PaymentDto, PaymentWithIdDto } from './common/payment.dto';
import { TagDto } from './common/tag.dto';

export class SelectOrderDto {
  @IsObject()
  provider: ProviderDto;

  @IsArray()
  items: ItemDto[];

  @IsArray()
  fulfillments?: any[]; // Add specific DTO if needed

  @IsArray()
  payments?: any[]; // Optional depending on flow

  @IsArray()
  tags?: TagDto[];
}
