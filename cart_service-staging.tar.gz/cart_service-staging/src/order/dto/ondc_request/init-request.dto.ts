import { BaseOndcRequestDto } from './base-request.dto';
import { InitOrderDto } from './init-order.dto';

export class InitRequestDto extends BaseOndcRequestDto<InitOrderDto> {}
