import { BaseOndcRequestDto } from './base-request.dto';
import { SelectOrderDto } from './select-order.dto';

export class SelectRequestDto extends BaseOndcRequestDto<SelectOrderDto> {}
