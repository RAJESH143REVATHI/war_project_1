// dto/common/xinput.dto.ts
import { IsString, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class FormDto {
  @IsString()
  id: string;
}

class SubmissionDto {
  @IsString()
  id: string;
}

export class XInputDto {
  @ValidateNested()
  @Type(() => FormDto)
  form: FormDto;

  @ValidateNested()
  @Type(() => SubmissionDto)
  submission: SubmissionDto;
}

// export default XInputDto;