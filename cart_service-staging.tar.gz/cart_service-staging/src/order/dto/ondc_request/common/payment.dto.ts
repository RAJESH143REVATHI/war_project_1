import { IsString, IsObject, IsArray, ValidateNested, IsOptional } from 'class-validator';
import { Type } from 'class-transformer';

class PaymentParamsDto {
  @IsString()
  amount: string;

  @IsString()
  currency: string;

  @IsString()
  source_bank_code: string;

  @IsString()
  source_bank_account_number: string;

  @IsString()
  source_bank_account_name: string;

  @IsString()
  @IsOptional()
  transaction_id?: string;
}

class TagListItemDto {
  @IsObject()
  descriptor: {
    code: string;
  };

  @IsString()
  value: string;
}

class TagGroupDto {
  @IsObject()
  descriptor: {
    name: string;
    code: string;
  };

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => TagListItemDto)
  list: TagListItemDto[];
}

export class PaymentDto {
  @IsString()
  collected_by: string;

  @IsObject()
  @ValidateNested()
  @Type(() => PaymentParamsDto)
  params: PaymentParamsDto;

  @IsString()
  type: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => TagGroupDto)
  tags: TagGroupDto[];
}

export class PaymentWithIdDto extends PaymentDto {
  @IsString()
  id: string;

  @IsString()
  status: string;
}
