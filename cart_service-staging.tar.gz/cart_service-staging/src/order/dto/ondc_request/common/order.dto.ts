// dto/common/order.dto.ts
import { IsArray, IsOptional, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { ProviderDto } from './provider.dto';
import { ItemDto } from './item.dto';
import { FulfillmentDto } from './fulfillment.dto';
import { PaymentDto } from './payment.dto';
import { TagDto } from './tag.dto';
import { XInputDto } from './xinput.dto';

export class OrderDto {
  @ValidateNested()
  @Type(() => ProviderDto)
  provider: ProviderDto;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ItemDto)
  items: ItemDto[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => FulfillmentDto)
  fulfillments: FulfillmentDto[];

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => TagDto)
  tags: TagDto[];

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => PaymentDto)
  payments?: PaymentDto[];

  @IsOptional()
  @ValidateNested()
  @Type(() => XInputDto)
  xinput?: XInputDto;

  @IsOptional()
  id?: string; // Used in confirm payload
}
