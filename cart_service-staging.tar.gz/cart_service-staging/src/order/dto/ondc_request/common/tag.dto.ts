import { IsBoolean, IsObject, IsArray, ValidateNested, IsString } from 'class-validator';
import { Type } from 'class-transformer';

class TagDescriptorDto {
  @IsString()
  name: string;

  @IsString()
  code: string;
}

class TagListEntryDto {
  @IsObject()
  descriptor: TagDescriptorDto;

  @IsString()
  value: string;
}

export class TagDto {
  @IsBoolean()
  display: boolean;

  @IsObject()
  descriptor: TagDescriptorDto;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => TagListEntryDto)
  list: TagListEntryDto[];
}
