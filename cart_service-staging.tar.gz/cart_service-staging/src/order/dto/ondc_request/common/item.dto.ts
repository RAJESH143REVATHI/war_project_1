import { IsString, IsArray, IsObject, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class QuantityMeasureDto {
  @IsString()
  value: string;

  @IsString()
  unit: string;
}

class QuantityDto {
  @IsObject()
  @ValidateNested()
  @Type(() => QuantityMeasureDto)
  selected: QuantityMeasureDto;
}

export class ItemDto {
  @IsString()
  id: string;
}

export class ItemWithQuantityDto extends ItemDto {
  @IsObject()
  @ValidateNested()
  @Type(() => QuantityDto)
  quantity: QuantityDto;
}

export class ItemWithPaymentDto extends ItemWithQuantityDto {
  @IsArray()
  fulfillment_ids: string[];

  @IsArray()
  payment_ids: string[];
}
