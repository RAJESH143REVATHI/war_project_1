import { IsString } from 'class-validator';

export class ProviderDto {
  @IsString()
  id: string;
}
