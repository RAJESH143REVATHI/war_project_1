import { IsString, IsObject, IsArray, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';

class CredentialDto {
  @IsString()
  id: string;

  @IsString()
  type: string;
}

class PersonDto {
  @IsString()
  id: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CredentialDto)
  creds: CredentialDto[];
}

class ContactDto {
  @IsString()
  phone: string;
}

class CustomerDto {
  @IsObject()
  @ValidateNested()
  @Type(() => PersonDto)
  person: PersonDto;

  @IsObject()
  @ValidateNested()
  @Type(() => ContactDto)
  contact: ContactDto;
}

class AgentDto {
  @IsObject()
  @ValidateNested()
  @Type(() => PersonDto)
  person: PersonDto;

  @IsObject()
  @ValidateNested()
  @Type(() => OrganizationDto)
  organization: OrganizationDto;
}

class OrganizationDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CredentialDto)
  creds: CredentialDto[];
}

export class FulfillmentDto {
  @IsString()
  id: string;

  @IsString()
  type: string;

  @IsObject()
  @ValidateNested()
  @Type(() => CustomerDto)
  customer: CustomerDto;

  @IsObject()
  @ValidateNested()
  @Type(() => AgentDto)
  agent: AgentDto;

  // Optional if you want to handle stops (for SIP)
  // stops?: StopDto[];
}
