import { IsString, IsOptional, IsObject } from 'class-validator';

class LocationDto {
  @IsObject()
  country: {
    code: string;
  };

  @IsObject()
  city: {
    code: string;
  };
}

export class ContextDto {
  @IsOptional()
  @IsObject()
  location?: LocationDto;

  @IsString()
  domain: string;

  @IsString()
  action: string;

  @IsString()
  version: string;

  @IsString()
  bap_id: string;

  @IsString()
  bap_uri: string;

  @IsString()
  bpp_id: string;

  @IsString()
  bpp_uri: string;

  @IsString()
  transaction_id: string;

  @IsString()
  message_id: string;

  @IsString()
  timestamp: string;

  @IsString()
  ttl: string;
}
