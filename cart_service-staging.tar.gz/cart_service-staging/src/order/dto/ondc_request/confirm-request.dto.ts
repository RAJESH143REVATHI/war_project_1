import { BaseOndcRequestDto } from './base-request.dto';
import { ConfirmOrderDto } from './confirm-order.dto';

export class ConfirmRequestDto extends BaseOndcRequestDto<ConfirmOrderDto> {}
