import { IsArray, IsObject } from 'class-validator';

import { ProviderDto } from './common/provider.dto';
import { ItemWithPaymentDto } from './common/item.dto';
import { FulfillmentDto } from './common/fulfillment.dto';
import { PaymentWithIdDto } from './common/payment.dto';
import { TagDto } from './common/tag.dto';

export class ConfirmOrderDto {
  @IsObject()
  provider: ProviderDto;

  @IsArray()
  items: ItemWithPaymentDto[];

  @IsArray()
  fulfillments: FulfillmentDto[];

  @IsArray()
  payments: PaymentWithIdDto[];

  @IsArray()
  tags?: TagDto[];
}
