// import { Injectable } from '@nestjs/common';
// import { v4 as uuidv4 } from 'uuid';
// // import { SelectRequestDto } from './dto/select-request.dto';
// // import { InitRequestDto } from './dto/init-request.dto';
// // import { ConfirmRequestDto } from './dto/confirm-request.dto';
// // import { ContextDto } from './dto/common/context.dto';
// // import { OrderDto } from './dto/common/order.dto';
// // import { OrderType } from './enums/order-type.enum'; // e.g., 'LUMPSUM' | 'SIP'
// // import { CreateOrderPayloadInput } from './interfaces/create-order-payload.interface';
// import { ContextDto } from './dto/ondc_request/common/context.dto';
// import { SelectRequestDto } from './dto/ondc_request/select-request.dto';
// import { InitRequestDto } from './dto/ondc_request/init-request.dto';
// import { ConfirmRequestDto } from './dto/ondc_request/confirm-request.dto';
// import { OrderDto } from './dto/ondc_request/common/order.dto';
// import { CreateOrderPayloadInput, OrderType } from './interfaces/create-order-payload.interface';

// @Injectable()
// export class OndcPayloadService {
//     createContext(action: string, data: Partial<ContextDto>): ContextDto {
//         return {
//             domain: 'ONDC:FIS14',
//             location: {
//                 country: { code: 'IND', },
//                 city: { code: '*' }
//             },
//             version: '2.0.0',
//             ttl: 'PT10M',
//             timestamp: new Date().toISOString(),
//             transaction_id: data.transaction_id || uuidv4(),
//             message_id: uuidv4(),
//             bap_id: data.bap_id || '',
//             bap_uri: data.bap_uri || '',
//             bpp_id: data.bpp_id || '',
//             bpp_uri: data.bpp_uri || '',
//             action,
//         };
//     }

//     createOrder(input: CreateOrderPayloadInput): OrderDto {
//         const isSIP = input.orderType === OrderType.SIP;

//         const fulfillments = [
//             {
//                 id: input.fulfillmentId,
//                 type: input.orderType,
//                 customer: input.customer,
//                 agent: input.agent,
//                 ...(isSIP && input.sipSchedule
//                     ? {
//                         stops: [
//                             {
//                                 time: {
//                                     schedule: {
//                                         frequency: input.sipSchedule,
//                                     },
//                                 },
//                             },
//                         ],
//                     }
//                     : {}),
//             },
//         ];

//         return {
//             id: input.orderId,
//             provider: {
//                 id: input.providerId,
//             },
//             items: input.items,
//             fulfillments,
//             payments: input.payments,
//             tags: input.tags,
//             ...(input.xinput ? { xinput: input.xinput } : {}),
//         };
//     }

//     buildSelectPayload(input: CreateOrderPayloadInput): SelectRequestDto {
//         return {
//             context: this.createContext('select', input.context),
//             message: {
//                 order: this.createOrder(input),
//             },
//         };
//     }

//     buildInitPayload(input: CreateOrderPayloadInput): InitRequestDto {
//         return {
//             context: this.createContext('init', input.context),
//             message: {
//                 order: this.createOrder(input),
//             },
//         };
//     }

//     buildConfirmPayload(input: CreateOrderPayloadInput): ConfirmRequestDto {
//         return {
//             context: this.createContext('confirm', input.context),
//             message: {
//                 order: this.createOrder(input),
//             },
//         };
//     }
// }
