import { Injectable, InternalServerErrorException } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { ClientProxy } from "@nestjs/microservices";
// import { OrderEntity } from "src/entity/order.entity";
import { RmqService } from "src/shared/rmq.service";
import { TenantAwareRepositoryService } from "src/shared/tenant-aware-repository.service";
import { CreateLumpsumOrderDto, CreateSIPOrderDto } from "./dto/create-order.dto";
// import { UUID } from "typeorm/driver/mongodb/bson.typings";
import { randomUUID, UUID } from "crypto";
import { v4 as UUIDv4 } from 'uuid'
import { ContextBuilderService } from "./context-builder.service";
import { makeApiCall } from "src/utils/http-utils";
import { TenantOrderMapRepository } from "src/mongoose/repositories/tenantordermap.repository";
import { TenantTransactionHelper } from "src/shared/tenant-transaction.helper";
import { AofSubmissionService } from "./aof-submission/aof-submission.service";
import { BppOrderStatus, FormTypes,  } from "./order-status.enum";
import { extractTags, transitionRules } from "./transition-rules";
import { MqService } from "src/consumer/mq.service";
// import { PaymentEntity } from "src/entity/payment.entity";

import { OrderEntity,PaymentEntity,OrderStatus } from "@npstx/pg-entities";

@Injectable()
export class OrderService {
    private transactionTenantMap = new Map<string, string>();
    // private client: ClientProxy
    constructor(
        // private readonly rmqService: RmqService,
        private readonly mqService: MqService,
        private readonly configService: ConfigService,
        private readonly tenantRepo: TenantAwareRepositoryService,
        private readonly contextBuilderService: ContextBuilderService,
        private readonly tnantOrderMapRepo: TenantOrderMapRepository,
        private readonly aofSubmissionService: AofSubmissionService
    ) { }

    onModuleInit() {
        let queue = this.configService.get('rabbitmq.queue')
        // this.client = this.rmqService.createClient(queue)
    }
    getHello(): string {
        return "Hello World!";
    }

    private async findTenantIdByTransactionId(transactionId: string): Promise<string> {
        let tenantId = this.transactionTenantMap.get(transactionId);
        if (!tenantId) {
            const tenantMap = await this.tnantOrderMapRepo.findOne({ transaction_id: transactionId });
            if (!tenantMap) {
                throw new Error(`Tenant not found for transaction_id ${transactionId}`);
            }
            tenantId = tenantMap.tenant_id;
            this.transactionTenantMap.set(transactionId, tenantId);
        }

        return tenantId;

    }

    private async makeSelectRequest(payload: any): Promise<any> {
        const url = 'https://test-ondc.timepayonline.com/select';
        let select_ack;
        let success = false;

        console.log("🚀 ~ Make Select Request with Payload -: ", JSON.stringify(payload))

        // for (let attempt = 1; attempt <= 3; attempt++) {
        try {
            select_ack = await makeApiCall(url, 'POST', payload);
            console.log("🚀 ~ OrderService ~ select_ack:", select_ack)

            // Cache in memory
            // this.transactionTenantMap.set(transaction_id, tenantId);

            if (select_ack?.message?.ack?.status === 'ACK') {
                success = true;
                return { success, select_ack };
            } else {
                return { success, select_ack };
            }

        } catch (err) {
            console.warn(`ONDC select failed:`, err.message);
        }
        // }
    }

    private async makeInitRequest(payload: any): Promise<any> {
        const url = 'https://test-ondc.timepayonline.com/init';
        let init_ack;
        let success = false;

        // for (let attempt = 1; attempt <= 3; attempt++) {
        try {
            init_ack = await makeApiCall(url, 'POST', payload);
            console.log(JSON.stringify(payload), "🚀 ~ OrderService ~ init_ack:", init_ack)

            // Cache in memory
            // this.transactionTenantMap.set(transaction_id, tenantId);

            if (init_ack?.message?.ack?.status === 'ACK') {
                success = true;
                return { success, init_ack };
            } else {
                return { success, init_ack };
            }

        } catch (err) {
            console.warn(`ONDC select failed:`, err.message);
        }
        // }
    }

    private async makeConfirmRequest(payload: any): Promise<any> {
        const url = 'https://test-ondc.timepayonline.com/confirm';
        let init_ack;
        let success = false;

        // for (let attempt = 1; attempt <= 3; attempt++) {
        try {
            init_ack = await makeApiCall(url, 'POST', payload);
            console.log(JSON.stringify(payload), "🚀 ~ OrderService ~ init_ack:", init_ack)

            // Cache in memory
            // this.transactionTenantMap.set(transaction_id, tenantId);

            if (init_ack?.message?.ack?.status === 'ACK') {
                success = true;
                return { success, init_ack };
            } else {
                return { success, init_ack };
            }

        } catch (err) {
            console.warn(`ONDC select failed:`, err.message);
        }
        // }
    }

    /**
     * 
     * @param tenantId 
     * @param dto 
     * @returns 
     */

    async createOrder(tenantId: string, dto: CreateLumpsumOrderDto) {
        const transaction_id = UUIDv4();
        const bap_order_id = UUIDv4();

        // const ondc_data_url = `https://test-ondc.timepayonline.com/gateway/catalog/getOndcFundData?isin=${dto.isin}`;
        // const ondcFundData = await makeApiCall(ondc_data_url, 'GET');

        // if (!ondcFundData) {
        //     throw new InternalServerErrorException("Invalid ISIN");
        // }

        const payload = this.contextBuilderService.buildPayload({
            transactionId: transaction_id,
            action: 'select',
            bapId: dto.bap_id,
            bapUri: dto.bap_uri,
            bppId: dto.bpp_id,
            bppUri: dto.bpp_uri,
            ttl: 'PT10M',
            providerId: dto.providerId,
            itemId: dto.itemId,
            amount: dto.amount,
            fulfillment_id: dto.fulfillment_id,
            fullfillmentType: dto.fullfillmentType,
            investorPan: dto.investorPan,
            arn: dto.arn,
            euin: dto.euin,
            phone: dto.phone
        });
        console.log("🚀 ~ OrderService ~ createOrder ~ payload:", JSON.stringify(payload))


        // return payload;

        let createdOrder;
        let selectAckError = false

        try {
            await this.tenantRepo.transaction(
                tenantId,
                async (manager) => {
                    const txnHelper = new TenantTransactionHelper(manager);

                    // Step 1: Call ONDC Select API with up to 2 retries
                    const url = 'https://test-ondc.timepayonline.com/select';
                    let select_ack;
                    let success = false;

                    for (let attempt = 1; attempt <= 3; attempt++) {
                        try {
                            select_ack = await makeApiCall(url, 'POST', payload);
                            console.log("🚀 ~ OrderService ~ select_ack:", select_ack)

                            // Cache in memory
                            this.transactionTenantMap.set(transaction_id, tenantId);

                            if (select_ack?.message?.ack?.status === 'ACK') {
                                success = true;
                                break;
                            } else if (select_ack?.message?.ack?.status === 'NACK') {
                                createdOrder = select_ack
                                selectAckError = true
                                break;
                            }
                        } catch (err) {
                            console.warn(`ONDC select retry ${attempt} failed:`, err.message);
                        }
                    }

                    // if (!success) {
                    //     throw new InternalServerErrorException('ONDC Select failed after retries');
                    // }

                    if (selectAckError) {
                        return createdOrder
                    }

                    // Step 3: Insert mapping to MongoDB outside the transaction
                    await this.tnantOrderMapRepo.create({
                        transaction_id,
                        tenant_id: tenantId,
                    });


                    // Step 2: Save the order in the transaction only if ONDC call succeeded
                    createdOrder = await txnHelper.create(OrderEntity, {
                        id: transaction_id,
                        user_id: dto.user_id,
                        transaction_id,
                        bap_order_id,
                        bap_id: dto.bap_id,
                        bap_uri: dto.bap_uri,
                        bpp_id: dto.bpp_id,
                        bpp_uri: dto.bpp_uri,
                        status: OrderStatus.SELECT_REQUESTED,
                        investment_type: 'LUMPSUM',
                        amount: dto.amount,
                        select_context: payload,
                    });
                });



            return createdOrder;
        } catch (err) {
            console.error(`Order creation failed: ${err.message}`);
            throw new InternalServerErrorException('Failed to create order', err.message);
        }

    }

    async getOnSelectRes(data: any): Promise<any> {
        const context = data?.context;
        const transactionId = context?.transaction_id;

        if (!transactionId) {
            throw new Error('Missing transaction_id in ONDC callback');
        }

        const tenantId = await this.findTenantIdByTransactionId(transactionId);

        // Wrap update logic inside transaction
        let action = await this.tenantRepo.transaction(tenantId, async (manager) => {
            const txnHelper = new TenantTransactionHelper(manager);

            // manager.queryRunner?.commitTransaction();


            const order = await txnHelper.findById(OrderEntity, transactionId);

            if (!order) {
                throw new Error(`Order not found in tenant DB for txn ${transactionId}`);
            }

            let currentStatus = order.status;
            console.log("On_SELECT_LISTNER ---->################===========>", currentStatus)
            let fulfillment = data?.message?.order?.fulfillments[0];

            const fulfillment_tags = extractTags(fulfillment.tags) || {};

            console.log(JSON.stringify(fulfillment.tags),"🚀 ~ OrderService ~ action ~ fulfillment_tags:", fulfillment_tags);
            switch (currentStatus) {
                case OrderStatus.SELECT_REQUESTED:

                    if (data?.error) {
                        await txnHelper.update(OrderEntity, order.id, {
                            status: OrderStatus.ON_SELECT_RECEIVED_ERROR,
                            hasError: true,
                            error_response: data,
                            fulfillment_tags:fulfillment_tags
                        });
                        return true;
                    }

                    await txnHelper.update(OrderEntity, order.id, {
                        on_select_payload: data,
                        status: OrderStatus.ON_SELECT_RECEIVED,
                        fulfillment_tags:fulfillment_tags
                    });

                    // currentStatus = OrderStatus.ON_SELECT_RECEIVED

                    break;
                case OrderStatus.AOF_SELECT_REQUESTED:

                    if (data?.error) {
                        await txnHelper.update(OrderEntity, order.id, {
                            status: OrderStatus.AOF_SELECT_RECEIVED_ERROR,
                            hasError: true,
                            error_response: data,
                            fulfillment_tags:fulfillment_tags
                        });
                        return true;
                    }

                    await txnHelper.update(OrderEntity, order.id, {
                        aof_select_payload: data,
                        status: OrderStatus.AOF_SELECT_RECEIVED,
                        fulfillment_tags:fulfillment_tags
                    })

                    // currentStatus = OrderStatus.AOF_SELECT_RECEIVED

                    break;
                case OrderStatus.KYC_SELECT_REQUESTED:

                    if (data?.error) {
                        await txnHelper.update(OrderEntity, order.id, {
                            status: OrderStatus.KYC_SELECT_RECEIVED_ERROR,
                            hasError: true,
                            error_response: data,
                            fulfillment_tags:fulfillment_tags
                        });
                        return true;
                    }

                    await txnHelper.update(OrderEntity, order.id, {
                        kyc_select_payload: data,
                        status: OrderStatus.KYC_SELECT_RECEIVED,
                        fulfillment_tags:fulfillment_tags
                    })

                    break;

                case OrderStatus.ESIGN_SELECT_REQUESTED || OrderStatus.ESIGN_SUBMITTED:

                    if (data?.error) {
                        await txnHelper.update(OrderEntity, order.id, {
                            status: OrderStatus.ESIGN_SELECT_RECEIVED_ERROR,
                            hasError: true,
                            error_response: data,
                            fulfillment_tags:fulfillment_tags
                        });
                        return true;
                    }

                    await txnHelper.update(OrderEntity, order.id, {
                        esign_select_payload: data,
                        status: OrderStatus.ESIGN_SELECT_RECEIVED,
                        fulfillment_tags:fulfillment_tags
                    })

                    break;

                case OrderStatus.COMPLETE:
                    return true
                    break;
                case OrderStatus.FAILED:
                    return true;
                    break;
                case OrderStatus.ON_CONFIRM_RECEIVED:
                    return true;
                    break;
                case OrderStatus.ON_INIT_RECEIVED:
                    return true;
                    break;
                case OrderStatus.CONFIRM_SENT:
                    return true;
                    break;
                case OrderStatus.INIT_SENT:
                    return true;
                    break;

                default:
                    break;
            }

            const nextState = transitionRules[OrderStatus.ON_SELECT_RECEIVED](data);
            let xinput = data?.message?.order?.xinput;
            console.log("🚀 ~ OrderService ~ returnawaitthis.tenantRepo.transaction ~ nextState:", nextState)


            switch (nextState) {
                case OrderStatus.AOF_PENDING:
                    let order1 = await txnHelper.update(OrderEntity, order.id, {
                        status: OrderStatus.AOF_PENDING,
                        next_required_form: xinput,
                        fulfillment_tags:fulfillment_tags
                    });
                    console.log("iiiiiiiiii===========>", order1.status);

                    return order1.status;
                    // manager.queryRunner?.commitTransaction();

                    // let queuePaload = {
                    //     type: FormTypes.APPLICATION_FORM_WITH_KYC,
                    //     orderId: order.id,
                    // }

                    // await this.mqService.publishMessage('form_handler', queuePaload);

                    break;
                case OrderStatus.KYC_PENDING:
                    await txnHelper.update(OrderEntity, order.id, {
                        status: OrderStatus.KYC_PENDING,
                        next_required_form: xinput,
                        user_action_required: true,
                        fulfillment_tags:fulfillment_tags
                    });
                    /**
                     * Need User Action here.
                     */
                    break;

                case OrderStatus.ESIGN_PENDING:
                    await txnHelper.update(OrderEntity, order.id, {
                        status: OrderStatus.ESIGN_PENDING,
                        next_required_form: xinput,
                        user_action_required: true,
                        fulfillment_tags:fulfillment_tags
                    });
                    /**
                     * Need User Action here.
                     */
                    break;

                case OrderStatus.PAYMENT_OPTIONS_RESIVED:
                    await txnHelper.update(OrderEntity, order.id, {
                        status: OrderStatus.PAYMENT_OPTIONS_RESIVED,
                        next_required_form: null,
                        user_action_required: true,
                        payments_options: data?.message?.order?.payments,
                        fulfillment_tags:fulfillment_tags
                    });
                    /**
                     * Need User Action here.
                     */
                    break;

                default:
                    break;
            }

            // return true;
        });

        if (action === OrderStatus.AOF_PENDING) {
            let queuePaload = {
                type: FormTypes.APPLICATION_FORM_WITH_KYC,
                orderId: transactionId,
            }

            await this.mqService.publishMessage('form_handler', queuePaload);
        }

        return true;
    }

    async handleAofSubmission(orderId: string): Promise<any> {
        const tenantId = await this.findTenantIdByTransactionId(orderId);

        const aofSuccess = await this.tenantRepo.transaction(tenantId, async (manager) => {
            const txnHelper = new TenantTransactionHelper(manager);

            const order = await txnHelper.findById(OrderEntity, orderId);

            if (!order) {
                throw new Error(`Order not found in tenant DB for txn ${orderId}`);
            }

            const currentStatus = order?.status;

            if (currentStatus === OrderStatus.AOF_SUBMITTED) {
                return true;
            }

            console.log("AOF Submission Handler ---> @@@@@@@@======>", currentStatus);
            if (currentStatus === OrderStatus.AOF_PENDING) {
                let on_select_payload = order?.on_select_payload;

                if (!on_select_payload) {
                    throw new Error(`Missing on_select_payload in order ${orderId}`);
                }

                let xinput = order.next_required_form;
                console.log("🚀 ~ AOF Submission Handler ~ xinput:", xinput)

                // Need proper error handling in autoSubmitForm.
                let { status, aofRes } = await this.aofSubmissionService.autoSubmitForm({
                    transactionId: orderId,
                    tenantId,
                    formUrl: xinput.form.url,
                    userId: order.user_id
                });


                if (!status) {
                    await txnHelper.update(OrderEntity, order.id, {
                        status: OrderStatus.AOF_ERROR,
                        aof_error: aofRes
                    });
                    throw new Error(`Failed to submit AOF for order ${orderId}`);
                }

                await txnHelper.update(OrderEntity, order.id, {
                    status: OrderStatus.AOF_SUBMITTED,
                    aof_response: aofRes
                });

                return true
            }
        });

        if (aofSuccess) {
            this.selectFormSubmission(orderId)
        }
        return aofSuccess

    }

    async selectFormSubmission(orderId): Promise<any> {

        let tenantId = await this.findTenantIdByTransactionId(orderId);
        let currentAction;
        let selectPayload;

        await this.tenantRepo.transaction(tenantId, async (manager) => {
            const txnHelper = new TenantTransactionHelper(manager);

            const order = await txnHelper.findById(OrderEntity, orderId);


            if (!order) {
                throw new Error(`Order not found in tenant DB for txn ${orderId}`);
            }
            // console.log("🚀 ~ OrderService ~ awaitthis.tenantRepo.transaction ~ order:", order?.select_context);

            const currentStatus = order?.status;
            console.log("🚀 FROM selectFormSubmission $$$$$$$$$$======>", currentStatus)

            let xinput = order?.next_required_form;
            let payload = order?.select_context;
            payload.context.message_id = UUIDv4();
            payload.context.timestamp = new Date().toISOString();

            switch (currentStatus) {
                case OrderStatus.AOF_SUBMITTED:

                    let submission_id = order?.aof_response?.submission_id;

                    // let on_select_payload = order?.on_select_payload;


                    payload.message.order.xinput = this.contextBuilderService.getXinput(xinput.form.id, submission_id);

                    // let { success, select_ack } = await this.makeSelectRequest(payload);

                    // if (success) {
                    let order1 = await txnHelper.update(OrderEntity, order.id, {
                        status: OrderStatus.AOF_SELECT_REQUESTED,
                        aof_select_context: payload,
                        aof_form: payload.message.order.xinput
                    });
                    // }
                    currentAction = order1?.status;
                    selectPayload = payload;

                    break;

                case OrderStatus.KYC_SUBMITTED:

                    let kyc_submission_id = order?.kyc_response?.submission_id;

                    payload.message.order.xinput = this.contextBuilderService.getXinput(xinput.form.id, kyc_submission_id);

                    // let kycSelectAck = await this.makeSelectRequest(payload);
                    // console.log("🚀 ~ OrderService ~ awaitthis.tenantRepo.transaction ~ kycSelectAck:", kycSelectAck)

                    // if (kycSelectAck.success) {
                    let order2 = await txnHelper.update(OrderEntity, order.id, {
                        status: OrderStatus.KYC_SELECT_REQUESTED,
                        kyc_select_context: payload
                    });
                    // }

                    currentAction = order2?.status;
                    selectPayload = payload;

                    break;

                case OrderStatus.ESIGN_SUBMITTED:

                    let esign_submission_id = order?.esign_response?.submission_id;
                    payload.message.order.xinput = this.contextBuilderService.getXinput(xinput.form.id, esign_submission_id);

                    // let esignSelectAck = await this.makeSelectRequest(payload);
                    // console.log("🚀 ~ OrderService ~ awaitthis.tenantRepo.transaction ~ kycSelectAck:", esignSelectAck)

                    // if (esignSelectAck.success) {
                    let order3 = await txnHelper.update(OrderEntity, order.id, {
                        status: OrderStatus.ESIGN_SELECT_REQUESTED,
                        esign_select_context: payload
                    });
                    // }

                    currentAction = order3?.status;
                    selectPayload = payload;

                    break;
                default:
                    break;
            }


        })

        if (currentAction == OrderStatus.AOF_SELECT_REQUESTED || currentAction == OrderStatus.KYC_SELECT_REQUESTED || currentAction == OrderStatus.ESIGN_SELECT_REQUESTED) {
            let { success, select_ack } = await this.makeSelectRequest(selectPayload);
            console.log(success, "🚀 ~ OrderService ~ select_ack:", select_ack)
            return { success, select_ack }
        }

    }

    async getOnStatusRes(data: any): Promise<any> {
        const context = data?.context;
        const transactionId = context?.transaction_id;

        if (!transactionId) {
            throw new Error('Missing transaction_id in ONDC callback');
        }

        const tenantId = await this.findTenantIdByTransactionId(transactionId);

        let status = await this.tenantRepo.transaction(tenantId, async (manager) => {
            const txnHelper = new TenantTransactionHelper(manager);

            const order = await txnHelper.findById(OrderEntity, transactionId);

            if (!order) {
                throw new Error(`Order not found in tenant DB for txn ${transactionId}`);
            }

            const currentStatus = order?.status;

            let newStatusXinput = data?.message?.order?.xinput;


            if (
                newStatusXinput?.form?.id === FormTypes.KYC &&
                currentStatus == OrderStatus.KYC_PENDING
            ) {
                await txnHelper.update(OrderEntity, order.id, {
                    status: OrderStatus.KYC_SUBMITTED,
                    on_status_kyc_payload: data,
                    kyc_response: newStatusXinput?.form_response,
                    user_action_required: false
                });

                return true

            } else if (
                newStatusXinput?.form?.id === FormTypes.ESIGN &&
                currentStatus == OrderStatus.ESIGN_PENDING
            ) {
                await txnHelper.update(OrderEntity, order.id, {
                    status: OrderStatus.ESIGN_SUBMITTED,
                    on_status_esign_payload: data,
                    esign_response: newStatusXinput?.form_response,
                    user_action_required: false
                });

                return true
            } if (currentStatus == OrderStatus.ON_CONFIRM_RECEIVED && order?.order_status == BppOrderStatus.ACCEPTED) {
                let payment = await this.tenantRepo.findOne(tenantId, PaymentEntity, { order_id: transactionId });
                let currentPayment = data?.message?.order?.payments[0]
                if (payment) {
                    await txnHelper.update(PaymentEntity, payment.id, {
                        status: currentPayment?.status
                    });
                }

                await txnHelper.update(OrderEntity, order.id, {
                    status: OrderStatus.PAID,
                    on_status_payment_payload: data,
                    order_status: data?.message?.order?.status,
                    user_action_required: false
                });

                return false

            } else {
                console.log('=============Condition not matched================')
                return false
            }

        });

        if (status) {
            this.selectFormSubmission(transactionId)
        }
        return status

    }

    /**
     * selectPaymentOptions --> Triggred By User 
     * @param orderId 
     * @param payment 
     */
    async selectPaymentOptions(orderId: string, payment: any): Promise<any> {

        const tenantId = await this.findTenantIdByTransactionId(orderId);

        const status = await this.tenantRepo.transaction(tenantId, async (manager) => {
            const txnHelper = new TenantTransactionHelper(manager);

            const order = await txnHelper.findById(OrderEntity, orderId);

            if (!order) {
                throw new Error(`Order not found in tenant DB for txn ${orderId}`);
            }

            await txnHelper.update(OrderEntity, order.id, {
                status: OrderStatus.PAYMENT_OPTION_SELECTED,
                selected_payment: payment,
                user_action_required: false
            });

            return true
        });

        if (status) {
            // Call init API.
            this.initApiCall(orderId)
        }
        return status

    }

    async initApiCall(orderId: string): Promise<any> {
        const tenantId = await this.findTenantIdByTransactionId(orderId);
        let payload;

        const status = await this.tenantRepo.transaction(tenantId, async (manager) => {
            const txnHelper = new TenantTransactionHelper(manager);

            const order = await txnHelper.findById(OrderEntity, orderId);

            if (!order) {
                throw new Error(`Order not found in tenant DB for txn ${orderId}`);
            }

            let fulfillment_tags = order.fulfillment_tags

            

            payload = order.select_context;
            payload.context.message_id = UUIDv4();
            payload.context.timestamp = new Date().toISOString();
            payload.context.action = 'init';

            payload.message.order.payments = order?.selected_payment;

            
            if(fulfillment_tags && fulfillment_tags.FOLIO_NUMBER){
                payload.message.order.fulfillments[0].customer.person.creds.push({
                    "type": "FOLIO",
                    "id": fulfillment_tags.FOLIO_NUMBER
                })
            }else{
                payload.message.order.xinput = order?.aof_form || {};
            }
            console.log("🚀 ~ OrderService ~ status ~ payload:", JSON.stringify(payload))

            const init_ack = await this.makeInitRequest(payload);

            if (init_ack.success) {
                await txnHelper.update(OrderEntity, order.id, {
                    status: OrderStatus.INIT_SENT,
                    user_action_required: false,
                    init_context: payload
                });
            } else {
                await txnHelper.update(OrderEntity, order.id, {
                    status: OrderStatus.INIT_FAILED,
                    user_action_required: false,
                    init_context: payload
                });
            }
            return true
        });

        // if (status) {
        //     await this.makeInitRequest(payload)
        // }
        return status
    }

    async onInitRes(data: any): Promise<any> {
        const context = data?.context;
        const transactionId = context?.transaction_id;

        if (!transactionId) {
            throw new Error('Missing transaction_id in ONDC callback');
        }

        const tenantId = await this.findTenantIdByTransactionId(transactionId);

        let status = await this.tenantRepo.transaction(tenantId, async (manager) => {
            const txnHelper = new TenantTransactionHelper(manager);

            const order = await txnHelper.findById(OrderEntity, transactionId);

            const payments = data.message.order.payments;

            if (!order) {
                throw new Error(`Order not found in tenant DB for txn ${transactionId}`);
            }

            // Save payment records
            for (const payment of payments) {
                const paymentEntity = new PaymentEntity();
                paymentEntity.id = payment.id;
                paymentEntity.order_id = order.id;
                paymentEntity.collected_by = payment.collected_by;
                paymentEntity.url = payment.url;
                paymentEntity.amount = parseFloat(payment.params?.amount || '0');
                paymentEntity.currency = payment.params?.currency || 'INR';
                paymentEntity.source_bank_code = payment.params?.source_bank_code || '';
                paymentEntity.source_bank_account_number = payment.params?.source_bank_account_number || '';
                paymentEntity.source_bank_account_name = payment.params?.source_bank_account_name || '';
                paymentEntity.type = payment.type;
                paymentEntity.status = payment.status;
                paymentEntity.tags = payment.tags || [];
                paymentEntity.order_status = data?.message?.order?.status;

                await txnHelper.create(PaymentEntity, paymentEntity);
            }

            await txnHelper.update(OrderEntity, order.id, {
                bpp_order_id: data?.message?.order?.id,
                status: OrderStatus.ON_INIT_RECEIVED,
                order_status: data?.message?.order?.status,
                on_init_payload: data,
                user_action_required: false,
                order_created_time: data.message.order.created_at,
                order_updated_time: data.message.order.updated_at
            });
            return true
        });
        //Make confirm API call for this order
        if (status) {
            this.confirmAPICall(transactionId)
        }


    }

    async confirmAPICall(orderId: string): Promise<any> {
        const tenantId = await this.findTenantIdByTransactionId(orderId);
        let payload;

        const status = await this.tenantRepo.transaction(tenantId, async (manager) => {
            const txnHelper = new TenantTransactionHelper(manager);

            const order = await txnHelper.findById(OrderEntity, orderId);

            if (!order) {
                throw new Error(`Order not found in tenant DB for txn ${orderId}`);
            }

            payload = order.select_context;
            payload.context.message_id = UUIDv4();
            payload.context.timestamp = new Date().toISOString();
            payload.context.action = 'confirm';

            payload.message.order.id = order.bpp_order_id
            const payment = await txnHelper.findOne(PaymentEntity, { order_id: order.id });

            let paymentPayload = {
                "id": payment?.id,
                "type": payment?.type,
                "status": payment?.status,
                "collected_by": payment?.collected_by,
                "tags": payment?.tags,
                "params": {
                    "amount": payment?.amount,
                    "currency": payment?.currency,
                    "source_bank_code": payment?.source_bank_code,
                    "source_bank_account_number": payment?.source_bank_account_number,
                    "source_bank_account_name": payment?.source_bank_account_name
                }
            }
            // payload.message.order.payments = order?.selected_payment;
            payload.message.order.payments = [paymentPayload];


            const init_ack = await this.makeConfirmRequest(payload);

            if (init_ack.success) {
                await txnHelper.update(OrderEntity, order.id, {
                    status: OrderStatus.CONFIRM_SENT,
                    user_action_required: false,
                    confirm_context: payload
                });
            } else {
                await txnHelper.update(OrderEntity, order.id, {
                    status: OrderStatus.CONFIRM_FAILED,
                    user_action_required: false,
                    init_context: payload
                });
            }
            return true
        });
    }

    async onConfirmRes(data: any): Promise<any> {
        const context = data?.context;
        const transactionId = context?.transaction_id;

        if (!transactionId) {
            throw new Error('Missing transaction_id in ONDC callback');
        }

        const tenantId = await this.findTenantIdByTransactionId(transactionId);

        let status = await this.tenantRepo.transaction(tenantId, async (manager) => {
            const txnHelper = new TenantTransactionHelper(manager);

            const order = await txnHelper.findById(OrderEntity, transactionId);

            const payments = data.message.order.payments;

            if (!order) {
                throw new Error(`Order not found in tenant DB for txn ${transactionId}`);
            }

            if (data?.error) {
                await txnHelper.update(OrderEntity, order.id, {
                    status: OrderStatus.ON_CONFIRM_RECEIVED_ERROR,
                    hasError: true,
                    error_response: data
                });
                return true;
            }

            await txnHelper.update(OrderEntity, order.id, {
                status: OrderStatus.ON_CONFIRM_RECEIVED,
                order_status: data?.message?.order?.status,
                on_confirm_payload: data,
                user_action_required: true
            })

            //update the payment method.
            for (const payment of payments) {
                let ispay = await txnHelper.findById(PaymentEntity, payment.id);

                if (ispay) {

                    await txnHelper.update(PaymentEntity, ispay.id, {
                        status: payment.status,
                        order_status: data?.message?.order?.status
                    })

                } else {
                    const paymentEntity = new PaymentEntity();
                    paymentEntity.id = payment.id;
                    paymentEntity.order_id = order.id;
                    paymentEntity.collected_by = payment.collected_by;
                    paymentEntity.url = payment.url;
                    paymentEntity.amount = parseFloat(payment.params?.amount || '0');
                    paymentEntity.currency = payment.params?.currency || 'INR';
                    paymentEntity.source_bank_code = payment.params?.source_bank_code || '';
                    paymentEntity.source_bank_account_number = payment.params?.source_bank_account_number || '';
                    paymentEntity.source_bank_account_name = payment.params?.source_bank_account_name || '';
                    paymentEntity.type = payment.type;
                    paymentEntity.status = payment.status;
                    paymentEntity.tags = payment.tags || [];
                    paymentEntity.order_status = data?.message?.order?.status;

                    await txnHelper.create(PaymentEntity, paymentEntity);
                }
            }

            return true
        });


    }

    async getOrderStatus(orderId: string): Promise<any> {
        const tenantId = await this.findTenantIdByTransactionId(orderId);
        const order = await this.tenantRepo.findOne(tenantId, OrderEntity, { id: orderId });

        const isActionRequired = order?.user_action_required || false;
        const currentStatus = order?.status;
        const orderStatus = order?.order_status;
        const hasError = order?.hasError || false;

        let responsePayload = {
            currentStatus: currentStatus,
            isActionRequired: isActionRequired,
        }

        if (hasError) {
            responsePayload["hasError"] = hasError
            responsePayload["error"] = order?.error_response
        }

        if (isActionRequired) {
            // return OrderStatus.AOF_PENDING
            responsePayload["nextRequiredForm"] = order?.next_required_form?.form || null
        }

        if (currentStatus == OrderStatus.PAYMENT_OPTIONS_RESIVED) {
            responsePayload["paymentOptions"] = order?.payments_options
        }

        if (currentStatus == OrderStatus.ON_CONFIRM_RECEIVED && orderStatus == BppOrderStatus.ACCEPTED) {
            let payment = await this.tenantRepo.findOne(tenantId, PaymentEntity, { order_id: orderId });
            responsePayload["payment"] = payment
            responsePayload["orderStatus"] = orderStatus
        }

        if (currentStatus == OrderStatus.PAID) {
            responsePayload['message'] = "Order has been paid successfully, nav will be assigned to you in 2 working days."
        }

        return responsePayload
    }

}