import { Controller } from "@nestjs/common";
import { OrderService } from "./order.service";
import { MessagePattern } from "@nestjs/microservices";

@Controller()
export class OrderController {

    constructor(
        private readonly orderService: OrderService
    ){}

    @MessagePattern({ cmd: 'create_lumpsum_order'})
    selectOrder(data:any){
        return this.orderService.createOrder(data.tenantId, data.data);
    }

    @MessagePattern({ cmd: 'get_order_status'})
    getOrderStatus(data:any){
        console.log("🚀 ~ OrderController ~ getOrderStatus ~ data:", data)
        return this.orderService.getOrderStatus(data.orderId);
    }

    @MessagePattern({ cmd: 'handle_aof_submission'})
    handleAofSubmission(data:any){
        return this.orderService.handleAofSubmission(data.orderId);
    }

    @MessagePattern({ cmd: 'select_payment_method'})
    selectPaymentOptions(data:any){
        return this.orderService.selectPaymentOptions(data.orderId, data.paymentMethod);
    }

}