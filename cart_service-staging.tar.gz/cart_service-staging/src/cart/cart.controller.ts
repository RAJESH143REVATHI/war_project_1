import { Controller, Get } from "@nestjs/common";
import { MessagePattern } from "@nestjs/microservices";
import { CartService } from "./cart.service";

@Controller()
export class CartController {

    constructor(
        private readonly cartService: CartService
    ){}

    @MessagePattern('ping_cart')
    responseToPing(){
        return this.cartService.responseToPing();
    }
    
}