import { Injectable, OnModuleInit } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { ClientProxy } from "@nestjs/microservices";
import { RmqService } from "src/shared/rmq.service";

@Injectable()
export class CartService implements OnModuleInit {
    private client: ClientProxy

    constructor(
        private readonly rmqService: RmqService,
        private readonly configService: ConfigService
    ){}

    onModuleInit() {
        let queue = this.configService.get('rabbitmq.queue')
        this.client = this.rmqService.createClient(queue)
    }


    responseToPing(){
        return `
            <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to User Service</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
        }
        .container {
            text-align: center;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Cart/Order Service</h1>
        <p>Your request has been received successfully.</p>
    </div>
</body>
</html>
        `
    }
}