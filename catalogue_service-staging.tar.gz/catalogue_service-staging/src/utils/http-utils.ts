import axios, { AxiosRequestConfig, Method } from 'axios';

/**
 * Make an HTTP request using axios.
 * @param url - The full URL to call.
 * @param method - HTTP method: 'GET', 'POST', etc.
 * @param data - Payload for POST/PUT requests (optional).
 * @param headers - Optional headers.
 */
export async function makeApiCall<T = any>(
  url: string,
  method: Method,
  data?: any,
  headers?: Record<string, string>
): Promise<T> {
  const config: AxiosRequestConfig = {
    url,
    method,
    data,
    headers,
  };

  try {
    const response = await axios(config);
    return response.data as T;
  } catch (error) {
    // Optional: throw structured error for caller to handle
    throw {
      message: error?.response?.data?.message || 'HTTP request failed',
      status: error?.response?.status || 500,
      details: error?.response?.data || error,
    };
  }
}
