import { Controller } from '@nestjs/common';
import { Ctx, MessagePattern, Payload, RmqContext } from '@nestjs/microservices';
import { CatalogService } from './catalog.service';
import { MessagePatternStr } from './catalog-message-pattern';
import { ResponseConstructor } from 'src/res/reponse.cunstructor';

@Controller()
export class CatalogController {

  constructor(
    private readonly catalogService: CatalogService
  ) { }

  @MessagePattern({ cmd: MessagePatternStr.PING_CATALOG })
  async getCatalogPing() {
    console.log("Request came from gateway.===")
    return this.catalogService.resposeToPing();
  }

  @MessagePattern({ cmd: MessagePatternStr.GET_CATALOG })
  async getCatalog(data: any) {
    var catlogList = await this.catalogService.getFunds(data);
    return new ResponseConstructor(catlogList, 'success').compose();
  }

  @MessagePattern({ cmd: MessagePatternStr.GET_CATOGERY })
  async getAllCategory(data: any) {
    console.log("🚀 ~kkkk CatalogController ~ getAllCategory ~ data:", data)
    var categoriesList = await this.catalogService.getAllCategory(data);
    return new ResponseConstructor(categoriesList, 'success').compose();
  }

  @MessagePattern({ cmd: MessagePatternStr.GET_ONDCFUNDDATA })
  async getOndcMutualFund(query: any) {
    return this.catalogService.getOndcMutualFund(query);
  }

  @MessagePattern({ cmd: MessagePatternStr.GET_TOPCOLLECTION })
  async getTopCollections() {
    var collectionList = await this.catalogService.getTopCollections();
    return new ResponseConstructor(collectionList, 'success').compose();
  }

  @MessagePattern({ cmd: MessagePatternStr.GET_AMCLIST })
  async getAmcList() {
    var amcList = await this.catalogService.getAmcList();
    return new ResponseConstructor(amcList, 'success').compose();
  }

  @MessagePattern({ cmd: MessagePatternStr.GET_HOLDINGDATA })
  async getHoldingData(query: any) {
    var fundHoldingData = await this.catalogService.getHoldingData(query);
    return new ResponseConstructor(fundHoldingData, 'success').compose();
  }
}
