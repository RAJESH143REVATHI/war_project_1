import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { RmqService } from '../shared/rmq.service';
import { ClientProxy } from '@nestjs/microservices';
import { Amc, AmcDocument } from 'src/mongoose/schemas/amc-collection.schema';
import { Fund, FundDocument } from 'src/mongoose/schemas/fund.schema';
import { InjectModel } from '@nestjs/mongoose';
import { isValidObjectId, Model } from 'mongoose';
import { OndcFundPlan, OndcFundPlanDocument } from 'src/mongoose/schemas/ondc-fund-plan.schema';
import { MorningStarFund, MorningStarFundDocument } from 'src/mongoose/schemas/msFunds.schema';
import { Category, CategoryCollectionDocument } from 'src/mongoose/schemas/catogery.schema';
import { SubCategory, SubCategoryDocument } from 'src/mongoose/schemas/sub-catogery.schema';

import { Types } from 'mongoose';
import { CategoryRepository } from 'src/mongoose/repositories/category.repository';
import { SubCategoryRepository } from 'src/mongoose/repositories/subCategory.repository';
import { AmcRepository } from 'src/mongoose/repositories/amc.repository';
import { TopCollection, TopCollectionDocument } from 'src/mongoose/schemas/top-collection.schema';
import { FundHolding, FundHoldingDocument } from 'src/mongoose/schemas/fund-holdings.schema';

@Injectable()
export class CatalogService {
  private client: ClientProxy;

  constructor(
    private readonly rmqService: RmqService,
    private readonly configService: ConfigService,
    @InjectModel(Fund.name) private fundModel: Model<FundDocument>,
    @InjectModel(Amc.name) private amcCollectionDocument: Model<AmcDocument>,
    private readonly amcRepository: AmcRepository,
    @InjectModel(OndcFundPlan.name) private readonly ondcFundPlanModel: Model<OndcFundPlanDocument>,
    @InjectModel(FundHolding.name) private fundHoldingModel: Model<FundHoldingDocument>,
    @InjectModel(TopCollection.name) private readonly topCollectionModel: Model<TopCollectionDocument>,
    @InjectModel(MorningStarFund.name) private readonly mfModel: Model<MorningStarFundDocument>,
    @InjectModel(Amc.name) private readonly amcModel: Model<AmcDocument>,
    // @InjectModel(Category.name) private readonly categoryModel: Model<CategoryCollectionDocument>,
    // @InjectModel(SubCategory.name) private readonly subCategoryModel: Model<SubCategoryDocument>,
    private readonly catogeryReposetry: CategoryRepository,
    private readonly subCategoryRepository: SubCategoryRepository,
    // private readonly morningStartCatService : MorningstarCatlogService

  ) {
    const queue = this.configService.get('rabbitmq.queue');
    this.client = this.rmqService.createClient(queue);
  }

  async getCollection() {
    return {
      // amcCollectionModel: await this.amcCollectionModel.find(query).exec(),
      // fundModel: await this.amcCollectionDocument.find().exec(),
      fundModel: await this.amcRepository.findAll(),
    };
  }

  async getOndcMutualFund(query: any) {

    let data = await this.ondcFundPlanModel.find(query).exec()
    
    return data && data.length > 0 && data[0]
  }

  async getTopCollections() {
    return await this.topCollectionModel.find().exec();
  }

  async getAmcList() {
    return await this.amcModel.find().exec()
  }

  async getHoldingData(query: any) {
    return await this.fundHoldingModel.find(query).exec()
  }


  async resposeToPing() {
    return `
      <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to User Service</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
        }
        .container {
            text-align: center;
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        h1 {
            color: #333;
        }
        p {
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome to Catlog Service</h1>
        <p>Your request has been received successfully.</p>
    </div>
</body>
</html>
    `;
  }

  normalizeToArray(value: string | string[]): string[] {
    if (!value) return [];
    return Array.isArray(value) ? value : value.split(',');
  };

  async getFunds(query: any) {
    const {
      category,
      subCategory,
      amc,
      risk,
      isin,
      search,
      sortBy = 'nav.value',
      order = 'desc',
      page = 1,
      limit = 10,
      popularFund,
      highReturn,
      sipAt
    } = query;

    let filter: any = {};

    const categoryIds = this.normalizeToArray(category)
      .filter(Types.ObjectId.isValid)
      .map(id => new Types.ObjectId(id));

    const subCategoryIds = this.normalizeToArray(subCategory)
      .filter(Types.ObjectId.isValid)
      .map(id => new Types.ObjectId(id));

    const amcIds = this.normalizeToArray(amc)
      .filter(Types.ObjectId.isValid)
      .map(id => new Types.ObjectId(id));


    if (categoryIds.length) {
      filter.category_id = { $in: categoryIds };
    }

    if (subCategoryIds.length) {
      filter.subCategory_id = { $in: subCategoryIds };
    }

    console.log('kailas subcat', filter.subCategory_id);

    if (amcIds.length) {
      filter.amc_id = { $in: amcIds };
    }

    // if (category && Types.ObjectId.isValid(category)) {
    //   filter.category_id = new Types.ObjectId(category);
    // }
    // if (subCategory && Types.ObjectId.isValid(subCategory)) {
    //   filter.subCategory_id = new Types.ObjectId(subCategory);
    // }
    // if (amc && Types.ObjectId.isValid(amc)) {
    //   filter.amc_id = new Types.ObjectId(amc);
    // }


    // if (category) filter.category_id = isValidObjectId(category) ? category : category;
    // if (subCategory) filter.subCategory_id = subCategory;
    // if (amc) filter.amc_id = amc;
    if (risk) filter["risk.level"] = risk;

    if (search) {
      filter.$text = { $search: search };
    }


    const sort: any = {};
    sort[sortBy] = order === 'asc' ? 1 : -1;


    console.log('kkk val page ', page)

    if(isin){
      filter = {
        isin: isin
      }
    }

    console.log(filter, "🚀 ~ CatalogService ~ getFunds ~ search:")
    console.log('highhhh', highReturn)

    if (sipAt) {
      const filter = {
        minSipAt: (sipAt === 100)
          ? 100
          : { $lte: sipAt }
      };
      console.log("kailas check in else", filter)
      const skip = (page - 1) * limit;
      const [results, total] = await Promise.all([
        this.mfModel.find(filter).sort(sort).skip(skip).limit(Number(limit)).exec(),
        this.mfModel.countDocuments(filter),
      ]);
      return {
        funds: results,
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit),
      };
    } else if (popularFund) {
      console.log("kailas check in popular", popularFund)
      //limit = 10;
      console.log('kkk val in popular limit ', limit)
      const skip = (page - 1) * limit;
      const matchStage = {
        ...filter,
        "risk.level": "Low Risk",
        "returns.threeYear": { $ne: null }
      };

      const [results, total] = await Promise.all([
        this.mfModel.aggregate([
          { $match: matchStage },
          {
            $addFields: {
              threeYearReturnNumeric: {
                $toDouble: "$returns.threeYear"
              }
            }
          },
          { $sort: { threeYearReturnNumeric: -1 } },
          { $skip: skip },
          { $limit: Number(10) }
        ]).exec(),

        this.mfModel.countDocuments(matchStage)
      ]);
      return {
        funds: results,
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit),
      };
    } else if (highReturn) {
      console.log("kailas check in highreturn", highReturn)
      const skip = (page - 1) * limit;

      const convertReturnFields = [
        {
          $addFields: {
            threeYearReturn: { $toDouble: "$returns.threeYear" },
            fiveYearReturn: { $toDouble: "$returns.fiveYear" },
            sevenYearReturn: { $toDouble: "$returns.sevenYear" }
          }
        }
      ];

      // Query 1: Funds with threeYearReturn
      const threeYearFunds = await this.mfModel.aggregate([
        { $match: { ...filter, "returns.threeYear": { $ne: null } } },
        ...convertReturnFields,
        { $sort: { threeYearReturn: -1 } }
      ]);

      // Query 2: Funds with fiveYearReturn but NOT in threeYearFunds
      const fiveYearFunds = await this.mfModel.aggregate([
        {
          $match: {
            ...filter,
            "returns.threeYear": null,
            "returns.fiveYear": { $ne: null }
          }
        },
        ...convertReturnFields,
        { $sort: { fiveYearReturn: -1 } }
      ]);

      // Query 3: Funds with sevenYearReturn but NOT in threeYear or fiveYear
      const sevenYearFunds = await this.mfModel.aggregate([
        {
          $match: {
            ...filter,
            "returns.threeYear": null,
            "returns.fiveYear": null,
            "returns.sevenYear": { $ne: null }
          }
        },
        ...convertReturnFields,
        { $sort: { sevenYearReturn: -1 } }
      ]);

      // Combine all
      const combined = [...threeYearFunds, ...fiveYearFunds, ...sevenYearFunds];

      // Paginate in JS
      const paginated = combined.slice(skip, skip + limit);

      return {
        funds: paginated,
        total: combined.length,
        page,
        limit,
        totalPages: Math.ceil(combined.length / limit),
      };

    } else {
      console.log("kailas check in else", filter)
      const skip = (page - 1) * limit;
      const [results, total] = await Promise.all([
        this.mfModel.find(filter).sort(sort).skip(skip).limit(Number(limit)).exec(),
        this.mfModel.countDocuments(filter),
      ]);
      return {
        funds: results,
        total,
        page: Number(page),
        limit: Number(limit),
        totalPages: Math.ceil(total / limit),
      };
    }
  }

  async getAllCategory(query: any) {
    // const categories = await this.categoryModel.find(query).exec();
    const categories = await this.catogeryReposetry.findAll();
    console.log("🚀 ~ CatalogService ~ getAllCategory ~ categories:", categories)
    // const subCategories = await this.subCategoryModel.find(query).exec();
    const subCategories = await this.subCategoryRepository.findAll();
    console.log("🚀 ~ CatalogService ~ getAllCategory ~ subCategories:", subCategories)

    const categoryMap = categories.map((category: any) => {
      // Filter subcategories that belong to this category
      const filteredSubcategories = subCategories.filter(
        (subCat) => subCat.Category_id.toString() === category._id.toString(),
      );

      return {
        Category_id: category._id,
        CategoryName: category.CategoryName,
        sub_category: filteredSubcategories,
      };
    });

    return categoryMap;
  }

}
