import { Module } from '@nestjs/common';
import { CatalogService } from './catalog.service';
import { CatalogController } from './catalog.controller';
import { ConfigModule } from '@nestjs/config';
import rabbitmqConfig from '../config/rabbitmq.config';
import { RmqService } from '../shared/rmq.service';
// import { MongooseModule } from '@nestjs/mongoose';
// import { Amc, AmcSchema } from 'src/mongoose/schemas/amc-collection.schema';
// import { Fund, FundSchema } from 'src/mongoose/schemas/fund.schema';
// import { OndcFundPlan, OndcFundPlanSchema } from 'src/mongoose/schemas/ondc-fund-plan.schema';
// import { MorningStarFund, MorningStarFundSchema } from 'src/mongoose/schemas/msFunds.schema';
// import { Category, CategoryCollectionSchema } from 'src/mongoose/schemas/catogery.schema';
// import { SubCategory, SubCategorySchema } from 'src/mongoose/schemas/sub-catogery.schema';
import { SharedMongooseModule } from 'src/mongoose/mongoose.module';

@Module({
  imports: [
    // MongooseModule.forFeature([
    //   { name: Fund.name, schema: FundSchema },
    //   { name: Amc.name, schema: AmcSchema },
    //   { name: OndcFundPlan.name, schema: OndcFundPlanSchema },
    //   {name: MorningStarFund.name, schema: MorningStarFundSchema},
    //   {name: Category.name, schema: CategoryCollectionSchema},
    //   {name: SubCategory.name, schema: SubCategorySchema}
    // ]),
    SharedMongooseModule,
    ConfigModule.forRoot({ isGlobal: true, load: [rabbitmqConfig] })
  ],
  controllers: [CatalogController],
  providers: [CatalogService, RmqService],
})
export class CatalogModule {}
