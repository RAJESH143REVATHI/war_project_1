import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { Type } from 'class-transformer';

// Nested Schema for DB Credentials
@Schema({ _id: false })
export class DbCredentials {
  @Prop({ required: true })
  host: string;

  @Prop({ required: true })
  port: string;

  @Prop({ required: true })
  username: string;

  @Prop({ required: true })
  password: string;

  @Prop({ required: true })
  dbName: string;
}

// Nested Schema for Integrations
@Schema({ _id: false })
export class Integrations {
  @Prop()
  paymentGateway: string;

  @Prop()
  notificationService: string;
}

export type TenantConfigDocument = TenantConfig & Document;

@Schema({ timestamps: true })
export class TenantConfig {
  @Prop({ required: true, unique: true })
  tenant_id: string;

  @Prop({ required: true })
  name: string;

  @Prop({ type: Object, default: {} })
  layout: Record<string, any>;

  @Prop({ type: DbCredentials, required: true })
  @Type(() => DbCredentials)
  dbCredentials: DbCredentials;

  @Prop({ type: Object, default: {} })
  featureFlags: Record<string, boolean>;

  @Prop({ type: Integrations, default: {} })
  @Type(() => Integrations)
  integrations: Integrations;
}

export const TenantConfigSchema = SchemaFactory.createForClass(TenantConfig);
