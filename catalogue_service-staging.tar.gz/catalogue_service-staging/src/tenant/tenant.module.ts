import { Module } from "@nestjs/common";
import { TenantService } from "./tenant.service";
import { TenantConfig, TenantConfigSchema } from "src/tenant/tenantConfig.schema";
import { MongooseModule } from "@nestjs/mongoose";
// import { AppConfig } from "src/schemas/app-config.schema";

@Module({
    imports: [
        MongooseModule.forFeature([
            { name: TenantConfig.name, schema: TenantConfigSchema }
        ])
    ],
    controllers: [],
    providers: [TenantService,TenantConfig],
    exports: [TenantService]
})
export class TenantModule {

}