import { forwardRef, Module } from "@nestjs/common";
import { ScheduleModule } from "@nestjs/schedule";
import { CatlogProcesserModule } from "src/catalog-processer/catlog-processer.module";
import { MorningstarCatlogService } from "./morningstar.catlog.service";
import { MorningstarScheduler } from "./morningstar.scheduler";
import { ConsumerModule } from "src/consumer/consumer.module";
import { CatogeryController } from "./catogery.controller";

import { MongooseModule } from "@nestjs/mongoose";
import { Category, CategoryCollectionSchema } from "src/mongoose/schemas/catogery.schema";
import { CatogeryService } from "./catogery.service";
import { SubCategory, SubCategorySchema } from "src/mongoose/schemas/sub-catogery.schema";
import { Amc, AmcSchema } from "src/mongoose/schemas/amc-collection.schema";
import { MorningStarFund, MorningStarFundSchema } from "src/mongoose/schemas/msFunds.schema";
import { SharedMongooseModule } from "src/mongoose/mongoose.module";


@Module({
    imports: [
        // MongooseModule.forFeature([
        //     { name: `${Category.name}`, schema: CategoryCollectionSchema  },
        //     { name: `${SubCategory.name}`, schema: SubCategorySchema },
        //     {name: Amc.name, schema: AmcSchema},
        //     {name: MorningStarFund.name, schema: MorningStarFundSchema}
        // ]),
        SharedMongooseModule,
        ScheduleModule.forRoot(),
        CatlogProcesserModule,
        forwardRef(() => ConsumerModule)
    ],
    controllers: [CatogeryController],
    providers: [
        CatogeryService,
        MorningstarCatlogService,
        
        MorningstarScheduler
    ],
    exports: [MorningstarCatlogService,CatogeryService]
})
export class MorningstarCatlogModule {}