import { Injectable, Logger } from "@nestjs/common";
import { CatlogProcesserService } from "src/catalog-processer/catlog-processer.service";
import { MqService } from "src/consumer/mq.service";
import { RmqService } from "src/shared/rmq.service";
import { MorningstarSingleIsinQueuePayload } from "./interfase/morningstar.interfase";
import axios, { AxiosRequestConfig } from "axios";
import { makeApiCall } from "src/utils/http-utils";
import { CatogeryService } from "./catogery.service";
import { InjectModel } from "@nestjs/mongoose";
import { Amc, AmcDocument } from "src/mongoose/schemas/amc-collection.schema";
import { get, Model } from "mongoose";
import { MorningStarFund, MorningStarFundDocument } from "src/mongoose/schemas/msFunds.schema";
import { ConfigService } from "@nestjs/config";
import { FundHolding, FundHoldingDocument } from "src/mongoose/schemas/fund-holdings.schema";
import { OndcFundPlan, OndcFundPlanDocument } from "src/mongoose/schemas/ondc-fund-plan.schema";

@Injectable()
export class MorningstarCatlogService {

  constructor(
    private readonly catalogProcessService: CatlogProcesserService,
    private readonly catogeryService: CatogeryService,
    private readonly mqService: MqService,
    @InjectModel(Amc.name) private amcModel: Model<AmcDocument>,
    @InjectModel(MorningStarFund.name) private msFundModel: Model<MorningStarFundDocument>,
    @InjectModel(FundHolding.name) private fundHoldingModel: Model<FundHoldingDocument>,
    @InjectModel(OndcFundPlan.name)
    private readonly ondcFundPlanModel: Model<OndcFundPlanDocument>,
    private readonly configService: ConfigService
  ) { }


  async syncData() {

    // Fetch avilable ISIN from ONDC Data Catalog.
    let allIsin = await this.catalogProcessService.fetchAllIsin();

    let allData: MorningstarSingleIsinQueuePayload[] = allIsin.map((isin) => {

      //Construct Morning Star API URL Based ON ISIN.
      let API_URL = `https://api.morningstar.com/v2/service/mf/y763j26xgld7fzlx/isin/${isin}?accesscode=${this.configService.get('MORNINGSTAR_ACCESS_CODE')}&format=json`;
      // let API_URL = `https://api.morningstar.com/v2/service/mf/AssetManagementCompanyBasicInformation/isin/${isin}?accesscode=b2vcwc3n1sesfk3gceb6pnojeh29mai3&format=json`;

      let payload: MorningstarSingleIsinQueuePayload = {
        ISIN: isin,
        API_URL
      }

      return payload
    });

    await this.mqService.publishMessagesInBulk('morning_star_sync', allData);

  }



  async processSingleIsin(data: MorningstarSingleIsinQueuePayload) {
    try {
      const morningstarData = await makeApiCall(data.API_URL, 'GET');
      //   console.log("🚀 ~ MorningstarCatlogService ~ processSingleIsin ~ morningstarData:", morningstarData)

      if (
        !morningstarData ||
        !morningstarData.data ||
        !Array.isArray(morningstarData.data) ||
        morningstarData.data.length === 0
      ) {
        throw new Error("Data Not Found");
      }

      const raw = morningstarData.data[0];
      const fund = raw.api;

      // Do catogery and sub-catogery mapping

      let catogery = await this.catogeryService.getSubCatogeryBymorningstarCatId(fund["AT-FundLevelCategoryCode"]);
      let subCategory_id = catogery._id;
      let category_id = catogery.Category_id;
      // console.log(category_id,"🚀 ~ MorningstarCatlogService ~ processSingleIsin ~ catogery:", subCategory_id);
      // check AMC avilabe or not (if not create one) and map it amc_id with isin

      let amc = {
        companyId: fund["FSCBI-ProviderCompanyID"] || null,
        name: fund["FSCBI-ProviderCompanyName"] || null,
        website: fund["FSCBI-ProviderCompanyWebsite"] || null,
      };

      let amcData = await this.amcModel.find({ companyId: amc.companyId });


      let amc_id;
      if (amcData.length > 0) {
        // console.log("AMC Already exist ======>",amcData[0]);
        amc_id = amcData[0]._id;
      } else {
        let amcCollection = await this.amcModel.create(amc);
        amc_id = amcCollection._id;
        // console.log("AMC Created ======>",amcCollection);
      }

      // console.log(amc_id,"🚀 ~ MorningstarCatlogService ~ processSingleIsin ~ amcData:", amcData);

      // provider: {
      //   companyId: fund["FSCBI-ProviderCompanyID"] || null,
      //   name: fund["FSCBI-ProviderCompanyName"] || null,
      //   website: fund["FSCBI-ProviderCompanyWebsite"] || null,
      // },



      // map purchaseMode with ENUM.

      // return true


      const parsedData = {
        isin: raw._id || fund["FSCBI-ISIN"] || null,
        name: fund["FSCBI-FundName"] || null,
        legalName: fund["FSCBI-LegalName"] || null,
        mstarId: raw._MstarId || null,
        category_id,
        subCategory_id,
        amc_id,
        purchaseMode: fund["FSCBI-PurchaseMode"] || null,
        advisoryCompany: fund["FSCBI-AdvisoryCompanyName"] || null,
        globalCategory: fund["FSCBI-GlobalCategoryName"] || null,
        category: fund["FSCBI-CategoryName"] || null,
        fundLevelCategory: {
          name: fund["AT-FundLevelCategoryName"] || null,
          code: fund["AT-FundLevelCategoryCode"] || null,
        },
        managers: fund["FM-Managers"]?.map((m: any) => ({
          id: m.ManagerId || null,
          name: m.Name || null,
          role: m.Role || null,
          startDate: m.StartDate || null,
          tenure: m.Tenure || null,
        })) ?? [],
        risk: {
          level: fund["AT-india_fund_risk_level"] || null,
          prcMatrix: fund["AT-potential_risk_class_matrix"] || null,
        },
        sipAvailable: fund["PI-SIPAvailability"] === "true",
        indexFund: fund["AT-IndexFund"] === true,
        masterFeeder: fund["AT-MasterFeeder"] === true,
        distributionFrequency: fund["FSCBI-DistributionFrequency"] || null, // need to check
        load: {
          deferredDetails: fund["PF-deferred_load_additional_details"] || null,
          maxDeferLoad: fund["LS-MaximumDeferLoad"] || null,
        },
        managementFee: fund["LS-MaximumManagementFee"] || null,
        expenseRatio: {
          current: fund["ARF-InterimNetExpenseRatio"] || null,
          currentDate: fund["ARF-InterimNetExpenseRatioDate"] || null,
          semiAnnual: fund["ARF-NetExpenseRatio"] || null,
          semiAnnualDate: fund["ARF-semi_annual_report_net_expense_ratio_date"] || null,
        },
        minimumRedemption: {
          amount: fund["LS-MinimumRedemptionAmount"] || null, // need to check
          unit: fund["LS-MinimumRedemptionUnit"] || null, // need to check
        },
        swpAvailable: fund["PI-systematic_withdrawal_plan_indicator"] === "true",
        nav: {
          value: fund["TS-DayEndNAV"] || null,
          date: fund["TS-DayEndNAVDate"] || null,
          change: fund["DP-NAVChange"] || null,
          changePercent: fund["DP-NAVChangePercentage"] || null,
        },
        returns: {
          oneDay: fund["DP-Return1Day"] || null,
          oneWeek: fund["DP-Return1Week"] || null,
          threeMonth: fund["TTR-Return3Mth"] || null,
          twoYear: fund["TTR-Return2Yr"] || null,
          threeYear: fund["TTR-CumulativeReturn3Yr"] || null,
          fourYear: fund["TTR-Return4Yr"] || null,
          fiveYear: fund["TTR-CumulativeReturn5Yr"] || null,
          sevenYear: fund["TTR-Return7Yr"] || null,
          tenYear: fund["TTR-CumulativeReturn10Yr"] || null,
          sinceInception: fund["TTR-ReturnSinceInception"] || null,
        },
        categoryReturns: {
          oneDay: fund["DP-CategoryReturn1Day"] || null,
          oneWeek: fund["DP-CategoryReturn1Week"] || null,
          threeYear: fund["TTR-CategoryCumulativeReturn3Yr"] || null,
          fiveYear: fund["TTR-CategoryCumulativeReturn5Yr"] || null,
          tenYear: fund["TTR-CategoryCumulativeReturn10Yr"] || null,
        },
        peerReturns: {
          threeYear: fund["QETP-CumulativeReturn3Yr"] || null,
          fiveYear: fund["QETP-CumulativeReturn5Yr"] || null,
          tenYear: fund["QETP-CumulativeReturn10Yr"] || null,
        },
        portfolio: {
          date: fund["AABRP-PortfolioDate"] || null,
          holdings: Number(fund["PSRP-NumberofHolding"]) || null,
          assetAllocation: {
            bond: fund["AABRP-AssetAllocBondNet"] || null,
            cash: fund["AABRP-AssetAllocCashNet"] || null,
            equity: fund["AABRP-AssetAllocEquityNet"] || null,
            other: fund["AABRP-OtherNet"] || null,
          },
          aum: fund["FNA-AsOfOriginalReported"] || null,
        },
        rating: {
          overall: fund["MR-RatingOverall"] || null,
          risk: fund["MR-RiskOverall"] || null,
          return: fund["MR-ReturnOverall"] || null,
          numberOfFunds: fund["MR-NumberOfFundsOverall"] || null,
        },
        ms_fullfilments: fund["IAIP-AIP"]?.filter(f => f.SIType === "SIP").map((f: any) => ({
          frequency: f.Frequency || null,
          frequencyDate: f.FrequencyDate || null,
          minTenure: f.MinTenure || null,
          siType: f.SIType || null,
          minAmount: f.MinAmount || null,
        })),
        minSipAt: Math.min(
          ...fund["IAIP-AIP"]
            .filter(f => f.SIType === "SIP")
            .map(f => {
              //console.log("$$$$$$$$$", f.MinAmount)
              return Number(f.MinAmount)
            })
        )
      };


      let fundData = await this.msFundModel.find({ isin: parsedData.isin }).exec();

      // if (fundDate.length > 0) {
      //   await this.msFundModel.updateOne({ isin: parsedData.isin }, parsedData);
      //   console.log("Updated Morningstar Data:=========>", JSON.stringify(parsedData, null, 2));
      // } else {
      //   let createdFund = await this.msFundModel.create(parsedData);
      //   console.log("Created Morningstar Data:=========>", JSON.stringify(createdFund, null, 2));
      // }

      if (parsedData.isin == 'INF109K1A013') {
        console.log('kkkkk isin ', parsedData.isin)
      }

      if (fundData.length > 0) {
        // Step 2: Fetch the new field data from another collection
        const ondcFundData = await this.ondcFundPlanModel.findOne({ isin: parsedData.isin }).exec();

        if (parsedData.isin == 'INF109K1A013') {
          console.log('kkkkk isin ', ondcFundData)
        }


        // Optional: Fallback if no data found
        if (!ondcFundData) {
          console.warn("No new field data found for ISIN:", parsedData.isin);
        }

        const updatePayload: any = { ...parsedData };

        // Step 3: Only add new field if not already present in fundData
        // if (!fundData[0].ondcFundData && ondcFundData) {
        //   updatePayload.ondcFundData = ondcFundData;
        // }
        if (ondcFundData) {
          updatePayload.ondcFundData = ondcFundData;
        }

        // Step 4: Update the document
        await this.msFundModel.updateOne(
          { isin: parsedData.isin },
          { $set: updatePayload }
        );

        //console.log("Updated Morningstar Data with other collection field:", JSON.stringify(updatePayload, null, 2));

      } else {
        // Step 5: If document doesn't exist, create it with field from other collection
        const ondcFundData = await this.ondcFundPlanModel.findOne({ isin: parsedData.isin }).exec();

        console.log(ondcFundData);

        const createPayload: any = {
          ...parsedData,
          ...(ondcFundData && { ondcFundData: ondcFundData }),
        };

        const createdFund = await this.msFundModel.create(createPayload);

        //console.log("Created Morningstar Data with other collection field:", JSON.stringify(createdFund, null, 2));
      }







    } catch (error) {
      // Logger.error("❌ MorningstarCatalogService ~ processSingleIsin ~ error:", error.message || error);
      //throw error
    }
  }


  async syncHoldingData() {


    //let API_URL = `https://api.morningstar.com/v2/service/mf/pf94suciixt84nc8/isin/INF109K01753?accesscode=${this.configService.get('MORNINGSTAR_ACCESS_CODE')}&format=json`;
    //  let API_URL = `https://api.morningstar.com/v2/service/mf/pf94suciixt84nc8/isin/INF109K01753?accesscode=b2vcwc3n1sesfk3gceb6pnojeh29mai3&format=json`;

    // let payload:MorningstarSingleIsinQueuePayload = {
    //     ISIN : 'INF109K01753',
    //     API_URL
    // }

    // this.processSingleIsinHolding(payload);

    // Fetch avilable ISIN from ONDC Data Catalog.
    console.log('in sync holding kkk')
    let allIsin = await this.catalogProcessService.fetchAllIsin();

    let allData: MorningstarSingleIsinQueuePayload[] = allIsin.map((isin) => {

      //Construct Morning Star API URL Based ON ISIN.
      let API_URL = `https://api.morningstar.com/v2/service/mf/pf94suciixt84nc8/isin/${isin}?accesscode=b2vcwc3n1sesfk3gceb6pnojeh29mai3&format=json`;
      // let API_URL = `https://api.morningstar.com/v2/service/mf/pf94suciixt84nc8/isin/INF109K01753?accesscode=b2vcwc3n1sesfk3gceb6pnojeh29mai3&format=json`;

      let payload: MorningstarSingleIsinQueuePayload = {
        ISIN: isin,
        API_URL
      }

      return payload
    });

    await this.mqService.publishMessagesInBulk('morning_star_holding_sync', allData);

  }

  async processSingleIsinHolding(data: MorningstarSingleIsinQueuePayload) {
    try {
      const morningstarData = await makeApiCall(data.API_URL, 'GET');
      console.log("HoldingData ~ MorningstarCatlogService ~ processSingleIsin ~ morningstarData:", morningstarData)

      if (
        !morningstarData ||
        !morningstarData.data ||
        !Array.isArray(morningstarData.data) ||
        morningstarData.data.length === 0
      ) {
        throw new Error("Data Not Found");
      }

      //const raw = morningstarData.data[0];
      const transformed = morningstarData.data.map(item => ({
        isin: item._id,
        holdingDetail: item.api["FHV2-HoldingDetail"]
      }));

      console.log('holding kkk', JSON.stringify(transformed, null, 2));


      let fundDate = await this.fundHoldingModel.find({ isin: transformed.isin }).exec();

      if (fundDate.length > 0) {
        await this.fundHoldingModel.updateOne({ isin: transformed.isin }, transformed);
        console.log("Updated fund holding Data:=========>", JSON.stringify(transformed, null, 2));
      } else {
        let createdFund = await this.fundHoldingModel.create(transformed);
        console.log("Created fund holding Data:=========>", JSON.stringify(createdFund, null, 2));
      }

    } catch (error) {
      // Logger.error("❌ MorningstarCatalogService ~ processSingleIsin ~ error:", error.message || error);
      //throw error
    }
  }


}