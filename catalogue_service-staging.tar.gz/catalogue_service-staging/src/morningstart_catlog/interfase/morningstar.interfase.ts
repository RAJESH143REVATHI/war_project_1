export interface MorningstarSingleIsinQueuePayload {
    ISIN: string;
    API_URL: string;
}