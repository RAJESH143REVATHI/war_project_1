// scheduler/morningstar.scheduler.ts
import { Injectable, Logger } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
// import { MorningstarService } from '../services/morningstar.service';
import { MorningstarCatlogService } from './morningstar.catlog.service';

@Injectable()
export class MorningstarScheduler {
  private readonly logger = new Logger(MorningstarScheduler.name);

  constructor(private readonly morningstarService: MorningstarCatlogService) { }

  // @Cron('0 1 * * *', { timeZone: 'Asia/Kolkata' }) // 1 AM IST daily
  @Cron(CronExpression.EVERY_DAY_AT_1AM, { timeZone: 'Asia/Kolkata' })
  async handleDailySync() {
    this.logger.log('Started Morningstar daily data sync');
    try {
      await this.morningstarService.syncData();
      this.logger.log('Morningstar sync completed successfully');
    } catch (error) {
      this.logger.error('Error during Morningstar sync', error.stack);
    }
  }


  @Cron(CronExpression.EVERY_DAY_AT_1AM, { timeZone: 'Asia/Kolkata' })
  async handleDailyFundSync() {
    this.logger.log('Started Morningstar daily data sync');
    try {
      await this.morningstarService.syncHoldingData();
      this.logger.log('Morningstar sync completed successfully');
    } catch (error) {
      this.logger.error('Error during Morningstar sync', error.stack);
    }
  }
}
