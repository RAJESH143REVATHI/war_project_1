let data ={
  "status": {
    "code": 0,
    "message": "OK"
  },
  "data": [
    {
      "_idtype": "isin",
      "_id": "INF209K01785", // Done --> isin
      "_MstarId": "F0GBR06S9S", // Done --> mstarId
      "_CurrencyId": "CU$$$$$INR",
      "api": {
        "_id": "y763j26xgld7fzlx",
        "FSCBI-MStarID": "F0GBR06S9S",
        "FSCBI-ISIN": "INF209K01785",
        "FSCBI-FundId": "FSGBR071HB",
        "FSCBI-ProviderCompanyID": "0C0000349B", // Done --> provider.companyId
        "FSCBI-ProviderCompanyName": "Aditya Birla Sun Life AMC Ltd", // Done --> provider.name
        "FSCBI-FundName": "Aditya BSL Corporate Bond Reg Gr", //Done  --> name
        "FSCBI-LegalName": "Aditya Birla Sun Life Corporate Bond Fund Regular Plan Growth", //Done  --> legalName
        "FSCBI-PurchaseMode": "1", // Done --> purchaseMode
        "AT-AvailableInsuranceProduct": false,
        "AT-FundLevelCategoryName": "Corporate Bond", // Done --> fundLevelCategory.name
        "AT-FundLevelCategoryCode": "INCA000064", // Done --> fundLevelCategory.code
        "FSCBI-AdvisoryCompanyName": "Aditya Birla Sun Life AMC Ltd", // Done --> advisoryCompany
        "FSCBI-GlobalCategoryName": "India Fixed Income", // Done --> globalCategory
        "DP-CategoryName": "Corporate Bond",
        "FSCBI-CategoryName": "Corporate Bond", // Done --> category
        "FM-Managers": [
          {
            "Display": "Display as Lead",
            "ManagerId": "145855", // Done --> manager.id
            "Name": "Kaustubh Gupta", // Done --> manager.name
            "Role": "Manager", // Done --> manager.role
            "StartDate": "2021-04-12", // Done --> manager.startDate
            "Tenure": "4.05" // Done --> manager.tenure
          }
        ],
        "AT-india_fund_risk_level": "Low to Moderate Risk", //Done --> risk.level
        "AT-potential_risk_class_matrix": "B-III - Relatively High Interest Rate Risk and Moderate Credit Risk", // Done --> risk.prcMatrix
        "PI-SIPAvailability": "true", // Done --> sipAvailable
        "FSCBI-ProviderCompanyWebsite": "www.adityabirlasunlifemf.com", // Done --> provider.website
        "AT-IndexFund": false, // Done --> indexFund
        "AT-MasterFeeder": false, // Done --> masterFeeder
        "PF-deferred_load_additional_details": "Nil", // Done --> load.deferredDetails
        "LS-MaximumDeferLoad": "0.00000", // Done --> load.maxDeferLoad
        "LS-MaximumManagementFee": "1.25000", // Done --> load.maxManagementFee
        "PF-ActualManagementFee": "0.39000",
        "ARF-InterimNetExpenseRatio": "0.51000", // Done --> expenseRatio.current
        "ARF-InterimNetExpenseRatioDate": "2025-03-31", // Done --> expenseRatio.currentDate
        "ARF-NetExpenseRatio": "0.50000", // Done --> expenseRatio.semiAnnual
        "PF-NetExpenseRatio": "2.25000",
        "ARF-semi_annual_report_net_expense_ratio_date": "2024-09-30", // Done --> expenseRatio.semiAnnualDate
        "PI-systematic_withdrawal_plan_indicator": "true", // Done --> swpAvailable
        "TS-DayEndNAV": "112.17340", // Done --> nav.value
        "DP-DayEndNAV": "112.17340",
        "TS-DayEndNAVDate": "2025-05-08", // Done --> nav.date
        "DP-NAVChange": "-0.24260", // Done --> nav.change
        "DP-NAVChangePercentage": "-0.21581", // Done --> nav.changePercent
        "TTR-CumulativeReturn3Yr": "24.66425", // Done --> returns.threeYear
        "DP-CumulativeReturn3Yr": "25.86031", 
        "TTR-CategoryCumulativeReturn3Yr": "22.67398", // Done --> categoryReturns.threeYear
        "QETP-CumulativeReturn3Yr": "22.65827", // Done --> peerReturns.threeYear
        "TTR-CategoryCumulativeReturn5Yr": "37.73571", // Done --> categoryReturns.fiveYear
        "DP-CumulativeReturn5Yr": "40.62737",
        "TTR-CumulativeReturn5Yr": "42.00107", // Done --> returns.fiveYear
        "QETP-CumulativeReturn5Yr": "41.36604", // Done --> peerReturns.fiveYear
        "TTR-CategoryCumulativeReturn10Yr": "89.55863", // Done --> categoryReturns.tenYear
        "QETP-CumulativeReturn10Yr": "111.41862", // Done --> peerReturns.tenYear
        "TTR-CumulativeReturn10Yr": "113.3899", // Done --> returns.tenYear
        "DP-CumulativeReturn10Yr": "113.22261",
        "DP-CategoryReturn1Day": "-0.19967", // Done --> categoryReturns.oneDay
        "DP-Return1Day": "-0.21581", // Done --> returns.oneDay
        "DP-CategoryReturn1Week": "-0.08667", // Done --> categoryReturns.oneWeek
        "DP-Return1Week": "-0.08506", // Done --> returns.oneWeek
        "TTR-Return3Mth": "3.20455", // Done --> returns.threeMonth
        "TTR-Return2Yr": "8.63770", // Done --> returns.twoYear
        "TTR-Return4Yr": "6.70722", // Done --> returns.fourYear
        "TTR-Return7Yr": "7.82012", // Done --> returns.sevenYear
        "TTR-ReturnSinceInception": "8.96769", // Done --> returns.sinceInception
        "AABRP-PortfolioDate": "2025-04-15", // Done --> portfolio.date
        "PSRP-NumberofHolding": "207", // Done --> portfolio.holdings
        "FNA-AsOfOriginalReported": "245702641000", // Done --> portfolio.aum
        "AABRP-AssetAllocBondNet": "95.70541", // Done --> portfolio.assetAllocation.bond
        "AABRP-AssetAllocCashNet": "4.02536", // Done --> portfolio.assetAllocation.cash
        "AABRP-AssetAllocEquityNet": "0", // Done --> portfolio.assetAllocation.equity
        "AABRP-OtherNet": "0.26923", // Done --> portfolio.assetAllocation.other
        "MR-RatingOverall": "5", // Done --> rating.overall
        "MR-NumberOfFundsOverall": "278", // Done --> rating.numberOfFunds
        "MR-RiskOverall": "Below Average", // Done --> rating.risk
        "MR-ReturnOverall": "High", // Done --> rating.return
        "IAIP-AIP": [
          {
            "Frequency": "Weekly",
            "FrequencyDate": "Monday|Tuesday|Wednesday|Thursday|Friday",
            "MinTenure": "6",
            "SIType": "SIP",
            "MinAmount": "100"
          },
          {
            "Frequency": "Monthly",
            "FrequencyDate": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28",
            "MinTenure": "6",
            "SIType": "SIP",
            "MinAmount": "100"
          },
          {
            "Frequency": "Daily",
            "FrequencyDate": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28",
            "MinTenure": "20",
            "SIType": "STP",
            "MinAmount": "500",
            "SubsquentAmount": "100"
          },
          {
            "Frequency": "Weekly",
            "FrequencyDate": "1|7|14|21|28",
            "SIType": "STP",
            "MinAmount": "500"
          },
          {
            "Frequency": "Monthly",
            "FrequencyDate": "1|7|10|14|20|21|28",
            "MinTenure": "12",
            "SIType": "STP",
            "MinAmount": "500",
            "SubsquentAmount": "1"
          },
          {
            "Frequency": "Quarterly",
            "FrequencyDate": "1|7|10|14|20|21|28",
            "MinTenure": "6",
            "SIType": "STP",
            "MinAmount": "1000",
            "SubsquentAmount": "1"
          },
          {
            "Frequency": "Daily",
            "FrequencyDate": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31",
            "SIType": "SWP",
            "MinAmount": "500"
          },
          {
            "Frequency": "Weekly",
            "FrequencyDate": "Monday|Tuesday|Wednesday|Thursday|Friday",
            "SIType": "SWP",
            "MinAmount": "500",
            "SubsquentAmount": "1"
          },
          {
            "Frequency": "Monthly",
            "FrequencyDate": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28",
            "MinTenure": "6",
            "SIType": "SWP",
            "MinAmount": "500",
            "SubsquentAmount": "1"
          },
          {
            "Frequency": "Quarterly",
            "FrequencyDate": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28",
            "MinTenure": "4",
            "SIType": "SWP",
            "MinAmount": "500",
            "SubsquentAmount": "1"
          },
          {
            "Frequency": "Semi-annually",
            "FrequencyDate": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28",
            "MinTenure": "2",
            "SIType": "SWP",
            "MinAmount": "500",
            "SubsquentAmount": "1"
          },
          {
            "Frequency": "Annually",
            "FrequencyDate": "1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28",
            "MinTenure": "1",
            "SIType": "SWP",
            "MinAmount": "500",
            "SubsquentAmount": "1"
          }
        ]
      }
    }
  ]
}