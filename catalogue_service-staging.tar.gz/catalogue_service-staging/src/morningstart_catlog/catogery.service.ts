import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { CategoryRepository } from 'src/mongoose/repositories/category.repository';
import { PipelineStage } from 'mongoose';
import {
  Category,
  CategoryCollectionDocument,
} from 'src/mongoose/schemas/catogery.schema';
import { Fund, FundDocument } from 'src/mongoose/schemas/fund.schema';
import {
  MorningStarFund,
  MorningStarFundDocument,
} from 'src/mongoose/schemas/msFunds.schema';
import { NavDocument, Navs } from 'src/mongoose/schemas/navs.schema';
import {
  SubCategory,
  SubCategoryDocument,
} from 'src/mongoose/schemas/sub-catogery.schema';
import axios from 'axios';
import { GetNavs } from './dto/getNav.dto';
import { ResponseConstructor } from 'src/res/reponse.cunstructor';
@Injectable()
export class CatogeryService {
  constructor(
    // private readonly catogetModel: Model<CategoryCollectionDocument>,
    @InjectModel(`${Category.name}`)
    private categoryModel: Model<CategoryCollectionDocument>,
    @InjectModel(`${SubCategory.name}`)
    private subCategoryModel: Model<SubCategoryDocument>,
    @InjectModel(Navs.name) private navModel: Model<NavDocument>,
    @InjectModel(MorningStarFund.name)
    private morningStarFundModel: Model<MorningStarFundDocument>,

    private readonly categoryRepository: CategoryRepository,
  ) {}

  createCatogeryBulk(data: string[]) {
    let allData = data.map((item) => {
      let myObj = {
        CategoryName: item,
      };
      return this.categoryRepository.create(myObj);
    });
    return Promise.all(allData);
  }

  async createSubCatogeryBulk(data: object[]) {
    // console.log("🚀 ~ CatogeryService ~ createSubCatogeryBulk ~ data:", data)
    let allData = data.map(async (item) => {
      let catogeryName = item['Morningstar Broad Category group'];

      let catogery: any = await this.categoryModel.findOne({
        CategoryName: catogeryName,
      });

      // if(!catogery){
      //     let myObj = {
      //         CategoryName: catogeryName
      //     }
      //     catogery = await this.categoryModel.create(myObj);
      // }

      let constructorData = {
        srNo: item['Sr No.'],
        morningstarCatId: item['Category Code- Morningstar'],
        sebiCategoryMame: item['SEBI Category name'],
        name: item['Category Name - Morningstar'],
        Category_id: catogery._id,
      };
      console.log('🚀 ~ CatogeryService ~ allData ~ item:', constructorData);

      return this.subCategoryModel.create(constructorData);
    });
    return Promise.all(allData);
  }

  async getSubCatogeryBymorningstarCatId(id: string): Promise<any> {
    return this.subCategoryModel.findOne({ morningstarCatId: id }).exec();
  }

  async getAllCatogery(): Promise<any> {
    return this.categoryModel.find().exec();
  }

  async addNavsBulk(body: []): Promise<any> {
    console.log('addNavsBulk hit');

    let BATCH_SIZE = 1000;
    const fundsISin = body['fundsISin'];

    try {
      console.log('inside try');

      let isins: string[] = [];
      if (fundsISin?.length == 0) {
        console.log('inside if 0');

        const funds = await this.morningStarFundModel
          .find({}, { isin: 1 })
          .lean();
        isins = funds.map((f) => f.isin);
      } else {
        console.log('inside else ');

        for (let e of fundsISin) {
          isins.push(e);
        }
      }
      for (const isin of isins) {
        console.log('inside loop fro isin ');

        try {
          console.log('inside try');

          let res = await this.fetchNavData(isin);

          const navDocs: Partial<Navs>[] = res.map((v) => ({
            isin: isin,
            nav: v.v,
            date: new Date(v.d), // use Date type
            dayStartNav: null,
            dayEndNav: null,
          }));
          // Batch insert
          for (let i = 0; i < navDocs.length; i += BATCH_SIZE) {
            const batch = navDocs.slice(i, i + BATCH_SIZE);
            await this.navModel.insertMany(batch, { ordered: false });
            console.log(`Inserted batch ${i / BATCH_SIZE + 1} for ${isin}`);
          }
        } catch (error) {
          console.log('error in  first catch ,', error);
          return error;
        }
      }
      // }
    } catch (error) {
      console.log('error in  first catch ,', error);

      return error;
    }
  }

  async fetchNavData(isin: string): Promise<any> {
    console.log('got hit');

    let url = `https://api.morningstar.com/service/mf/Price/isin/${isin}?accesscode=b2vcwc3n1sesfk3gceb6pnojeh29mai3&format=json`;
    console.log('url ,', url);

    try {
      const res = await axios.get(url);
      return res.data.data.Prices;
    } catch (error) {
      console.error(`API error for ${isin}: ${error.message}`);
      return [];
    }
  }

  //get navs
  // async findNavsByIsinAndDateRange(data: GetNavs): Promise<Navs[] | any> {
  //   const { startDate, endDate, isin, offset, limit } = data;
  //   try {
  //     const filter: any = {
  //       isin: { $in: isin },
  //     };

  //     if (startDate || endDate) {
  //       filter.date = {};
  //       if (startDate) {
  //         filter.date.$gte = new Date(`${startDate}T00:00:00.000Z`);
  //       }
  //       if (endDate) {
  //         filter.date.$lte = new Date(`${endDate}T00:00:00.000Z`);
  //       }
  //     }

  //     let query = this.navModel.find(filter).lean();
  //     if (
  //       offset !== undefined &&
  //       offset !== null &&
  //       typeof offset === 'number'
  //     ) {
  //       query = query.skip(offset);
  //     }

  //     if (limit !== undefined && limit !== null && typeof limit === 'number') {
  //       query = query.limit(limit);
  //     }
  //     const [data, total] = await Promise.all([
  //       query,
  //       this.navModel.countDocuments(filter),
  //     ]);
  //     const res = { total, count: data.length, data };
  //     return new ResponseConstructor(res, 'success').compose();
  //   } catch (error) {
  //     return new ResponseConstructor(error, 'error').compose();
  //   }
  // }
  async getNavsGraph(dto:GetNavs) {
    try {
      const { isin, startDate, endDate } = dto;

  const match: any = { isin };
  if (startDate) match.date = { ...match.date, $gte: new Date(startDate) };
  if (endDate) match.date = { ...match.date, $lte: new Date(endDate) };

  // const pipeline:PipelineStage[] = [
  //   {
  //     $facet: {
  //       bucketed: [
  //         { $match: match },
  //         {
  //           $bucketAuto: {
  //             groupBy: "$date",
  //             buckets: dto?.limit || 200,
  //             output: {
  //               firstDoc: { $first: "$$ROOT" }
  //             }
  //           }
  //         },
  //         { $replaceRoot: { newRoot: "$firstDoc" } }
  //       ],
  //       start: [
  //         { $match: match },
  //         { $sort: { date: 1 } },
  //         { $limit: 1 }
  //       ],
  //       end: [
  //         { $match: match },
  //         { $sort: { date: -1 } },
  //         { $limit: 1 }
  //       ]
  //     }
  //   },
  //   {
  //     $project: {
  //       data: {
  //         $setUnion: ["$start", "$bucketed", "$end"]
  //       }
  //     }
  //   },
  //   { $unwind: "$data" },
  //   { $replaceRoot: { newRoot: "$data" } },
  //   { $sort: { date: 1 } },
  //   { $limit:dto?.limit || 200} // Optional: sort final result
  // ];

  const pipeline:PipelineStage[] = [
  {
    $match: match
  },
  {
    $facet: {
      bucketed: [
        {
          $bucketAuto: {
            groupBy: "$date",
            buckets: dto?.limit ? dto?.limit - 1 : 199,
            output: {
              firstDoc: { $first: "$$ROOT" }
            }
          }
        },
        { $replaceRoot: { newRoot: "$firstDoc" } }
      ],
      start: [
        { $sort: { date: 1 } },
        { $limit: 1 }
      ],
      end: [
        { $sort: { date: -1 } },
        { $limit: 1 }
      ]
    }
  },
  {
    $project: {
      data: { $setUnion: ["$start", "$bucketed", "$end"] }
    }
  },
  { $unwind: "$data" },
  { $replaceRoot: { newRoot: "$data" } },
  { $sort: { date: 1 } }

  ];
  const data = await this.navModel.aggregate(pipeline);
  // console.log("data ,",data);
  
  
  return new ResponseConstructor(data || [],'success').compose()
      
    } catch (error) {
      return new ResponseConstructor(error,'error').compose()
    }
  
}


}
