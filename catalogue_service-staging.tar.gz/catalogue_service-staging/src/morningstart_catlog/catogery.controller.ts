import { Controller } from "@nestjs/common";
import { MessagePattern } from "@nestjs/microservices";
import { CatogeryService } from "./catogery.service";

@Controller()
export class CatogeryController {

    constructor(
        private readonly catogeryService: CatogeryService
    ) {}

    @MessagePattern('create_catogery')
    async createCatogery(data: any) {
        return this.catogeryService.createCatogeryBulk(data);
    }

    @MessagePattern('create_sub_catogery')
    async createSubCatogery(data: any) {
        return this.catogeryService.createSubCatogeryBulk(data);
    }

    @MessagePattern('get_catogery')
    async getCatogery() {
        // return this.catogeryService.getCatogery();
    }

    @MessagePattern({cmd:"addNavs_bulk"})
    async addNavsBulk(data) {        
        return this.catogeryService.addNavsBulk(data)
        // return this.catogeryService.getCatogery();
    }

    @MessagePattern({cmd:"navs_isin_daterange"})
    async findNavsByIsinAndDateRange(data) {        
        return this.catogeryService.getNavsGraph(data)
        // return this.catogeryService.getCatogery();
    }
}