import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { MqService } from './mq.service';
import * as amqp from 'amqplib';
import { MorningstarCatlogService } from 'src/morningstart_catlog/morningstar.catlog.service';

@Injectable()
export class MorningStarConsumerService implements OnModuleInit {
  private readonly logger = new Logger(MorningStarConsumerService.name);


  constructor(
    private readonly mqService: MqService,
    private readonly morningstarService: MorningstarCatlogService
  ) { }

  async onModuleInit() {
    await this.consumeQueue('morning_star_sync');
    await this.consumeQueue('morning_star_holding_sync');
    console.log("🚀 morning_star_sync start listning");
  }

  private async consumeQueue(queueName: string) {
    await this.mqService.listenToQueue(queueName, async (data, msg, channel: amqp.Channel) => {
      try {
        this.logger.log(`📥 Received from ${queueName}: ${JSON.stringify(data)}`);
        switch (queueName) {
          case 'morning_star_sync':
            await this.morningstarService.processSingleIsin(data);
            break;
          case 'morning_star_holding_sync':
            await this.morningstarService.processSingleIsinHolding(data);
            break;

          default:
            break;
        }



        channel.ack(msg);
      } catch (err) {
        this.logger.error(`❌ Error processing message from ${queueName}: ${err.message}`, err.stack);

        // 🔁 Decide whether to requeue the message (true) or discard (false);
        const requeue = true;

        channel.nack(msg, false, requeue);
      }
    });
  }
}
