import { Module } from "@nestjs/common";
// import { MqService } from "src/mqConsumer.service";
import { OnSearchConsumerService } from "./onSearchConsumer.service";
import { MqService } from "./mq.service";
import { CatlogProcesserService } from "src/catalog-processer/catlog-processer.service";
import { MongooseModule } from "@nestjs/mongoose";
import { OndcFundPlan, OndcFundPlanSchema } from "src/mongoose/schemas/ondc-fund-plan.schema";
import { MorningStarConsumerService } from "./morningStarConsumer.service";
import { MorningstarCatlogService } from "src/morningstart_catlog/morningstar.catlog.service";
import { MorningstarCatlogModule } from "src/morningstart_catlog/morningstar.catlog.module";
import { SharedMongooseModule } from "src/mongoose/mongoose.module";

@Module({
    imports: [
        // MongooseModule.forFeature([
        //   { name: OndcFundPlan.name, schema: OndcFundPlanSchema },
        // ]),
        SharedMongooseModule,
        MorningstarCatlogModule,
      ],
    controllers: [],
    providers: [MqService,OnSearchConsumerService,MorningStarConsumerService,CatlogProcesserService],
    exports: [MqService,OnSearchConsumerService]
})
export class ConsumerModule {}