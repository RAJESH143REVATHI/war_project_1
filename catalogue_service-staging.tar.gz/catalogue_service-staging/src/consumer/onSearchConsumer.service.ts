import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { MqService } from './mq.service';
import * as amqp from 'amqplib';
import { CatlogProcesserService } from 'src/catalog-processer/catlog-processer.service';

@Injectable()
export class OnSearchConsumerService implements OnModuleInit {
  private readonly logger = new Logger(OnSearchConsumerService.name);


  constructor(
    private readonly mqService: MqService, 
    readonly catlogProcessorService: CatlogProcesserService
  ) { }

  async onModuleInit() {
    await this.consumeQueue('on_search_queue');
    console.log("🚀 on_search_queue start listning");
  }

  private async consumeQueue(queueName: string) {
    await this.mqService.listenToQueue(queueName, async (data, msg, channel: amqp.Channel) => {
      try {
        this.logger.log(`📥 Received from ${queueName}: ${JSON.stringify(data)}`);
        this.logger.log('bpp',data.context.bpp_id)
        if(data.context.bpp_id == 'api.preprod.cybrilla.com' || data.context.bpp_id == 'api.sandbox.cybrilla.com') {
          this.catlogProcessorService.processMutualFundData(data)
        } 
        // else if(data.context.bpp_id == 'api.sandbox.cybrilla.com') {
        //   this.catlogProcessorService.processMutualFundData(data)
        // }
        
        channel.ack(msg);
      } catch (err) {
        this.logger.error(`❌ Error processing message from ${queueName}: ${err.message}`, err.stack);

        // 🔁 Decide whether to requeue the message (true) or discard (false);
        const requeue = true;

        channel.nack(msg, false, requeue);
      }
    });
  }
}
