// mq.service.ts
import { Injectable } from '@nestjs/common';
import * as amqp from 'amqplib';
import { ConfigService } from '@nestjs/config';
import { Logger } from '@nestjs/common';

type MsgHandler = (data: any, rawMsg: amqp.ConsumeMessage, channel: amqp.Channel) => void;

@Injectable()
export class MqService {
  private connection: amqp.Connection;
  private channel: amqp.Channel;

  constructor(private readonly configService: ConfigService) {}

  async connect(): Promise<void> {
    const url = this.configService.get<string>('rabbitmq.url');
    this.connection = await amqp.connect(url);
    this.channel = await this.connection.createChannel();
    Logger.log('RabbitMQ connection established');
  }

  /**
   * Listen to a specific queue with custom callback.
   * @param queueName 
   * @param handler function(data, rawMsg, channel)
   */
  async listenToQueue(queueName: string, handler: MsgHandler): Promise<void> {
    if (!this.channel) {
      await this.connect();
    }

    await this.channel.assertQueue(queueName, { durable: true });
    Logger.log(`Listening on queue: ${queueName}`);

    await this.channel.consume(queueName, (msg) => {
      if (msg) {
        try {
          const data = JSON.parse(msg.content.toString());
          handler(data, msg, this.channel); // Pass parsed data + raw message
        } catch (err) {
          Logger.error(`Error processing message from ${queueName}:`, err);
        }
      }
    }, {
      noAck: false,
    });
  }

  /**
 * Publish multiple messages to a queue in bulk.
 * @param queueName - The name of the queue.
 * @param messages - Array of messages to publish.
 */
public async publishMessagesInBulk(queueName: string, messages: any[]): Promise<void> {
  if (!this.channel) {
    await this.connect();
  }

  await this.channel.assertQueue(queueName, { durable: true });
  Logger.log(`Publishing ${messages.length} messages to queue: ${queueName}`);

  for (const msg of messages) {
    console.log("🚀 ~ MqService ~ publishMessagesInBulk ~ msg:", msg)
    const success = this.channel.sendToQueue(queueName, Buffer.from(JSON.stringify(msg)));
    if (!success) {
      Logger.warn(`Queue ${queueName} buffer is full. Consider using publisher confirms or backpressure handling.`);
    }
  }
}


  public async publishMessage(queueName : string, data : any) {
    if(!this.channel) {
      await this.connect();
    }

    await this.channel.assertQueue(queueName, { durable: true });
    Logger.log(`Data inserted in queue: ${queueName}`);

    this.channel.sendToQueue(queueName, Buffer.from(JSON.stringify(data)))
}

  async close() {
    await this.channel?.close();
    await this.connection?.close();
    Logger.log('RabbitMQ connection closed');
  }
}
