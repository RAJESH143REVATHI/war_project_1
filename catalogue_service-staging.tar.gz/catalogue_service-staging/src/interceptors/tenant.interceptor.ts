// src/common/interceptors/tenant.interceptor.ts
import {
    Injectable,
    NestInterceptor,
    ExecutionContext,
    CallHandler,
  } from '@nestjs/common';
  import { Observable, tap } from 'rxjs';
  import { TenantService } from 'src/tenant/tenant.service';
  import { RmqContext } from '@nestjs/microservices';
  
  @Injectable()
  export class TenantInterceptor implements NestInterceptor {
    // constructor(private readonly tenantService: TenantService) {}
  
    // async intercept(
    //   context: ExecutionContext,
    //   next: CallHandler,
    // ): Promise<Observable<any>> {
    //   const rmqContext: RmqContext = context.switchToRpc().getContext<RmqContext>();
    //   const data = context.switchToRpc().getData();
  
    //   // You can extract `x-arn` from data or from message properties
    //   const tenant_id = data?.context?.tenant_id || rmqContext.getMessage()?.properties?.headers?.['x-arn'];
  
    //   if (!tenant_id) {
    //     throw new Error('Missing tenant tenant_id in RabbitMQ message');
    //   }
  
    //   const connection = await this.tenantService.getTenantConnection(tenant_id);
  
    //   // Mutate the payload to include the tenant context
    //   data.tenantContext = {
    //     tenant_id,
    //     connection,
    //   };
  
    //   return next.handle();
    // }

    constructor() {
      console.log('TenantInterceptor instantiated');
    }
    

    intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
      const rpcContext = context.switchToRpc().getContext<RmqContext>();
      const pattern = rpcContext.getPattern();
  
      console.log(`[RMQ] Received pattern: ${JSON.stringify(pattern)}`);
  
      return next.handle().pipe(
        tap(() => {
          // Optional: log after response
          console.log(`[RMQ] Processed pattern: ${JSON.stringify(pattern)}`);
        }),
      );
    }
  }
  