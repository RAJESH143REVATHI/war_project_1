import { NestFactory } from '@nestjs/core';
import { CatalogModule } from './catalog/catalog.module';
import { Transport } from '@nestjs/microservices';
import { ConfigService } from '@nestjs/config';
import { AppModule } from './app.module';
import { TenantService } from './tenant/tenant.service';
import { TenantInterceptor } from './interceptors/tenant.interceptor';

async function bootstrap() {

  const app = await NestFactory.create(AppModule);

  const configService = app.get(ConfigService);

  await app.init();

  const PORT = 3001
  const microservices = await NestFactory.createMicroservice(AppModule, {
    transport: Transport.RMQ,
    options: {
      urls: [configService.get<string>('rabbitmq.url')],
      queue: process.env.CATALOG_SERVICE_QUEUE,
      queueOptions: { durable: true },
    },
  });

   // Global interceptor injection with dependency
  //  const tenantService = microservices.get(TenantService);
  //  microservices.useGlobalInterceptors(new TenantInterceptor());

  await microservices.listen();
}
bootstrap();
