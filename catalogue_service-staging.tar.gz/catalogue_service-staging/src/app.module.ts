import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { CatalogModule } from './catalog/catalog.module';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import rabbitmqConfig from './config/rabbitmq.config';
import { ConsumerModule } from './consumer/consumer.module';
import { MorningstarCatlogModule } from './morningstart_catlog/morningstar.catlog.module';



@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, load: [rabbitmqConfig] }),
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: async (configService: ConfigService) => ({
        uri: `mongodb://${configService.get<string>(
          'MONGO_USERNAME',
        )}:${configService.get<string>(
          'MONGO_PASSWORD',
        )}@${configService.get<string>(
          'MONGO_HOST',
        )}:${configService.get<string>(
          'MONGO_PORT',
        )}/${configService.get<string>('MONGO_DATABASE')}?authSource=admin`,
      }),
      inject: [ConfigService],
    }),
    CatalogModule,
    ConsumerModule,
    MorningstarCatlogModule
  ],
  controllers: [AppController],
  providers: [
    AppService,
    // {
    //   provide: APP_INTERCEPTOR,
    //   useClass: TenantInterceptor
    // }
  ],
})
export class AppModule {}
