import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Schemas } from "./schemas";
import { CategoryRepository } from "./repositories/category.repository";
import { SubCategoryRepository } from "./repositories/subCategory.repository";
import { AmcRepository } from "./repositories/amc.repository";
import { OndcFundRepository } from "./repositories/ondcFund.repository";

@Module({
    imports: [MongooseModule.forFeature(Schemas)],
    providers: [CategoryRepository,SubCategoryRepository,AmcRepository,OndcFundRepository],
    exports: [MongooseModule,CategoryRepository,SubCategoryRepository,AmcRepository,OndcFundRepository]
})
export class SharedMongooseModule {}