import { Injectable } from "@nestjs/common";
import { BaseRepository } from "./base.repository";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { OndcFundPlan } from "../schemas/ondc-fund-plan.schema";

@Injectable()
export class OndcFundRepository extends BaseRepository<OndcFundPlan> {
    constructor(@InjectModel(OndcFundPlan.name) private readonly ondcFundModel: Model<OndcFundPlan>) {
        super(ondcFundModel);
    }

    /**
     * this class will have all the methods of @see {@link BaseRepository}
     * We can still add Category specific methods
     */
}