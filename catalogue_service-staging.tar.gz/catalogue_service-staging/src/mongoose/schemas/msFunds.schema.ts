import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Types } from 'mongoose';
import { Category } from './catogery.schema';
import { SubCategory } from './sub-catogery.schema';
import { Amc } from './amc-collection.schema';
import { OndcFundPlan } from './ondc-fund-plan.schema';


@Schema({ _id: false })
export class FundLevelCategory {
  @Prop() name: string;
  @Prop() code: string;
}

@Schema({ _id: false })
export class Manager {
  @Prop() id: string;
  @Prop() name: string;
  @Prop() role: string;
  @Prop() startDate: string;
  @Prop() tenure: string;
}

@Schema({ _id: false })
export class Risk {
  @Prop() level: string;
  @Prop() prcMatrix: string;
}

@Schema({ _id: false })
export class Load {
  @Prop() deferredDetails: string;
  @Prop() maxDeferLoad: string;
}

@Schema({ _id: false })
export class ExpenseRatio {
  @Prop() current: string;
  @Prop() currentDate: string;
  @Prop() semiAnnual: string;
  @Prop() semiAnnualDate: string;
}

@Schema({ _id: false })
export class Nav {
  @Prop() value: string;
  @Prop() date: string;
  @Prop() change: string;
  @Prop() changePercent: string;
}

@Schema({ _id: false })
export class Returns {
  @Prop() oneDay: string;
  @Prop() oneWeek: string;
  @Prop() threeMonth: string;
  @Prop() twoYear: string;
  @Prop() threeYear: string;
  @Prop() fourYear: string;
  @Prop() fiveYear: string;
  @Prop() sevenYear: string;
  @Prop() tenYear: string;
  @Prop() sinceInception: string;
}

@Schema({ _id: false })
export class CategoryReturns {
  @Prop() oneDay: string;
  @Prop() oneWeek: string;
  @Prop() threeYear: string;
  @Prop() fiveYear: string;
  @Prop() tenYear: string;
}

@Schema({ _id: false })
export class PeerReturns {
  @Prop() threeYear: string;
  @Prop() fiveYear: string;
  @Prop() tenYear: string;
}

@Schema({ _id: false })
export class Portfolio {
  @Prop() date: string;
  @Prop() holdings: number;

  @Prop({ type: Object }) assetAllocation: {
    bond: string;
    cash: string;
    equity: string;
    other: string;
  };

  @Prop() aum: string;
}

@Schema({ _id: false })
export class Rating {
  @Prop() overall: string;
  @Prop() risk: string;
  @Prop() return: string;
  @Prop() numberOfFunds: string;
}

@Schema({ _id: false })
export class Fulfillment {
  @Prop() frequency: string;
  @Prop() frequencyDate: string;
  @Prop() minTenure: string;
  @Prop() siType: string;
  @Prop() minAmount: string;
}

export type MorningStarFundDocument = MorningStarFund & Document;
@Schema({ timestamps: true })
export class MorningStarFund extends Document {
  @Prop(
    {required: true, unique: true},
  ) isin: string;
  @Prop() name: string;
  @Prop() legalName: string;
  @Prop() mstarId: string;

  @Prop({ type: Types.ObjectId, ref: Category.name })
  category_id: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: SubCategory.name })
  subCategory_id: Types.ObjectId;

  @Prop({ type: Types.ObjectId, ref: Amc.name })
  amc_id: Types.ObjectId;

  @Prop() purchaseMode: string;
  @Prop() advisoryCompany: string;
  @Prop() globalCategory: string;
  @Prop() category: string;

  @Prop({ type: FundLevelCategory })
  fundLevelCategory: FundLevelCategory;

  @Prop({ type: [Manager] })
  managers: Manager[];

  @Prop({ type: Risk })
  risk: Risk;

  @Prop() sipAvailable: boolean;
  @Prop() indexFund: boolean;
  @Prop() masterFeeder: boolean;
  @Prop() distributionFrequency: string;

  @Prop({ type: Load })
  load: Load;

  @Prop() managementFee: string;

  @Prop({ type: ExpenseRatio })
  expenseRatio: ExpenseRatio;

  @Prop() swpAvailable: boolean;

  @Prop({ type: Nav })
  nav: Nav;

  @Prop({ type: Returns })
  returns: Returns;

  @Prop({ type: CategoryReturns })
  categoryReturns: CategoryReturns;

  @Prop({ type: PeerReturns })
  peerReturns: PeerReturns;

  @Prop({ type: Portfolio })
  portfolio: Portfolio;

  @Prop({ type: Rating })
  rating: Rating;

  @Prop({ type: [Fulfillment] })
  ms_fullfilments: Fulfillment[];

  @Prop()
  minSipAt: Number

  @Prop()
  ondcFundData :OndcFundPlan
}

export const MorningStarFundSchema = SchemaFactory.createForClass(MorningStarFund);
