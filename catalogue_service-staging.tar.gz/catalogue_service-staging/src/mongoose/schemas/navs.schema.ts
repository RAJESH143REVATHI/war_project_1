import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import mongoose, { Document, ObjectId } from "mongoose";

export type NavDocument = Navs & Document;

@Schema({versionKey:false,timestamps:false,})
export class Navs{
    @Prop()
    _id:mongoose.Types.ObjectId;

    @Prop({required:true})
    isin:string;

    @Prop({required:true})
    nav:string;
    
    @Prop({required:true})
    date:Date

    @Prop({required:false})
    dayStartNav:string;

    @Prop({required:false})
    dayEndNav:string;
    
}


export const NavSchema = SchemaFactory.createForClass(Navs);
NavSchema.index({ isin: 1, date: 1 });

