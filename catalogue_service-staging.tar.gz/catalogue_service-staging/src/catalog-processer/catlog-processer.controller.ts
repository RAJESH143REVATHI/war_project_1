import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { CatlogProcesserService } from './catlog-processer.service';
import { CreateCatlogProcesserDto } from './dto/create-catlog-processer.dto';


@Controller('catlog-processer')
export class CatlogProcesserController {
  constructor(private readonly catlogProcesserService: CatlogProcesserService) {}

  @Post()
  create(@Body() createCatlogProcesserDto: CreateCatlogProcesserDto) {
    //return this.catlogProcesserService.create(createCatlogProcesserDto);
  }

  
}
