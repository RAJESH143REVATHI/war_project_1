import { Module } from '@nestjs/common';
import { CatlogProcesserService } from './catlog-processer.service';
import { CatlogProcesserController } from './catlog-processer.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { OndcFundPlan, OndcFundPlanSchema } from 'src/mongoose/schemas/ondc-fund-plan.schema';
import { SharedMongooseModule } from 'src/mongoose/mongoose.module';

@Module({
  imports: [
    // MongooseModule.forFeature([
    //   { name: OndcFundPlan.name, schema: OndcFundPlanSchema },
    // ]),
    SharedMongooseModule
  ],
  controllers: [CatlogProcesserController],
  providers: [CatlogProcesserService],
  exports: [CatlogProcesserService],
})
export class CatlogProcesserModule {}
