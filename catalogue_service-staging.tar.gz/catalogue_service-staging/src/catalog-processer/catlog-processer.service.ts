import { Injectable } from '@nestjs/common';
import { CreateCatlogProcesserDto } from './dto/create-catlog-processer.dto';
import { UpdateCatlogProcesserDto } from './dto/update-catlog-processer.dto';

import * as fs from 'fs';
import * as path from 'path';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { OndcFundPlan, OndcFundPlanDocument } from 'src/mongoose/schemas/ondc-fund-plan.schema';

@Injectable()
export class CatlogProcesserService {

  constructor(
    @InjectModel(OndcFundPlan.name)
    private readonly ondcFundPlanModel: Model<OndcFundPlanDocument>,
  ) { }

  async processMutualFundData(rawData) {

    console.log('in parser');
    const providers = rawData.message.catalog.providers || [];
    const bpp_id = rawData.context.bpp_id;
    const bpp_uri = rawData.context.bpp_uri;

    const structuredOutput: any = [];

    for (const provider of providers) {
      const providerId = provider.id;
      const providerName = provider.descriptor.name;
      const items = provider.items || [];
      const fulfillments = provider.fulfillments || [];

      // Build a fulfillment ID → Type mapping for this provider
      const fulfillmentMap = Object.fromEntries(
        fulfillments.map(f => [f.id, f.type.toUpperCase()])
      );

      for (const item of items) {

        const entry: any = {
          'providerID': providerId,
          'providerName': providerName,
          'schemeID': item.parent_item_id || '',
          'schemeName': '', // Not available
          'planID': item.id,
          'planName': item.descriptor.name,
          'isin': '',
          'rtaIdentifier': '',
          'amfiIdentifier': '',
          'plan': '',
          'option': '',
          'idcwOption': '',
          'planType': item.tags?.[0]?.list?.[0]?.value || '',
          'bppId': bpp_id,
          'bppUri': bpp_uri,
          'fullfillments': []
        };


        // Iterate through the tags to find the ISIN value
        for (const tag of item.tags) {
          if (tag.descriptor.code === 'PLAN_IDENTIFIERS') {
            for (const item of tag.list) {
              if (item.descriptor.code === 'ISIN') {
                entry['isin'] = item.value;
              }
              if (item.descriptor.code === 'RTA_IDENTIFIER') {
                entry['rtaIdentifier'] = item.value;
              }
              if (item.descriptor.code === 'AMFI_IDENTIFIER') {
                entry['amfiIdentifier'] = item.value;
              }
            }
          }

          if (tag.descriptor.code === 'PLAN_OPTIONS') {
            for (const item of tag.list) {
              if (item.descriptor.code === 'PLAN') {
                entry['plan'] = item.value;
              }
              if (item.descriptor.code === 'OPTION') {
                entry['option'] = item.value;
              }
              if (item.descriptor.code === 'IDCW_OPTION') {
                entry['idcwOption'] = item.value;
              }
            }
          }
        }


        let sipCount = 1;

        for (const fid of item.fulfillment_ids || []) {

          //find unique fullfllment and extract key value
          const fulfillment = fulfillments.find(f => f.id === fid);
          const result: Record<string, any> = {};
          for (const tag of fulfillment.tags) {
            if (!tag.list || !Array.isArray(tag.list)) continue;

            for (const item of tag.list) {
              const code = item.descriptor?.code;
              const value = item.value;

              if (code) {
                result[code] = value;
              }
            }
          }

          const ftype = fulfillmentMap[fid];
          if (ftype === 'LUMPSUM') {
            result['ftype'] = ftype;
            result['fId'] = fid;
            //entry['fulfillment'] = result;
            entry.fullfillments.push(result)
            entry['Lumpsum Fulfillment ID'] = fid;
          } else if (ftype === 'SIP') {
            result['ftype'] = ftype;
            result['fId'] = fid;
            //entry['fulfillment'] = result;
            entry.fullfillments.push(result)
            entry[`SIP Fulfillment ID (${sipCount})`] = fid;
            sipCount++;
          } else if (ftype === 'REDEMPTION') {
            result['ftype'] = ftype;
            result['fId'] = fid;
            //entry['fulfillment'] = result;
            entry.fullfillments.push(result)
            entry['Redemption Fulfillment ID'] = fid;
          }
        }

        const isin = entry.isin?.trim();

        // Skip if ISIN is missing or empty
        if (isin) {
          structuredOutput.push(entry);
        }
      }
    }

    //save data to mongo
    let createNewData: any = [];
    let updatePromisses: any = [];


    for (const entry of structuredOutput) {
      const isin = entry.isin?.trim();

      let checkIsinExist = await this.ondcFundPlanModel.find({ isin }).exec();

      if (checkIsinExist.length) {
        let upd = this.ondcFundPlanModel.updateOne(
          { isin: isin },         // Find by ISIN
          { $set: entry },        // Update with new data
          { upsert: true }        // Insert if not found
        );
        updatePromisses.push(upd)
      } else {
        createNewData.push(entry)
      }

      
    }

    let finalQuery = await Promise.all(
      [...updatePromisses,this.ondcFundPlanModel.insertMany(createNewData)]
    )
    // await this.ondcFundPlanModel.insertMany(structuredOutput);



    // Save to JSON
    const outputPath = path.join(__dirname, 'mf_structured_data.json');
    fs.writeFileSync(outputPath, JSON.stringify(structuredOutput, null, 2));
    console.log(`Structured data saved to ${outputPath}`);
    console.log(`Structured output ${JSON.stringify(structuredOutput, null, 2)}`);
  }

  async fetchAllIsin(): Promise<any> {
    const allIsin = await this.ondcFundPlanModel.distinct('isin');
    return allIsin
  }


  /*
    async processMutualFundData(rawData) {
      // Load the JSON data
      //const filePath = path.join(__dirname, '..', 'api_sandbox_cybrilla_com.json'); // Adjusted path
      //const rawData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  
      const provider = rawData.message.catalog.providers[0];
      const bpp_id = rawData.context.bpp_id;
      const bpp_uri = rawData.context.bpp_uri;
      const providerId = provider.id;
      const providerName = provider.descriptor.name;
      const items = provider.items || [];
      const fulfillments = provider.fulfillments || [];
  
      // Build a fulfillment ID → Type mapping
      const fulfillmentMap = Object.fromEntries(
          fulfillments.map(f => [f.id, f.type.toUpperCase()])
      );
  
      // Generate structured list
      const structuredOutput = items.map(item => {
  
          // if (!data.tags || !Array.isArray(data.tags)) {
          //     return null;
          // }
          var isinG = '';
          // Iterate through the tags to find the ISIN value
          for (const tag of item.tags) {
              if (tag.descriptor.code === 'PLAN_IDENTIFIERS') {
                  for (const item of tag.list) {
                      if (item.descriptor.code === 'ISIN') {
                          isinG = item.value; // Return the ISIN value
                      }
                  }
              }
          }
  
          const entry: any = {
              'Provider ID': providerId,
              'Provider Name': providerName,
              'Scheme ID': item.parent_item_id || '',
              'Scheme Name': '', // Not available in file
              'Plan ID': item.id,
              'Plan Name': item.descriptor.name,
              'ISIN': isinG,
              'Plan Type': item.tags[0]?.list[0]?.value || '',
              'Option': '', // Placeholder
              'IDCW Option': '', // Placeholder
              'Lockin (Days)': '', // Placeholder
              'Entry Load': '', // Placeholder
              'Exit Load': '', // Placeholder
              'bpp_id': bpp_id, // Placeholder
              'bpp_uri': bpp_uri, // Placeholder
          };
  
          let sipCount = 1;
          for (const fid of item.fulfillment_ids || []) {
              const ftype = fulfillmentMap[fid];
              if (ftype === 'LUMPSUM') {
                  entry['Lumpsum Fulfillment ID'] = fid;
              } else if (ftype === 'SIP') {
                  entry[`SIP Fulfillment ID (${sipCount})`] = fid;
                  sipCount++;
              } else if (ftype === 'REDEMPTION') {
                  entry['Redemption Fulfillment ID'] = fid;
              }
          }
  
          return entry;
      });
  
      // Save to JSON
      const outputPath = path.join(__dirname, 'mf_structured_data.json');
      fs.writeFileSync(outputPath, JSON.stringify(structuredOutput, null, 2));
      console.log(`Structured data saved to ${outputPath}`);
  }
  
  */

}
