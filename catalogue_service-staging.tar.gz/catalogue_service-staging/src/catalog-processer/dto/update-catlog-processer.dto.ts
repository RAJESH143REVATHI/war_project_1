
import { CreateCatlogProcesserDto } from './create-catlog-processer.dto';

export class UpdateCatlogProcesserDto  {}
