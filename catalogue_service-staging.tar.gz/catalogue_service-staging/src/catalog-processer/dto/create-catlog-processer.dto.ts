export class CreateCatlogProcesserDto {}
