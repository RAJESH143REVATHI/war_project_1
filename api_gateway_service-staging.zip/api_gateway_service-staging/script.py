# script.py
import sys
import json

def main():
    input_data = json.loads(sys.argv[1])
    name = input_data.get("name", "Guest")
    print(json.dumps({"message": f"Hello {name} from Python!"}))

if __name__ == "__main__":
    main()
