import { Module } from '@nestjs/common';
import { UserService } from './user-service.service';
import { UserServiceController } from './user-service.controller';
import { RmqService } from 'src/shared/rmq.service';
import { RmqWrapperService } from 'src/shared/rmq-wrapper.service';

@Module({
  providers: [UserService,RmqService,RmqWrapperService],
  controllers: [UserServiceController],
  exports: [UserService]
})
export class UserServiceModule {}
