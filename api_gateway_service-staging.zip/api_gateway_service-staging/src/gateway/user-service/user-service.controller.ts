import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Post,
  Query,
  Req,
  UseGuards,
} from '@nestjs/common';
import { UserService } from './user-service.service';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { CreateSipDto } from '../sip/dto/create-sip.dto';
import { CancelSIPDto } from '../sip/dto/cancel-sip.dto';
import { PaymentStatusDto } from '../transaction/dto/payment-status.dto';
import { RedeemDto } from '../transaction/dto/redeem.dto';
import { CreateUserDto } from './dto/user.dto';
import { MessagePatternStr } from './userservice-message-pattern';
import { AofDto } from './dto/aof.dto';
import { JwtAuthGuard } from '../strategy/auth.guard';
// import { DtoFirstErrorFilter } from './exception.interceptor';

@ApiTags('User-Service')
@Controller('user')
export class UserServiceController {
  constructor(private readonly userService: UserService) {}

  @Get('ping')
  pingUserService() {
    console.log('======= Ping to User service ===========');
    return this.userService.sendMessage('ping_user', {});
  }

  @Post('createUser')
  @ApiOperation({ summary: 'Create a user' })
  @ApiResponse({ status: 200, description: 'Successfully created user' })
  @ApiBody({ type: CreateUserDto })
  createUser(@Body() body: CreateUserDto) {
    let data = {
      tenantId: '4da743f7-57a5-41b2-bc51-b8c1f7bf38d8',
      data: body,
    };
    console.log('🚀 ~ UserServiceController ~ createUser ~ data:', data);
    return this.userService.sendMessage('create_user', data);
  }

  //user AOF
  @Post("aof")
  // @UseFilters(DtoFirstErrorFilter)
  @ApiOperation({ summary: 'AOF operation ' })
  @ApiResponse({ status: 200, description: 'Successfully created AOF' })
  @ApiBody({type : AofDto})
  createAof(@Body() body:AofDto){
    let data = {
      tenantId: '4da743f7-57a5-41b2-bc51-b8c1f7bf38d8',
      data: body
    }
    console.log("aof hit in amirs backend");
    
    return this.userService.sendMessage('create_aof',data)
  }

  @Get('overallPortfolio')
  @ApiOperation({ summary: "Show user's overall portfolio" })
  @ApiResponse({
    status: 200,
    description: 'Successfully fetched overall portfolio',
  })
  showOverallPortfolio(@Query() query: Record<string, any>) {
    return this.userService.showOverallPortfolio(query);
  }

  @Get('userHoldingDetail')
  @ApiOperation({ summary: 'Fetch user holding details' })
  @ApiResponse({
    status: 200,
    description: 'Successfully fetched user holding details',
  })
  userHoldingDetail(@Query() query: Record<string, any>) {
    return this.userService.userHoldingDetail(query);
  }

  @Get('sipList')
  @ApiOperation({ summary: 'Fetch list of SIPs for a user' })
  @ApiResponse({ status: 200, description: 'Successfully fetched SIP list' })
  @ApiBody({ type: CreateSipDto })
  fetchSipList(@Query() query: Record<string, any>) {
    return this.userService.fetchSipList(query);
  }

  @Post('cancelSIP')
  @ApiOperation({ summary: 'Cancel an active SIP' })
  @ApiResponse({ status: 200, description: 'SIP cancelled successfully' })
  cancelSIP(@Body() cancelSIPdto: CancelSIPDto) {
    return this.userService.cancelSIP(cancelSIPdto);
  }

  @Get('listBank')
  @ApiOperation({ summary: 'Fetch list of banks for a user' })
  @ApiResponse({ status: 200, description: 'Successfully fetched bank list' })
  fetchBanks(@Query() query: Record<string, any>) {
    return this.userService.fetchBanks(query);
  }

  @Get('transactionList')
  @ApiOperation({ summary: 'Get list of user transactions' })
  @ApiResponse({
    status: 200,
    description: 'Successfully fetched transaction list',
  })
  transactionList(@Query() query: Record<string, any>) {
    return this.userService.transactionList(query);
  }

  @Post('redeemFund')
  @ApiOperation({ summary: 'Redeem fund for a user' })
  @ApiResponse({ status: 200, description: 'Fund redeemed successfully' })
  @ApiBody({ type: RedeemDto })
  redeemFund(@Body() redeemDto: RedeemDto) {
    return this.userService.redeemFund(redeemDto);
  }

  @Post('paymentStatus')
  @ApiOperation({ summary: 'Check payment status' })
  @ApiResponse({
    status: 200,
    description: 'Successfully checked payment status',
  })
  @ApiBody({ type: PaymentStatusDto })
  paymentStatus(@Body() paymentStatusDto: PaymentStatusDto) {
    return this.userService.paymentStatus(paymentStatusDto);
  }

  @Post('userPanVerification')
  verifyPan(@Body() body) {
    const pan = body.pan?.toUpperCase().trim();
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
    if (!panRegex.test(pan)) {
      throw new BadRequestException('Invalid PAN number format');
    }
    const data = {
      tenantId: '4da743f7-57a5-41b2-bc51-b8c1f7bf38d8',
      data: body.pan,
    };    
    return this.userService.sendMessage(MessagePatternStr.VERIFY_PAN, data);
  }

  @Post('createOtp')
  createOtp(@Body() body:{mobile:number}) {             
    return this.userService.sendMessage(MessagePatternStr.CREATE_OTP, body.mobile);
  }

  @Post('verifyOtp')
  async verifyOtp(@Body() body: { mobile: number; otp: string }) {   
    return this.userService.sendMessage(MessagePatternStr.VERIFY_OTP, body);
  }

  @Post('verifybank')
  async verifyBank(@Body() body: { id_number: number; ifsc: string; ifsc_details: boolean }) {   
    return this.userService.sendMessage(MessagePatternStr.VERIFY_BANK, body);
  }

  // @UseGuards()
  @Get('getbanklist')
  async getBankList(@Req() req:any,@Query('user_id') user_id: string){
   const payload ={
      tenant_id:req.user.tenant_id,
      user_id:user_id
    }
    console.log("req ,",req.user, user_id);
    
    return this.userService.sendMessage('get_bank_list',payload)
  }
}
