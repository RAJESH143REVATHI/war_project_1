import { Module } from '@nestjs/common';
import { OndcService } from './ondc_service.service';
import { OndcServiceController } from './ondc_service.controller';
import { RmqService } from 'src/shared/rmq.service';
import { ConfigService } from '@nestjs/config';

@Module({
  providers: [OndcService,RmqService,ConfigService],
  controllers: [OndcServiceController]
})
export class OndcServiceModule {}
