export class CreateMutualFundDto {}
