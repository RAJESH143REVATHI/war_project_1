import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
} from '@nestjs/common';
import { MutualFundsService } from './mutual-funds.service';
import { CreateMutualFundDto } from './dto/create-mutual-fund.dto';
import { UpdateMutualFundDto } from './dto/update-mutual-fund.dto';
import { MutualFundDetails } from './dto/mutual-fund-detail.dto';
import { CartList } from './dto/cart-list.dto';
import { ApiTags, ApiOperation, ApiResponse, ApiBody } from '@nestjs/swagger';

@ApiTags('Mutual Fund')
@Controller('mutualFunds')
export class MutualFundsController {
  constructor(private readonly mutualFundsService: MutualFundsService) {}

  @Get('getMutualFundList')
  findAll(@Query() query: Record<string, any>) {
    return this.mutualFundsService.getMutualFundList(query);
  }

  @Get('detail')
  @ApiOperation({ summary: 'Fetch mutual fund details' })
  @ApiResponse({
    status: 200,
    description: 'Successfully fetched mutual fund details',
  })
  fetchMFDetail(@Query() query: Record<string, any>) {
    return this.mutualFundsService.fetchMFDetail(query);
  }
}
