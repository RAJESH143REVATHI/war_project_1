import { Injectable } from '@nestjs/common';
import { CreateMutualFundDto } from './dto/create-mutual-fund.dto';
import { UpdateMutualFundDto } from './dto/update-mutual-fund.dto';
import { CartList } from './dto/cart-list.dto';
import { InjectModel } from '@nestjs/mongoose';
import { Fund, FundDocument } from 'src/schemas/fund.schema';
import { Model } from 'mongoose';
import { AmcCollection, AmcCollectionDocument } from 'src/schemas/amc-collection.schema';

@Injectable()
export class MutualFundsService {

  constructor(
    @InjectModel(Fund.name) private fundModel: Model<FundDocument>,
    @InjectModel(AmcCollection.name) private amcCollectionDocument: Model<AmcCollectionDocument>,
  ) { }


  async getMutualFundList(query: any) {
    console.log(query);
    return {
      // amcCollectionModel: await this.amcCollectionModel.find(query).exec(),
      fundModel: await this.fundModel.find(query).exec(),
    }
  }

  fetchMFDetail(createMutualFundDto: CreateMutualFundDto) {
    return 'This action fetches mutual fund details';
  }

  mutualFundList(query: any) {
    return 'This action retrieves the mutual fund list';
  }

  addToCart(createMutualFundDto: CreateMutualFundDto) {
    return 'This action adds a mutual fund to the cart';
  }

  cartList(cartListDto: CartList) {
    return 'This action retrieves the cart list';
  }

  deleteCart(createMutualFundDto: CreateMutualFundDto) {
    return 'This action removes a mutual fund from the cart';
  }

  findAll() {
    return `This action returns all mutualFunds`;
  }

  findOne(id: number) {
    return `This action returns a #${id} mutualFund`;
  }

  update(id: number, updateMutualFundDto: UpdateMutualFundDto) {
    return `This action updates a #${id} mutualFund`;
  }

  remove(id: number) {
    return `This action removes a #${id} mutualFund`;
  }
}
