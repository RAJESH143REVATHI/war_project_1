import { Module } from '@nestjs/common';
import { MutualFundsService } from './mutual-funds.service';
import { MutualFundsController } from './mutual-funds.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { AmcCollection, AmcCollectionSchema } from 'src/schemas/amc-collection.schema';
import { Fund, FundSchema } from 'src/schemas/fund.schema';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Fund.name, schema: FundSchema },
      { name: AmcCollection.name, schema: AmcCollectionSchema },
    ]),],
  controllers: [MutualFundsController],
  providers: [MutualFundsService],
})
export class MutualFundsModule { }
