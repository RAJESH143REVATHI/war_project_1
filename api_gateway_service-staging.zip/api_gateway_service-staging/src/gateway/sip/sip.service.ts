import { Injectable } from '@nestjs/common';
import { CreateSipDto } from './dto/create-sip.dto';
import { UpdateSipDto } from './dto/update-sip.dto';

@Injectable()
export class SipService {
  fetchSipList(createSipDto: CreateSipDto) {
    return 'This action adds a new sip';
  }

  cancelSIP(createSipDto: CreateSipDto) {
    return `This action returns all sip`;
  }

  findOne(id: number) {
    return `This action returns a #${id} sip`;
  }

  update(id: number, updateSipDto: UpdateSipDto) {
    return `This action updates a #${id} sip`;
  }

  remove(id: number) {
    return `This action removes a #${id} sip`;
  }
}

//
//
