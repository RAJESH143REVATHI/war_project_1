import { Test, TestingModule } from '@nestjs/testing';
import { SipController } from './sip.controller';
import { SipService } from './sip.service';

describe('SipController', () => {
  let controller: SipController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [SipController],
      providers: [SipService],
    }).compile();

    controller = module.get<SipController>(SipController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
