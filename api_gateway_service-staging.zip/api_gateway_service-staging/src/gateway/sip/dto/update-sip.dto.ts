import { PartialType } from '@nestjs/swagger';
import { CreateSipDto } from './create-sip.dto';

export class UpdateSipDto extends PartialType(CreateSipDto) {}
