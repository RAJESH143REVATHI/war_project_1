import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
} from '@nestjs/common';
import { SipService } from './sip.service';
import { CreateSipDto } from './dto/create-sip.dto';
import { UpdateSipDto } from './dto/update-sip.dto';
import { ApiTags, ApiOperation, ApiResponse, ApiBody } from '@nestjs/swagger';
import { CancelSIPDto } from './dto/cancel-sip.dto';

@ApiTags('SIP')
@Controller('sip')
export class SipController {
  constructor(private readonly sipService: SipService) {}

  @Get('sipList')
  @ApiOperation({ summary: 'Fetch list of SIPs for a user' })
  @ApiResponse({ status: 200, description: 'Successfully fetched SIP list' })
  @ApiBody({ type: CreateSipDto })
  fetchSipList(@Query() query: Record<string, any>) {
    return this.sipService.fetchSipList(query);
  }

  @Post('cancelSIP')
  @ApiOperation({ summary: 'Cancel an active SIP' })
  @ApiResponse({ status: 200, description: 'SIP cancelled successfully' })
  cancelSIP(@Body() cancelSIPdto: CancelSIPDto) {
    return this.sipService.cancelSIP(cancelSIPdto);
  }
}
