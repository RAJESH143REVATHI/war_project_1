import { Injectable } from '@nestjs/common';
import { CreateDashboardDto } from './dto/create-dashboard.dto';
import { UpdateDashboardDto } from './dto/update-dashboard.dto';
import { InjectModel } from '@nestjs/mongoose';
import { AmcCollection, AmcCollectionDocument } from 'src/schemas/amc-collection.schema';
import { Model } from 'mongoose';
import { Fund, FundDocument } from 'src/schemas/fund.schema';

@Injectable()
export class DashboardService {

  constructor(
    @InjectModel(Fund.name) private fundModel: Model<FundDocument>,
    @InjectModel(AmcCollection.name) private amcCollectionDocument: Model<AmcCollectionDocument>,
  ) { }

  

  async getCollection() {
    return {
      // amcCollectionModel: await this.amcCollectionModel.find(query).exec(),
      fundModel: await this.amcCollectionDocument.find().exec(),
    }
  }

  fetchPopularFund(createDashboardDto: CreateDashboardDto) {
    return 'This action fetches funds';
  }
  addToWatchlist(createDashboardDto: CreateDashboardDto) {
    return 'This action adds to watchlist';
  }
  removeFromWatchlist(createDashboardDto: CreateDashboardDto) {
    return 'This action removes from watchlist';
  }

  fetchWatchlist() {
    return 'This action fetches watchlist';
  }

  findAll() {
    return `This action returns all dashboard`;
  }

  findOne(id: number) {
    return `This action returns a #${id} dashboard`;
  }

  update(id: number, updateDashboardDto: UpdateDashboardDto) {
    return `This action updates a #${id} dashboard`;
  }

  remove(id: number) {
    return `This action removes a #${id} dashboard`;
  }


}
