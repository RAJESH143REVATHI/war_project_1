export class Dashboard {}
