export class CreateDashboardDto {}
