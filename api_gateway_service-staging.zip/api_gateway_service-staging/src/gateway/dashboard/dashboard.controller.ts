import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
} from '@nestjs/common';
import { DashboardService } from './dashboard.service';
import { CreateDashboardDto } from './dto/create-dashboard.dto';
import { UpdateDashboardDto } from './dto/update-dashboard.dto';
import { ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';
import { FetchCollectionList } from './dto/collection-list.dto';
import { PopularFund } from './dto/popular-fund.dto';
import { WatchList } from './dto/watchlist.dto';

@ApiTags('Dashboard')
@Controller('dashboard')
export class DashboardController {
  constructor(private readonly dashboardService: DashboardService) {}

  

  @Get('collectionList')
  @ApiOperation({ summary: 'fetch Collection List' })
  @ApiResponse({ status: 200, description: 'List fetched successfully' })
  fetchCollectionList() {
    return this.dashboardService.getCollection();
  }

  @Post('popularFund')
  @ApiOperation({
    summary: 'Fetch popular fund list based on user preferences',
  })
  @ApiResponse({
    status: 200,
    description: 'Popular fund list fetched successfully',
  })
  @ApiResponse({ status: 400, description: 'Invalid input data' })
  fetchPopularFund(@Query() query: Record<string, any>) {
    return this.dashboardService.fetchPopularFund(query);
  }

  @Post('addToWatchlist')
  @ApiOperation({ summary: 'Add fund to user watchlist' })
  @ApiResponse({
    status: 200,
    description: 'Fund added to watchlist successfully',
  })
  @ApiResponse({ status: 400, description: 'Invalid input data' })
  addToWatchlist(@Body() watchListDto: WatchList) {
    return this.dashboardService.addToWatchlist(watchListDto);
  }
  @Post('removeFromWatchlist')
  @ApiOperation({ summary: 'Remove fund from user watchlist' })
  @ApiResponse({
    status: 200,
    description: 'Fund removed from watchlist successfully',
  })
  @ApiResponse({ status: 400, description: 'Invalid input data' })
  removeFromWatchlist(@Body() watchListDto: WatchList) {
    return this.dashboardService.removeFromWatchlist(watchListDto);
  }
  @Get('getWatchlist')
  @ApiOperation({ summary: 'Get user watchlist' })
  @ApiResponse({ status: 200, description: 'Watchlist fetched successfully' })
  @ApiResponse({ status: 400, description: 'Invalid input data' })
  fetchWatchlist() {
    return this.dashboardService.fetchWatchlist();
  }
}
