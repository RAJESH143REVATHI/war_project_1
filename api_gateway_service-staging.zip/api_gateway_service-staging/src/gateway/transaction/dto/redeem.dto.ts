import { IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class RedeemDto {
  @ApiProperty({ description: 'SchemeId ' })
  @IsOptional()
  @IsString()
  schemeId: string;

  @ApiProperty({ description: 'Holding Id ' })
  @IsOptional()
  @IsString()
  holdingId: string;

  @ApiProperty({ description: 'Unit ' })
  @IsOptional()
  @IsString()
  unit: string;

  @ApiProperty({ description: 'Amount  ' })
  @IsOptional()
  @IsString()
  amount: string;
}
