import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  Query,
} from '@nestjs/common';
import { TransactionService } from './transaction.service';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';
import { UserDto } from 'src/auth/dto/user.dto';
import { RedeemDto } from './dto/redeem.dto';
import { PaymentStatusDto } from './dto/payment-status.dto';
import { ApiBody, ApiOperation, ApiResponse, ApiTags } from '@nestjs/swagger';

@ApiTags('Transaction')
@Controller('transaction')
export class TransactionController {
  constructor(private readonly transactionService: TransactionService) {}

  @Get('listBank')
  @ApiOperation({ summary: 'Fetch list of banks for a user' })
  @ApiResponse({ status: 200, description: 'Successfully fetched bank list' })
  fetchBanks(@Query() query: Record<string, any>) {
    return this.transactionService.fetchBanks(query);
  }



  @Get('transactionList')
  @ApiOperation({ summary: 'Get list of user transactions' })
  @ApiResponse({
    status: 200,
    description: 'Successfully fetched transaction list',
  })
  transactionList(@Query() query: Record<string, any>) {
    return this.transactionService.transactionList(query);
  }

  @Post('redeemFund')
  @ApiOperation({ summary: 'Redeem fund for a user' })
  @ApiResponse({ status: 200, description: 'Fund redeemed successfully' })
  @ApiBody({ type: RedeemDto })
  redeemFund(@Body() redeemDto: RedeemDto) {
    return this.transactionService.redeemFund(redeemDto);
  }

  @Post('paymentStatus')
  @ApiOperation({ summary: 'Check payment status' })
  @ApiResponse({
    status: 200,
    description: 'Successfully checked payment status',
  })
  @ApiBody({ type: PaymentStatusDto })
  paymentStatus(@Body() paymentStatusDto: PaymentStatusDto) {
    return this.transactionService.paymentStatus(paymentStatusDto);
  }
}
