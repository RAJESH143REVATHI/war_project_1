import { Injectable } from '@nestjs/common';
import { CreateTransactionDto } from './dto/create-transaction.dto';
import { UpdateTransactionDto } from './dto/update-transaction.dto';

@Injectable()
export class TransactionService {
  fetchBanks(createTransactionDto: CreateTransactionDto) {
    return 'This action fetches the list of available banks';
  }

  showOverallPortfolio(createTransactionDto: CreateTransactionDto) {
    return 'This action displays the overall user portfolio';
  }

  userHoldingDetail(createTransactionDto: CreateTransactionDto) {
    return "This action fetches the user's holding details";
  }

  redeemFund(createTransactionDto: CreateTransactionDto) {
    return 'This action initiates fund redemption';
  }

  transactionList(createTransactionDto: CreateTransactionDto) {
    return 'This action fetches the transaction list';
  }

  paymentStatus(createTransactionDto: CreateTransactionDto) {
    return 'This action checks the payment status of a transaction';
  }

  findAll() {
    return `This action returns all transaction`;
  }

  findOne(id: number) {
    return `This action returns a #${id} transaction`;
  }

  update(id: number, updateTransactionDto: UpdateTransactionDto) {
    return `This action updates a #${id} transaction`;
  }

  remove(id: number) {
    return `This action removes a #${id} transaction`;
  }
}
