import { Type } from 'class-transformer';
import { ArrayMinSize, ArrayNotEmpty, IsArray, IsInt, IsNotEmpty, IsOptional, IsString, Matches, Min } from 'class-validator';

export class GetNavs {
  
  @IsString({ message: ' isin must be a string' })
  @IsNotEmpty({message: ' isin must not be empty' })
  isin: string;

  
  @Matches(/^\d{4}-\d{2}-\d{2}$/, {
    message: 'startDate must be in the format yyyy-mm-dd',
  })
  @IsString({ message: 'start date must be a string' })
  @IsNotEmpty({message:"start date must not empty"})
  startDate:string

  
  @Matches(/^\d{4}-\d{2}-\d{2}$/, {
    message: 'startDate must be in the format yyyy-mm-dd',
  })
  @IsString({ message: 'end date must be a string' })
  @IsNotEmpty({message:"end date must not empty"})
  endDate:string

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number;
}
