import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { CatalogService } from './catalog.service';
import { ApiOperation, ApiResponse } from '@nestjs/swagger';
import { WatchList } from '../dashboard/dto/watchlist.dto';
import {
  MessagePatternStr
} from './catalog-message-pattern';
import { Public } from 'src/decorators/public.decorator';
import { lastValueFrom } from 'rxjs';
import { GetNavs } from './dto/getNav.dto';

@Controller('catalog')
export class CatalogController {
  constructor(private readonly catalogService: CatalogService) { }

  @Get('collectionList')
  @ApiOperation({ summary: 'fetch Collection List' })
  @ApiResponse({ status: 200, description: 'List fetched successfully' })
  fetchCollectionList() {
    return this.catalogService.getCollection();
  }

  @ApiResponse({
    status: 200,
    description: 'Popular fund list fetched successfully',
  })
  @ApiResponse({ status: 400, description: 'Invalid input data' })
  fetchPopularFund(@Query() query: Record<string, any>) {
    return this.catalogService.fetchPopularFund(query);
  }

  @Post('addToWatchlist')
  @ApiOperation({ summary: 'Add fund to user watchlist' })
  @ApiResponse({
    status: 200,
    description: 'Fund added to watchlist successfully',
  })
  @ApiResponse({ status: 400, description: 'Invalid input data' })
  addToWatchlist(@Body() watchListDto: WatchList) {
    return this.catalogService.addToWatchlist(watchListDto);
  }
  @Post('removeFromWatchlist')
  @ApiOperation({ summary: 'Remove fund from user watchlist' })
  @ApiResponse({
    status: 200,
    description: 'Fund removed from watchlist successfully',
  })
  @ApiResponse({ status: 400, description: 'Invalid input data' })
  removeFromWatchlist(@Body() watchListDto: WatchList) {
    return this.catalogService.removeFromWatchlist(watchListDto);
  }
  @Get('getWatchlist')
  @ApiOperation({ summary: 'Get user watchlist' })
  @ApiResponse({ status: 200, description: 'Watchlist fetched successfully' })
  @ApiResponse({ status: 400, description: 'Invalid input data' })
  fetchWatchlist() {
    return this.catalogService.fetchWatchlist();
  }

  // @Get('getMutualFundList')
  // findAll(@Query() query: Record<string, any>) {
  //   return this.catalogService.getMutualFundList('patternGetMutualFundList',query);
  // }

  @Get('detail')
  @ApiOperation({ summary: 'Fetch mutual fund details' })
  @ApiResponse({
    status: 200,
    description: 'Successfully fetched mutual fund details',
  })
  fetchMFDetail(@Query() query: Record<string, any>) {
    return this.catalogService.fetchMFDetail(query);
  }

  @Get('ping')
  async pingCalalogService() {
    // for (let index = 0; index < 60000; index++) {
    //   lastValueFrom(
    //     await this.catalogService.sendMessage(
    //       MessagePatternStr.PING_CATALOG,
    //       {},
    //     ),
    //   );
    //   //await new Promise(f => setTimeout(f, 100));
    //   console.log(`Gateway -: ${index}`);
    // }

    // return 'done';
    return this.catalogService.sendMessage(MessagePatternStr.PING_CATALOG, {});
  }

  @Post('createCatogery')
  async createCatogery(@Body() body: string[]) {
    return this.catalogService.sendMessage('create_catogery', body);
  }

  @Get('getOndcFundData')
  async getOndcFundData(@Query() queryParams: any) {
    console.log('in ondcFund data data')
    return this.catalogService.sendMessage(
      MessagePatternStr.GET_ONDCFUNDDATA,
      queryParams,
    );
  }

  @Get('getTopCollection')
  async getTopCollection(@Query() queryParams: any) {
    console.log('in topCollection')
    return this.catalogService.sendMessage(
      MessagePatternStr.GET_TOPCOLLECTION,
      queryParams,
    );
  }

  @Get('getRiskList')
  async getRiskList(@Query() queryParams: any) {
    console.log('in topCollection')
    return this.catalogService.sendMessage(
      MessagePatternStr.GET_RISKLIST,
      queryParams,
    );
  }

  @Get('getSortList')
  async getSortList(@Query() queryParams: any) {
    console.log('in topCollection')
    return this.catalogService.sendMessage(
      MessagePatternStr.GET_SORTLIST,
      queryParams,
    );
  }

  @Get('getAmcList')
  async getAMCList(@Query() queryParams: any) {
    console.log('in topCollections')
    return this.catalogService.sendMessage(
      MessagePatternStr.GET_AMCLIST,
      queryParams,
    );
  }

  @Get('getPopularFunds')
  async getPopularFunds(@Query() queryParams: any) {
    console.log('in topCollection')
    return this.catalogService.sendMessage(
      MessagePatternStr.GET_POPULARFUND,
      queryParams,
    );
  }


  @Post('createSubcatogery')
  async createSubcatogery(@Body() body: string[]) {
    return this.catalogService.sendMessage('create_sub_catogery', body);
  }

  @Get('getMutualFundList')
  findAll(@Query() query: Record<string, any>) {
    return this.catalogService.sendMessage(MessagePatternStr.GET_CATALOG, query)
  }

  @Get('getAllCatogery')
  async getAllCatogery() {
    return this.catalogService.sendMessage(MessagePatternStr.GET_CATOGERY, {});
  }

  @Get('getHoldingData')
  async getHoldingData(@Query() queryParams: any) {
    console.log('in holdingdata')
    return this.catalogService.sendMessage(
      MessagePatternStr.GET_HOLDINGDATA,
      queryParams,
    );
  }

  @Post('addNavsBulk')
  async addNavsBulk(@Body() data?:string[]){
    return this.catalogService.sendMessage(
      'addNavs_bulk',
      data
    );
    
  } 

  @Post("navsByIsinAndDateRange")
  async findNavsByIsinAndDateRange(@Body() data:GetNavs){
     return this.catalogService.sendMessage(
      'navs_isin_daterange',
      data
    );
  }


  // @Get('get_catalog')
  // async getCatalog(@Query() queryParams: any) {
  //   return this.catalogService.sendMessage(
  //     MessagePatternStr.GET_CATALOG,
  //     queryParams,
  //   );
  // }
}
