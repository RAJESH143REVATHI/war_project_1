import { Module } from '@nestjs/common';
import { GatewayController } from './gateway.controller';
import { GatewayService } from './gateway.service';
import { CatalogModule } from './catalog/catalog.module';
import { UserServiceModule } from './user-service/user-service.module';
import { CartModule } from './cart-service/cart.module';
import { OndcServiceModule } from './ondc_service/ondc_service.module';

@Module({
  imports:[CatalogModule, UserServiceModule,CartModule, OndcServiceModule],
  controllers: [GatewayController],
  providers: [GatewayService]
})
export class GatewayModule {}
