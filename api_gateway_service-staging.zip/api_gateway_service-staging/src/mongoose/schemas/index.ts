import { Amc, AmcSchema } from "./amc-collection.schema";
import { Category, CategoryCollectionSchema } from "./catogery.schema";
import { SubCategory, SubCategorySchema } from "./sub-catogery.schema";
import { Fund, FundSchema } from "./fund.schema";
import { OndcFundPlan, OndcFundPlanSchema } from "./ondc-fund-plan.schema";
import { MorningStarFund, MorningStarFundSchema } from "./msFunds.schema";
import { TopCollection, TopCollectionSchema } from "./top-collection.schema";
import { FundHolding, FundHoldingSchema } from "./fund-holdings.schema";

export const Schemas = [
    {name: Amc.name, schema: AmcSchema},
    {name: Category.name, schema: CategoryCollectionSchema},
    {name: SubCategory.name, schema: SubCategorySchema},
    {name: Fund.name, schema: FundSchema},
    {name: OndcFundPlan.name, schema: OndcFundPlanSchema},
    {name: MorningStarFund.name, schema: MorningStarFundSchema},
    {name: TopCollection.name, schema: TopCollectionSchema},
    {name: FundHolding.name, schema: FundHoldingSchema},
];