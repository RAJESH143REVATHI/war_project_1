import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';

export type CategoryCollectionDocument = Category & Document;

@Schema({ timestamps: false, versionKey: false })
export class Category {
    @Prop({ required: true })
    CategoryName: string;
}

export const CategoryCollectionSchema = SchemaFactory.createForClass(Category);
