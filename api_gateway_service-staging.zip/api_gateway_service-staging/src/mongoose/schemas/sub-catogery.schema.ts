import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';

export type SubCategoryDocument = SubCategory & Document;

@Schema({ timestamps: false, versionKey: false })
export class SubCategory {
  @Prop({ required: true })
  srNo: string;

  @Prop({ required: true, index: true })  // Index added here
  morningstarCatId: string;

  @Prop({ required: true })
  sebiCategoryMame: string;

  @Prop({ required: true })
  name: string;

  @Prop({
    type: MongooseSchema.Types.ObjectId,
    ref: 'CategoryCollection',
    required: true,
    index: true,  // Index added here
  })
  Category_id: MongooseSchema.Types.ObjectId;
}

export const SubCategorySchema = SchemaFactory.createForClass(SubCategory);
