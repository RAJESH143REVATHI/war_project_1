import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';

export type FundDocument = Fund & Document;

@Schema({ timestamps: true })
export class Fund {
  @Prop() _idtype: string;
  @Prop() _id: string;
  @Prop() isin: string;
  @Prop() rtaCode: string;
  @Prop() amfiCode: string;
  @Prop() fundId: string;
  @Prop() fundName: string;
  @Prop() legalName: string;
  @Prop() providerCompanyId: string;
  @Prop() providerCompanyName: string;
  @Prop() advisoryCompanyName: string;
  @Prop() providerPhone: string;
  @Prop() providerWebsite: string;
  @Prop() fundLevelCategory: string;
  @Prop() broadCategoryGroup: string;
  @Prop() riskLevel: string;
  @Prop() sipAvailability: boolean;
  @Prop() initialLockupPeriod: number;
  @Prop() isIndexFund: boolean;
  @Prop() isMasterFeeder: boolean;
  @Prop() maxDeferLoad: number;
  @Prop() maxManagementFee: number;
  @Prop() actualManagementFee: number;
  @Prop() netExpenseRatio: number;
  @Prop() grossExpenseRatio: number;
  @Prop() portfolioDate: string;
  @Prop() originalReportedValue: number;
  @Prop() originalReportedDate: string;

  @Prop({
    type: [
      {
        managerId: String,
        name: String,
        role: String,
        startDate: String,
        tenure: Number,
      },
    ],
    default: [],
    _id: false
  })
  fundManagers: any[];

  @Prop({
    type: [
      {
        morningstarId: String,
        holdingType: String,
        name: String,
        countryId: String,
        country: String,
        currencyId: String,
        currency: String,
        isin: String,
        weighting: Number,
        numOfShares: Number,
        marketValue: Number,
        shareChange: Number,
        sectorId: String,
        sector: String,
        globalSectorId: String,
        globalSector: String,
        ticker: String,
        holdingYtdReturn: Number,
      },
    ],
    default: [],
    _id: false
  })
  holdingDetails: any[];

  @Prop({
    type: {
      minAmount: Number,
      unit: String,
    },
  })
  redemptionDetails: any;

  @Prop({
    type: [
      {
        frequency: String,
        frequencyDate: String,
        siType: String,
        minAmount: Number,
        subsequentAmount: Number,
      },
    ],
    default: [],
    _id: false
  })
  systematicInvestmentOptions: any[];

  @Prop({
    type: {
      amount: Number,
      unit: String,
      indicator: Boolean,
    },
  })
  systematicWithdrawal: any;

  @Prop({
    type: {
      _id: String,
      returns: {
        '1Y': String,
        '3Y': String,
        '5Y': String,
      },
      benchmark: String,
    },
  })
  performance: any;
}

export const FundSchema = SchemaFactory.createForClass(Fund);
