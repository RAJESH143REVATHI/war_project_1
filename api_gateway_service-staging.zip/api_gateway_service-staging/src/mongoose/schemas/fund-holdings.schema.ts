import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type FundHoldingDocument = FundHolding & Document;

@Schema({ _id: false })
class HoldingDetail {
  @Prop() MorningstarID: string;
  @Prop() HoldingType: string;
  @Prop() Name: string;
  @Prop() Weighting: string;
}

@Schema({ timestamps: true })
export class FundHolding extends Document {
  @Prop({ required: true, unique: true })
  isin: string;

  @Prop({ type: [HoldingDetail], default: [] })
  holdingDetail: HoldingDetail[];
}

export const FundHoldingSchema = SchemaFactory.createForClass(FundHolding);
