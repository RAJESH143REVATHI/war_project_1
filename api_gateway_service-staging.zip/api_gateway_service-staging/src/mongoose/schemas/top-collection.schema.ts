import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type TopCollectionDocument = TopCollection & Document;

@Schema({ timestamps: true })
export class TopCollection {
    @Prop({ required: true })
    name: string;

    @Prop({ required: true })
    value: string;

    @Prop()
    image: string;
}

export const TopCollectionSchema = SchemaFactory.createForClass(TopCollection);
