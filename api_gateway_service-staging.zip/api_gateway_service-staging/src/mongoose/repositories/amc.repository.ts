import { Injectable } from "@nestjs/common";
import { BaseRepository } from "./base.repository";
import { Category } from "../schemas/catogery.schema";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { Amc } from "../schemas/amc-collection.schema";

@Injectable()
export class AmcRepository extends BaseRepository<Amc> {
    constructor(@InjectModel(Amc.name) private readonly amcModel: Model<Amc>) {
        super(amcModel);
    }

    /**
     * this class will have all the methods of @see {@link BaseRepository}
     * We can still add Category specific methods
     */
}