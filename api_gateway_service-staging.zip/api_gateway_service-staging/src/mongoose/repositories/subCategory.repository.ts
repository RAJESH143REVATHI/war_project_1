import { Injectable } from "@nestjs/common";
import { BaseRepository } from "./base.repository";
import { InjectModel } from "@nestjs/mongoose";
import { Model } from "mongoose";
import { SubCategory } from "../schemas/sub-catogery.schema";

@Injectable()
export class SubCategoryRepository extends BaseRepository<SubCategory> {
    constructor(@InjectModel(SubCategory.name) private readonly subCategoryModel: Model<SubCategory>) {
        super(subCategoryModel);
    }

    /**
     * this class will have all the methods of @see {@link BaseRepository}
     * We can still add Category specific methods
     */
}