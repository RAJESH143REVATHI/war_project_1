import { Module } from "@nestjs/common";
import { MongooseModule } from "@nestjs/mongoose";
import { Schemas } from "./schemas";
import { CategoryRepository } from "./repositories/category.repository";
import { SubCategoryRepository } from "./repositories/subCategory.repository";
import { AmcRepository } from "./repositories/amc.repository";

@Module({
    imports: [MongooseModule.forFeature(Schemas)],
    providers: [CategoryRepository,SubCategoryRepository,AmcRepository],
    exports: [MongooseModule,CategoryRepository,SubCategoryRepository,AmcRepository]
})
export class SharedMongooseModule {}