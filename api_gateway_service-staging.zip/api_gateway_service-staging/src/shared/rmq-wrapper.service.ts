// shared/rmq-wrapper.service.ts
import { HttpException, Injectable } from '@nestjs/common';
import { catchError, lastValueFrom, throwError } from 'rxjs';
import { ClientProxy } from '@nestjs/microservices';

@Injectable()
export class RmqWrapperService {
  constructor() {}

  async sendWithErrorHandling<T>(client: ClientProxy, pattern: string, data: any): Promise<T> {
    return await lastValueFrom(
      client.send<T>({cmd: pattern}, data).pipe(
        catchError((error) => {
            const parsed = JSON.parse(error?.message);
            throw new HttpException(parsed.message || 'Internal Error', parsed.statusCode || 500);
        }),
      ),
    );
  }
}
