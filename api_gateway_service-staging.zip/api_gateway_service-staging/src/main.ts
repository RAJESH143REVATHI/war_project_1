import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { MicroserviceOptions, Transport } from '@nestjs/microservices';
import { ConfigService } from '@nestjs/config';
import { ExpressAdapter } from '@nestjs/platform-express';
import * as express from 'express';
import { ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const server = express();
  const expressApp = new ExpressAdapter(server);

  const app = await NestFactory.create(AppModule, expressApp);

  const PORT = 3000;

  app.setGlobalPrefix('gateway');

  const config = new DocumentBuilder()
    .setTitle('ONDC API ')
    .setDescription('ONDC API Description')
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('apiDoc', app, document); // Serve Swagger UI at /api

  const configService = app.get(ConfigService);

  const microservice = app.connectMicroservice<MicroserviceOptions>({
    transport: Transport.RMQ,
    options: {
      urls: [configService.get<string>('rabbitmq.url')],
      queueOptions: {
        durable: true,
      },
    },
  });

  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
  // 🔥 Step 4: Start both apps
  await app.startAllMicroservices();


  await app.listen(PORT, () => {
    console.log('Gateway is running on port 3000');
  });
}
bootstrap();
