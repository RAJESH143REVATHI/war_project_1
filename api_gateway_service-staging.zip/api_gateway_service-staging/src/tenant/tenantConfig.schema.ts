import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { Type } from 'class-transformer';


export type TenantConfigDocument = TenantConfig & Document;

// Nested Schema for DB Credentials
@Schema({ _id: false })
export class DbCredentials {
  @Prop({ required: true })
  host: string;

  @Prop({ required: true })
  port: string;

  @Prop({ required: true })
  username: string;

  @Prop({ required: true })
  password: string;

  @Prop({ required: true })
  dbName: string;
}

// Nested Schema for Integrations
@Schema({ _id: false })
export class Integrations {
  @Prop()
  paymentGateway: string;

  @Prop()
  notificationService: string;
}


@Schema({ timestamps: true })
export class TenantConfig {
  @Prop({ required: true, unique: true })
  tenant_id: string;

  @Prop({ required: true })
  tenant_name: string;

  @Prop({required:true})
  tenant_pass_key: string

  @Prop({ type: Object, default: {} })
  layout: Record<string, any>;

  @Prop({ type: DbCredentials, required: true })
  @Type(() => DbCredentials)
  dbCredentials: DbCredentials;

  @Prop({ type: Object, default: {} })
  featureFlags: Record<string, boolean>;

  @Prop({ type: Integrations, default: {} })
  @Type(() => Integrations)
  integrations: Integrations;
}

export const TenantConfigSchema = SchemaFactory.createForClass(TenantConfig);
