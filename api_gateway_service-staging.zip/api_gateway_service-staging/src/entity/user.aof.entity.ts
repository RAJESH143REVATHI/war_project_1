// src/user/entities/user-aof.entity.ts
import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  OneToOne,
  JoinColumn,
  Unique,
} from 'typeorm';
import { UserEntity } from './user.entity';
import { CaNature, Citizenship, CountryCode, CpBelongsTo, Gender, IncomeRange, IndiaTaxResidencyStatus, MaritalStatus, ModeOfHolding, NomineeDisplayOption, NomineeIdType, Occupation, PoliticalExposure, SkipNomination, SourceOfWealth } from 'src/enums';

@Entity('user_aof_details')
@Unique(['pan'])
export class UserAofEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ nullable: false })
  user_id: string;

  @OneToOne(() => UserEntity, (user) => user.user_aof, {
    onDelete: 'CASCADE',
  })
  @JoinColumn({ name: 'user_id', referencedColumnName: 'id' })
  user: UserEntity;

  @Column({ length: 10 ,nullable:false})
  pan: string;

  @Column({
    nullable:false
  })
  dob: string;

  @Column({
    type: 'enum',
    enum: Gender,
    default:null,
  })
  gender: Gender;

  @Column({
    type: 'enum',
    enum: MaritalStatus,
    nullable: true,
  default: null,
  })
  marital_status?: MaritalStatus;

  @Column({ type: 'varchar', nullable: true, default: '' })
  father_name?: string;

  @Column({ type: 'varchar', nullable: true, default: '' })
  spouse_name?: string;

  @Column({ type: 'varchar', nullable: true, default: '' })
  mother_name?: string;

  @Column({ type: 'varchar', nullable: false })
  aadhaar_number: string;

  @Column({
    type: 'enum',
    enum: CountryCode,
    default: CountryCode.IN,
    nullable: false,
  })
  nationality: CountryCode;

   @Column({
    type: 'enum',
    enum: CountryCode,
    array: true,
    default: [CountryCode.IN],
    nullable: false,
  })
  citizenships: CountryCode[];


  @Column({ type: 'text', nullable: false })
  signature: string;

  @Column({ type: 'text', nullable: false })
  geo_latitude: string;

  @Column({ type: 'double precision', nullable: false })
  geo_longitudes: number;

 @Column({
    type: 'enum',
    enum: Occupation,
    nullable:false,
  })
  occupation: Occupation;

  @Column({
    type: 'enum',
    enum: SourceOfWealth,
    nullable: false
    
  })
  source_of_wealth: SourceOfWealth;

@Column({
    type: 'enum',
    enum: IncomeRange,
    nullable: false,
  })
  income_range: IncomeRange;

  @Column({
  type: 'enum',
  enum: CountryCode,
  nullable: false 
})
cob: CountryCode;

@Column({
  nullable:false
})
pob: string;

@Column({
  type: 'enum',
  enum: PoliticalExposure,
  nullable:false,
  default: PoliticalExposure.NO_EXPOSURE,
})
political_exposure: PoliticalExposure;


@Column({
  type: 'enum',
  enum: IndiaTaxResidencyStatus,
  nullable:false,
  default: IndiaTaxResidencyStatus.RESIDENT,
})
india_tax_residency_status: IndiaTaxResidencyStatus;

@Column({
  type:'enum',
  enum: CountryCode,
  nullable :true,
  default:null
})
trc_country_0:CountryCode;

@Column({
  nullable :true,
  default:null
})
trc_idtype_0:string;

@Column({
  nullable :true,
  default:null
})
trc_idnumber_0:string;

@Column({
  type:'enum',
  enum: CountryCode,
  nullable :true,
  default:null
})
trc_country_1:CountryCode;

@Column({
  nullable :true,
  default:null
})
trc_idtype_1:string;

@Column({
  nullable :true,
  default:null
})
trc_idnumber_1:string;

@Column({
  type:'enum',
  enum: CountryCode,
  nullable :true,
  default:null
})
trc_country_2:CountryCode;

@Column({
  nullable :true,
  default:null
})
trc_idtype_2:string;

@Column({
  nullable :true,
  default:null
})
trc_idnumber_2:string;

@Column({
  type: 'enum',
  enum: ModeOfHolding,
  nullable:false,
  default: ModeOfHolding.SINGLE,
})
mode_of_holding: ModeOfHolding;

@Column({ type: 'text', nullable:false, default:""})
ca_line: string;

@Column({
  type: 'enum',
  enum: CountryCode,
  nullable:false,
  default: CountryCode.IN
})
ca_country: CountryCode;

@Column({
  type: 'enum',
  enum: CaNature,
  nullable:false,
  default: CaNature.RESIDENTIAL,
})
ca_nature: CaNature;

@Column({ type: 'text', nullable:false, default:""})
cp_number: string;

@Column({
  type: 'enum',
  enum: CpBelongsTo,
  default: CpBelongsTo.SELF,
  nullable: true,
})
cp_belongsto: CpBelongsTo;

@Column({nullable:false})
ce_address: string;

@Column({
  type: 'enum',
  enum: CpBelongsTo,
  default: CpBelongsTo.SELF,
  nullable: true,
})
ce_belongsto: CpBelongsTo;

@Column({nullable:false, default:""})
pba_number:string;

@Column({nullable:false, default:""})
pba_pname:string;

@Column({nullable:false, default:""})
pba_code:string;

@Column({
  type: 'enum',
  enum: SkipNomination,
  nullable:false,
  default: SkipNomination.YES,
})
skip_nomination: SkipNomination;

@Column({
  nullable:true,
  default:null  
})
nominee_name_0:string;

@Column({
  nullable:true,
  default:null
})
nominee_relationship_0:string

@Column({
  nullable:true,
  default:null
})
nominee_dob_0:string

@Column({
  type:'enum',
  nullable:false,
  enum:NomineeIdType
})
nominee_idtype_0:NomineeIdType

@Column({
  nullable:true,
  default:null
})
nominee_idnumber_0:string;

@Column({
  nullable:true,
  default:null
})
nominee_cphone_0:string;

@Column({
  nullable:true,
  default:null
})
nominee_cemail_0:string;

@Column({
  nullable:true,
  default:null
})
nominee_caline_0:string;

@Column({
  nullable:true,
  default:null
})
nominee_capincode_0:string;

@Column({
  type:'enum',
  enum:CountryCode,
  nullable:true,
  default:null
})
nominee_cacountry_0:CountryCode;

@Column({
  nullable:true,
  default:null
})
nominee_guardian_name_0:string;

@Column({
  type:'enum',
  nullable:false,
  enum:NomineeIdType
})
nominee_gidtype_0:NomineeIdType

@Column({
  nullable:true,
  default:null
})
nominee_gidnumber_0:string;

@Column({
  nullable:true,
  default:null
})
nominee_gcemail_0:string;

@Column({
  nullable:true,
  default:null
})
nominee_gcaline_0:string

@Column({
  nullable:true,
  default:null
})
nominee_gcapincode_0: number

@Column({
  type:'enum',
  enum:CountryCode,
  nullable:true,
  default:null
})
nominee_gcacountry_0:CountryCode;

@Column({
  nullable:true,
  default:null
})
nominee_percentage_0: number

@Column({
  nullable:true,
  default:null 
})
nominee_name_1:string;

@Column({
  nullable:true,
  default:null
})
nominee_relationship_1:string

@Column({
  nullable:true,
  default:null
})
nominee_dob_1:string

@Column({
  type:'enum',
  nullable:false,
  enum:NomineeIdType
})
nominee_idtype_1:NomineeIdType

@Column({
  nullable:true,
  default:null
})
nominee_idnumber_1:string;

@Column({
  nullable:true,
  default:null
})
nominee_cphone_1:string;

@Column({
  nullable:true,
  default:null
})
nominee_cemail_1:string;

@Column({
  nullable:true,
  default:null
})
nominee_caline_1:string;

@Column({
  nullable:true,
  default:null
})
nominee_capincode_1:string;

@Column({
  type:'enum',
  enum:CountryCode,
  nullable:true,
  default:null
})
nominee_cacountry_1:CountryCode;

@Column({
  nullable:true,
  default:null
})
nominee_guardian_name_1:string;

@Column({
  type:'enum',
  nullable:false,
  enum:NomineeIdType
})
nominee_gidtype_1:NomineeIdType

@Column({
  nullable:true,
  default:null
})
nominee_gidnumber_1:string;

@Column({
  nullable:true,
  default:null
})
nominee_gcemail_1:string;

@Column({
  nullable:true,
  default:null
})
nominee_gcaline_1:string

@Column({
  nullable:true,
  default:null
})
nominee_gcapincode_1: number

@Column({
  type:'enum',
  enum:CountryCode,
  nullable:true,
  default:null
})
nominee_gcacountry_1:CountryCode;

@Column({
  nullable:true,
  default:null
})
nominee_percentage_1: number

@Column({
  nullable:true,
  default:null  
})
nominee_name_2:string;

@Column({
  nullable:true,
  default:null
})
nominee_relationship_2:string

@Column({
  nullable:true,
  default:null
})
nominee_dob_2:string

@Column({
  type:'enum',
  nullable:false,
  enum:NomineeIdType
})
nominee_idtype_2:NomineeIdType

@Column({
  nullable:true,
  default:null
})
nominee_idnumber_2:string;

@Column({
  nullable:true,
  default:null
})
nominee_cphone_2:string;

@Column({
  nullable:true,
  default:null
})
nominee_cemail_2:string;

@Column({
  nullable:true,
  default:null
})
nominee_caline_2:string;

@Column({
  nullable:true,
  default:null
})
nominee_capincode_2:string;

@Column({
  type:'enum',
  enum:CountryCode,
  nullable:true,
  default:null
})
nominee_cacountry_2:CountryCode;

@Column({
  nullable:true,
  default:null
})
nominee_guardian_name_2:string;

@Column({
  type:'enum',
  nullable:false,
  enum:NomineeIdType
})
nominee_gidtype_2:NomineeIdType

@Column({
  nullable:true,
  default:null
})
nominee_gidnumber_2:string;

@Column({
  nullable:true,
  default:null
})
nominee_gcemail_2:string;

@Column({
  nullable:true,
  default:null
})
nominee_gcaline_2:string

@Column({
  nullable:true,
  default:null
})
nominee_gcapincode_2: number

@Column({
  type:'enum',
  enum:CountryCode,
  nullable:true,
  default:null
})
nominee_gcacountry_2:CountryCode;

@Column({
  nullable:true,
  default:null
})
nominee_percentage_2: number


@Column({
  type:'enum',
  enum:NomineeDisplayOption,
  nullable:true,
  default:null
})
nomination_display_setting:NomineeDisplayOption

  // @Column({ length: 72 })
  // investorName: string;

  // @Column({ length: 70, nullable: true })
  // fatherName?: string;

  // @Column({ length: 70, nullable: true })
  // spouseName?: string;

  // @Column({ length: 70 })
  // motherName: string;

  // @Column({ enum: ['Married', 'Unmarried'] })
  // maritalStatus: string;

  // @Column({ type: 'char', length: 4 })
  // aadhaarLast4Digits: string;

  // @Column()
  // nationality: string;

  // @Column()
  // citizenship: string;

  // @Column()
  // signatureUrl: string; // URL or path to file

  // @Column('decimal', { precision: 10, scale: 7 })
  // geoLatitude: number;

  // @Column('decimal', { precision: 10, scale: 7 })
  // geoLongitude: number;

  // @Column()
  // occupation: string;

  // @Column()
  // sourceOfWealth: string;

  // @Column()
  // annualIncome: string;

  // @Column()
  // countryOfBirth: string;

  // @Column({ length: 60 })
  // placeOfBirth: string;

  // @Column()
  // politicalExposure: string;

  // @Column({ default: 'Resident' })
  // taxResidencyStatus: string;

  // // Communication Address Fields
  // @Column()
  // addressLine: string;

  // @Column({ length: 6 })
  // pincode: string;

  // @Column()
  // country: string;

  // @Column()
  // addressNature: string;

  // // Contact Info
  // @Column({ length: 10 })
  // phoneNumber: string;

  // @Column()
  // phoneBelongsTo: string;

  // @Column()
  // email: string;

  // @Column()
  // emailBelongsTo: string;

  // // Payout Bank Details
  // @Column({ length: 18 })
  // bankAccountNumber: string;

  // @Column({ length: 70 })
  // primaryHolderName: string;

  // @Column()
  // ifscCode: string;

  // @Column({ default: 'Savings' })
  // accountType: string;

  // // Nominee 1
  // @Column({ nullable: true })
  // nomineeName: string;

  // @Column({ nullable: true })
  // nomineePAN: string;

  // @Column({ type: 'date', nullable: true })
  // nomineeDOB: Date;

  // @Column({ nullable: true })
  // nomineeRelationship: string;

  // @Column({ nullable: true })
  // nomineeGuardianName: string;

  // @Column({ nullable: true })
  // nomineeGuardianPAN: string;

  // @Column({ type: 'int', nullable: true })
  // nomineeAllocationPercentage: number;
}
