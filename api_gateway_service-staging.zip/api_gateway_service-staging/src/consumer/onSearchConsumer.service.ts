import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { MqService } from './mq.service';
import * as amqp from 'amqplib';

import { promises as fsPromises } from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';

@Injectable()
export class OnSearchConsumerService implements OnModuleInit {
  private readonly logger = new Logger(OnSearchConsumerService.name);

  constructor(private readonly mqService: MqService) {}

  async onModuleInit() {
    await this.consumeQueue('on_search_queue');
  }

  async saveRequestBodyToJson(
    body: any,
    filename?: string
  ): Promise<string> {
    const uploadsFolder = path.join(__dirname, '../../', 'uploads');
    console.log("🚀 ~ OnSearchConsumerService ~ uploadsFolder:", uploadsFolder)
  
    // Ensure uploads folder exists
    await fsPromises.mkdir(uploadsFolder, { recursive: true });
  
    // If filename not provided, generate random name
    const safeFileName = filename
      ? this.sanitizeFilename(filename)
      : crypto.randomUUID();
  
    const filePath = path.join(uploadsFolder, `${safeFileName}.json`);
  
    // Save body to file
    await fsPromises.writeFile(filePath, JSON.stringify(body, null, 2), 'utf-8');
  
    return filePath;
  }
  
  // Utility function to sanitize filenames
  sanitizeFilename(name: string): string {
    return name.replace(/[^a-z0-9_\-]/gi, '_').toLowerCase();
  }

  private async consumeQueue(queueName: string) {
    await this.mqService.listenToQueue(queueName, async (data, msg, channel:amqp.Channel) => {
      try {
        // this.logger.log(`📥 Received from ${queueName}: ${JSON.stringify(data)}`);

        const parsedData = typeof data === 'string' ? JSON.parse(data) : data;
        
        const fileName = data?.context?.bpp_id || `file-${Date.now()}`;
        console.log("🚀 ~ OnSearchConsumerService ~ awaitthis.mqService.listenToQueue ~ fileName:", fileName)
        let path = await this.saveRequestBodyToJson(parsedData, fileName);
        console.log("🚀 ~ OnSearchConsumerService ~ awaitthis.mqService.listenToQueue ~ path:", path)
        
        // 🚀 Your business logic here
        // e.g., await this.someService.handle(data);

        channel.ack(msg);
      } catch (err) {
        this.logger.error(`❌ Error processing message from ${queueName}: ${err.message}`, err.stack);
        
        // 🔁 Decide whether to requeue the message (true) or discard (false);
        const requeue = true;

        channel.nack(msg, false, requeue);
      }
    });
  }
}
