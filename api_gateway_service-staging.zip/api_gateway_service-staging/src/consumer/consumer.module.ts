import { Module } from "@nestjs/common";
// import { MqService } from "src/mqConsumer.service";
import { OnSearchConsumerService } from "./onSearchConsumer.service";
import { MqService } from "./mq.service";

@Module({
    imports:[],
    controllers: [],
    providers: [
        MqService,
        // OnSearchConsumerService
    ],
    exports: [MqService,OnSearchConsumerService]
})
export class ConsumerModule {}