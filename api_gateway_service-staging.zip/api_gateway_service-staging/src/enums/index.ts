export enum Gender {
  MALE = 'male',
  FEMALE = 'female',
  Transgender = 'transgender',
}


export enum MaritalStatus {
  MARRIED = 'married',
  UNMARRIED = "UNMARRIED",
  OTHER = 'other'
}


export enum Nationality {
  IN = 'in', // India
  US = 'us', // United States
  UK = 'uk', // United Kingdom
  // Add more as needed
}

export enum Citizenship {
  INDIA = 'India',
  USA = 'USA',
  UK = 'UK',
  CANADA = 'Canada',
  OTHER = 'Other',
}

export enum Occupation {
  BUSINESS = 'business',
  PROFESSIONAL = 'professional',
  RETIRED = 'retired',
  HOUSEWIFE = "Housewife",
  PUBLIC_SECTOR_SERVICE = 'Public Sector Service',
  PRIVATE_SECTOR_SERVICE = 'private Sector Service',
  GOVERNMENT_SERVICE = 'Government Service',
  AGRICULTURE = 'Agriculture',
  DOCTOR = 'Doctor',
  FOREX_DEALER= 'Forex Dealer',
  SERVICE = 'Service',
  STUDENT = 'student',
  OTHER = 'other',
}

export enum SourceOfWealth {
  SALARY = 'salary',
  BUSINESS = 'business',
  GIFT = 'gift',
  ANCESTRAL_PROPERTY = 'Ancestral Property',
  RENTAL_INCOME = 'Rental Income',
  PRIZE_MONY = 'prize money',
  ROYALTY = 'Royalty',
  OTHERS = 'others',
}

export enum IncomeRange {
  /** Below ₹1 lakh */
  UPTO_1_LAKH                 = 'upto_1lakh',

  /** ₹1 lakh to ₹5 lakh */
  ABOVE_1_LAKH_UPTO_5_LAKH    = 'above_1lakh_upto_5lakh',

  /** ₹5 lakh to ₹10 lakh */
  ABOVE_5_LAKH_UPTO_10_LAKH   = 'above_5lakh_upto_10lakh',

  /** ₹10 lakh to ₹25 lakh */
  ABOVE_10_LAKH_UPTO_25_LAKH  = 'above_10lakh_upto_25lakh',

  /** ₹25 lakh to ₹1 crore */
  ABOVE_25_LAKH_UPTO_1_CR     = 'above_25lakh_upto_1cr',

  /** Over ₹1 crore */
  ABOVE_1_CR                  = 'above_1cr',
}

export enum CountryCode {
  AF = 'af', // Afghanistan
  AL = 'al', // Albania
  DZ = 'dz', // Algeria
  AS = 'as', // American Samoa
  AD = 'ad', // Andorra
  AO = 'ao', // Angola
  AG = 'ag', // Antigua and Barbuda
  AR = 'ar', // Argentina
  AM = 'am', // Armenia
  AU = 'au', // Australia
  AT = 'at', // Austria
  AZ = 'az', // Azerbaijan
  BS = 'bs', // Bahamas
  BH = 'bh', // Bahrain
  BD = 'bd', // Bangladesh
  BB = 'bb', // Barbados
  BY = 'by', // Belarus
  BE = 'be', // Belgium
  BZ = 'bz', // Belize
  BJ = 'bj', // Benin
  BT = 'bt', // Bhutan
  BO = 'bo', // Bolivia
  BA = 'ba', // Bosnia and Herzegovina
  BW = 'bw', // Botswana
  BR = 'br', // Brazil
  BN = 'bn', // Brunei
  BG = 'bg', // Bulgaria
  BF = 'bf', // Burkina Faso
  BI = 'bi', // Burundi
  KH = 'kh', // Cambodia
  CM = 'cm', // Cameroon
  CA = 'ca', // Canada
  CV = 'cv', // Cape Verde
  CF = 'cf', // Central African Republic
  TD = 'td', // Chad
  CL = 'cl', // Chile
  CN = 'cn', // China
  CO = 'co', // Colombia
  KM = 'km', // Comoros
  CG = 'cg', // Congo (Brazzaville)
  CD = 'cd', // Congo (Kinshasa)
  CR = 'cr', // Costa Rica
  CI = 'ci', // Côte d’Ivoire
  HR = 'hr', // Croatia
  CU = 'cu', // Cuba
  CY = 'cy', // Cyprus
  CZ = 'cz', // Czech Republic
  DK = 'dk', // Denmark
  DJ = 'dj', // Djibouti
  DM = 'dm', // Dominica
  DO = 'do', // Dominican Republic
  EC = 'ec', // Ecuador
  EG = 'eg', // Egypt
  SV = 'sv', // El Salvador
  GQ = 'gq', // Equatorial Guinea
  ER = 'er', // Eritrea
  EE = 'ee', // Estonia
  SZ = 'sz', // Eswatini
  ET = 'et', // Ethiopia
  FJ = 'fj', // Fiji
  FI = 'fi', // Finland
  FR = 'fr', // France
  GA = 'ga', // Gabon
  GM = 'gm', // Gambia
  GE = 'ge', // Georgia
  DE = 'de', // Germany
  GH = 'gh', // Ghana
  GR = 'gr', // Greece
  GD = 'gd', // Grenada
  GT = 'gt', // Guatemala
  GN = 'gn', // Guinea
  GW = 'gw', // Guinea-Bissau
  GY = 'gy', // Guyana
  HT = 'ht', // Haiti
  HN = 'hn', // Honduras
  HU = 'hu', // Hungary
  IS = 'is', // Iceland
  IN = 'in', // India
  ID = 'id', // Indonesia
  IR = 'ir', // Iran
  IQ = 'iq', // Iraq
  IE = 'ie', // Ireland
  IL = 'il', // Israel
  IT = 'it', // Italy
  JM = 'jm', // Jamaica
  JP = 'jp', // Japan
  JO = 'jo', // Jordan
  KZ = 'kz', // Kazakhstan
  KE = 'ke', // Kenya
  KI = 'ki', // Kiribati
  KW = 'kw', // Kuwait
  KG = 'kg', // Kyrgyzstan
  LA = 'la', // Laos
  LV = 'lv', // Latvia
  LB = 'lb', // Lebanon
  LS = 'ls', // Lesotho
  LR = 'lr', // Liberia
  LY = 'ly', // Libya
  LI = 'li', // Liechtenstein
  LT = 'lt', // Lithuania
  LU = 'lu', // Luxembourg
  MG = 'mg', // Madagascar
  MW = 'mw', // Malawi
  MY = 'my', // Malaysia
  MV = 'mv', // Maldives
  ML = 'ml', // Mali
  MT = 'mt', // Malta
  MH = 'mh', // Marshall Islands
  MR = 'mr', // Mauritania
  MU = 'mu', // Mauritius
  MX = 'mx', // Mexico
  FM = 'fm', // Micronesia
  MD = 'md', // Moldova
  MC = 'mc', // Monaco
  MN = 'mn', // Mongolia
  ME = 'me', // Montenegro
  MA = 'ma', // Morocco
  MZ = 'mz', // Mozambique
  MM = 'mm', // Myanmar
  NA = 'na', // Namibia
  NP = 'np', // Nepal
  NL = 'nl', // Netherlands
  NZ = 'nz', // New Zealand
  NI = 'ni', // Nicaragua
  NE = 'ne', // Niger
  NG = 'ng', // Nigeria
  KP = 'kp', // North Korea
  MK = 'mk', // North Macedonia
  NO = 'no', // Norway
  OM = 'om', // Oman
  PK = 'pk', // Pakistan
  PW = 'pw', // Palau
  PA = 'pa', // Panama
  PG = 'pg', // Papua New Guinea
  PY = 'py', // Paraguay
  PE = 'pe', // Peru
  PH = 'ph', // Philippines
  PL = 'pl', // Poland
  PT = 'pt', // Portugal
  QA = 'qa', // Qatar
  RO = 'ro', // Romania
  RU = 'ru', // Russia
  RW = 'rw', // Rwanda
  KN = 'kn', // Saint Kitts and Nevis
  LC = 'lc', // Saint Lucia
  VC = 'vc', // Saint Vincent and the Grenadines
  WS = 'ws', // Samoa
  SM = 'sm', // San Marino
  ST = 'st', // São Tomé and Príncipe
  SA = 'sa', // Saudi Arabia
  SN = 'sn', // Senegal
  RS = 'rs', // Serbia
  SC = 'sc', // Seychelles
  SL = 'sl', // Sierra Leone
  SG = 'sg', // Singapore
  SK = 'sk', // Slovakia
  SI = 'si', // Slovenia
  SB = 'sb', // Solomon Islands
  SO = 'so', // Somalia
  ZA = 'za', // South Africa
  KR = 'kr', // South Korea
  SS = 'ss', // South Sudan
  ES = 'es', // Spain
  LK = 'lk', // Sri Lanka
  SD = 'sd', // Sudan
  SR = 'sr', // Suriname
  SE = 'se', // Sweden
  CH = 'ch', // Switzerland
  SY = 'sy', // Syria
  TW = 'tw', // Taiwan
  TJ = 'tj', // Tajikistan
  TZ = 'tz', // Tanzania
  TH = 'th', // Thailand
  TL = 'tl', // Timor-Leste
  TG = 'tg', // Togo
  TO = 'to', // Tonga
  TT = 'tt', // Trinidad and Tobago
  TN = 'tn', // Tunisia
  TR = 'tr', // Turkey
  TM = 'tm', // Turkmenistan
  UG = 'ug', // Uganda
  UA = 'ua', // Ukraine
  AE = 'ae', // United Arab Emirates
  GB = 'gb', // United Kingdom
  US = 'us', // United States
  UY = 'uy', // Uruguay
  UZ = 'uz', // Uzbekistan
  VU = 'vu', // Vanuatu
  VE = 've', // Venezuela
  VN = 'vn', // Vietnam
  YE = 'ye', // Yemen
  ZM = 'zm', // Zambia
  ZW = 'zw', // Zimbabwe
}


export enum PoliticalExposure{
  NO_EXPOSURE= 'No exposure',
  POLITICALLY_EXPOSED= 'Politically Exposed',
  RELATED_TO_POLITICALLY_EXPOSED_PERSON= 'Related to a Politically Exposed Person',
}

export enum IndiaTaxResidencyStatus {
  RESIDENT = 'resident',
}

export enum ModeOfHolding {
  SINGLE = 'single',
}

export enum CaNature {
  RESIDENTIAL = 'residential',
  REGISTERED_OFFICE = 'Registered Office',
  BUSINESS_LOCATION = 'Business Location',
}

export enum CpBelongsTo {
  SELF = 'self',
  SPOUSE = 'spouse',
  DEPENDENT_CHILDREN = 'dependent_children',
  DEPENDENT_SIBLINGS = 'dependent_siblings',
  DEPENDENT_PARENTS = 'dependent_parents',
  GUARDIAN = 'guardian',
  PMS = 'pms',
  CUSTODIAN = 'custodian',
  POA = 'poa',
}

export enum PbaType {
  SAVINGS = 'savings',
  CURRENT = 'current',
  // SALARY = 'salary',
  // FIXED_DEPOSIT = 'fixed_deposit',
  // NRE = 'nre',              // Non-Resident External
  // NRO = 'nro',              // Non-Resident Ordinary
  // OTHERS = 'others'
}


export enum SkipNomination {
  YES = 'yes',
  NO = 'no',
}

export enum NomineeRelationship {
  AUNT = 'aunt',
  BROTHER_IN_LAW = 'brother_in_law',
  BROTHER = 'brother',
  DAUGHTER = 'daughter',
  DAUGHTER_IN_LAW = 'daughter_in_law',
  FATHER = 'father',
  FATHER_IN_LAW = 'father_in_law',
  GRAND_DAUGHTER = 'grand_daughter',
  GRAND_FATHER = 'grand_father',
  GRAND_MOTHER = 'grand_mother',
  GRAND_SON = 'grand_son',
  MOTHER_IN_LAW = 'mother_in_law',
  MOTHER = 'mother',
  NEPHEW = 'nephew',
  NIECE = 'niece',
  SISTER = 'sister',
  SISTER_IN_LAW = 'sister_in_law',
  SON = 'son',
  SON_IN_LAW = 'son_in_law',
  SPOUSE = 'spouse',
  UNCLE = 'uncle',
  COURT_APPOINTED_LEGAL_GUARDIAN = 'court_appointed_legal_guardian',
  OTHERS = 'others',
}


export enum NomineeIdType{
PAN= 'PAN',
AADHAAR_LAST_4_DIGIT = 'Aadhaar (Last 4 digits)',
DRIVING_LICENCE = 'Driving License',
PASSPORT = 'Passport'
}

export enum NomineeDisplayOption {
  SHOW_ALL_NOMINEE_NAMES = 'show_all_nominee_names',
  SHOW_NOMINATION_STATUS = 'show_nomination_status',
}

