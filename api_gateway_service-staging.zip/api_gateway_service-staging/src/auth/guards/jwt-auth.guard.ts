import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import * as jwt from 'jsonwebtoken';
import { Request } from 'express';
import { IS_PUBLIC_KEY } from '../../decorators/public.decorator';
import { TenantService } from 'src/tenant/tenant.service';

console.log('JwtAuthGuard file loaded ✅');


@Injectable()
export class JwtAuthGuard implements CanActivate {


  constructor(
    private readonly tenantService: TenantService,
    private readonly reflector: Reflector,
  ) {

    console.log(
      'JwtAuthGuard initialized:',
      'reflector exists:', !!reflector,
      'tenantService exists:', !!tenantService,
    );

  }

  async canActivate(context: ExecutionContext): Promise<boolean> {

    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const request = context.switchToHttp().getRequest<Request>();
    const authHeader = request.headers['authorization'];


    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedException('Authorization header missing or invalid');
    }

    const token = authHeader.split(' ')[1];

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET) as any;

      const connection = await this.tenantService.getTenantConnection(decoded.tenant_id);

      request['tenantDB'] = connection;

      request.body['context'] = {
        tenant_id: decoded.tenant_id,
        user_id: decoded.sub,
        email: decoded.email,
        roles: decoded.roles || [],
      };

      return true;
    } catch (err) {
      throw new UnauthorizedException('Invalid or expired token');
    }
  }
}
