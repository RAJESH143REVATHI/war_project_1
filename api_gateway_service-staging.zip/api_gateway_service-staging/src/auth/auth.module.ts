import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { Amc, AmcSchema } from 'src/schemas/amc.schema';
import { Fund, FundSchema } from 'src/schemas/fund.schema';
import { AmcCollection, AmcCollectionSchema } from 'src/schemas/amc-collection.schema';
import { UserService } from 'src/gateway/user-service/user-service.service';
import { RmqService } from 'src/shared/rmq.service';
import { JwtModule } from '@nestjs/jwt';
import { JwtStrategy } from 'src/gateway/strategy/JwtStrategy';
import { TenantConfig, TenantConfigSchema } from 'src/tenant/tenantConfig.schema';




import { forwardRef, Module } from '@nestjs/common';
import { JwtAuthGuard } from './guards/jwt-auth.guard';
import { APP_GUARD, Reflector } from '@nestjs/core';
import { TenantModule } from '../tenant/tenant.module';
import { TenantService } from 'src/tenant/tenant.service';
import { UserServiceModule } from 'src/gateway/user-service/user-service.module';


@Module({
  imports: [
    JwtModule.register({
      secret: 'YOUR_SECRET_KEY', // Change to env variable in production
      signOptions: { expiresIn: '1h' },
    }),
    MongooseModule.forFeature([
      { name: TenantConfig.name, schema: TenantConfigSchema },
      { name: Amc.name, schema: AmcSchema },
      { name: Fund.name, schema: FundSchema },

    ]), 
    forwardRef(() => TenantModule),
    UserServiceModule
  ],
  controllers: [AuthController],
  providers: [AuthService, RmqService, JwtStrategy],
})
export class AuthModule { }
