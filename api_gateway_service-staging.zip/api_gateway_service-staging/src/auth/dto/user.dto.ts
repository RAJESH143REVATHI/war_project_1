import { IsNotEmpty, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UserDto {
  @ApiProperty({ description: 'Source ' })
  @IsNotEmpty()
  @IsString()
  source: string;

  @ApiProperty({ description: 'Mobile number' })
  @IsNotEmpty()
  @IsString()
  mobile: string;

  @ApiProperty({ description: 'Device number' })
  @IsNotEmpty()
  @IsString()
  deviceNumber: string;

  @ApiProperty({ description: 'Operating System' })
  @IsNotEmpty()
  @IsString()
  OS: string;

  @ApiProperty({ description: 'Firebase Cloud Messaging token' })
  @IsNotEmpty()
  @IsString()
  FCM: string;

  // @ApiProperty({ description: 'Authentication token' })
  // @IsNotEmpty()
  // @IsString()
  // token: string;

  @ApiProperty({ description: 'Detailed device information' })
  @IsNotEmpty()
  @IsString()
  deviceDetail: string;

}